const { default: mongoose } = require("mongoose");
const Feedback = require("../models/Feedback");
const LeaveRequest = require("../models/LeaveRequest");
const Scheduling = require("../models/Scheduling");
const TherapistAssignment = require("../models/TherapistAssignment");
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const Batch = require("../models/Batch");
const fs = require("fs");
const path = require("path");
const Notification = require("../models/Notification");
const { MIME_TO_TYPE } = require("../utils/broadcastUpload");
const Complaint = require("../models/Complaint");
const SystemSetting = require("../models/SystemSetting");
const TherapistAvailability = require("../models/TherapistAvailability");
const BatchAssignment = require("../models/BatchAssignment");
const Package = require("../models/Package");
const Service = require("../models/Service");
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const { sendToUsers, TEMPLATE, sendNotifications } = require("../utils/notificationService");
const { buildRecipients } = require("../utils/broadcastHelpers");
const Conversation = require("../models/Conversation");
const multer = require("multer");
const cloudinary = require("../config/cloudinary");
const {
  calcAge,
  sanitizeDocuments,
  removedDocuments,
  destroyDocuments,
  confirmDocuments,
} = require("../utils/childDocuments");
const { sendBulkPushToUsers, sendPushToUser } = require("./pushNotificationController");
const sendEmail = require("../utils/sendEmail");
const Message = require("../models/Message");
const QuarterlyReport = require("../models/QuarterlyReport");
const Program = require("../models/Program");
const Permission = require("../models/Permission");
const PermissionGroup = require("../models/PermissionGroup");
const UserPermission = require("../models/UserPermission");
const { cleanGroupIds, validateGroupIds, replaceManagerGroups } = require("../utils/managerGroups");
const PAST_DAYS = 365;
const POPULATE = [
  { path: "complainantId", select: "fullName role" },
  { path: "resolvedBy", select: "fullName" },
];
const ROLES = ["Admin", "Therapist", "Manager","Child"];

const normalizeName = (name) => name?.trim().replace(/\s+/g, " ").toLowerCase();
const normalizeCnic = (v = "") => {
  const d = String(v).replace(/\D/g, "");
  return d.length === 13
    ? `${d.slice(0, 5)}-${d.slice(5, 12)}-${d.slice(12)}`
    : null;
};
const SESSION_TIMES = [30,45, 60, 90, 120];
const DAY_MS = 86400000;
const TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const WORKING_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const JS_DAY_TO_NAME = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const toMin = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
const to12 = (t) => {
  const [h, m = 0] = String(t).split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
};
const loadTherapistLeaves = async (therapistId, from, to) => {
  const docs = await LeaveRequest.find({
    applicantId: therapistId,
    status: "approved",
    startDate: { $lt: utcMidnight(addDays(to, 1)) },
    endDate: { $gte: utcMidnight(from) },
  })
    .select("startDate endDate")
    .lean();

  return docs.map((d) => ({
    from: dateKeyOf(d.startDate),
    to: dateKeyOf(d.endDate),
  }));
};

const onLeave = (leaves, date) =>
  leaves.some((l) => l.from <= date && date <= l.to);

const LEAVE_MSG = "Therapist is on leave on this day.";

const isValidDate = (s) =>
  typeof s === "string"
  && DATE_REGEX.test(s)
  && !Number.isNaN(new Date(`${s}T00:00:00Z`).getTime());

const weekdayOf = (s) => JS_DAY_TO_NAME[new Date(`${s}T00:00:00Z`).getUTCDay()];

const todayKey = (tz = "Asia/Karachi") => new Date().toLocaleDateString("en-CA", { timeZone: tz });

const describe = (r) =>
  r.type === "custom"
    ? `${r.date}, ${to12(r.startTime)}-${to12(r.endTime)}`
    : (r.slots || [])
      .map((s) => `${s.day} ${to12(s.startTime)}-${to12(s.endTime)}`)
      .join(", ");
let settingsCache = { at: 0, value: null };
const loadScheduleSettings = async () => {
  if (settingsCache.value && Date.now() - settingsCache.at < 60 * 1000) {
    return settingsCache.value;
  }
  const s = await SystemSetting.findOne().lean();
  const value = {
    tz: s?.timezone || "Asia/Karachi",
    clinicStart: s?.clinicStartTime ? toMin(s.clinicStartTime) : null,
    clinicEnd: s?.clinicEndTime ? toMin(s.clinicEndTime) : null,
    workingDays: s?.workingDays?.length ? s.workingDays : WORKING_DAYS,
  };
  settingsCache = { at: Date.now(), value };
  return value;
};
const timesOverlap = (a, b) =>
  toMin(a.startTime) < toMin(b.endTime)
  && toMin(b.startTime) < toMin(a.endTime);

const rulesConflict = (a, b) => {
  if (a.type === "custom" && b.type === "custom") {
    return a.date === b.date && timesOverlap(a, b);
  }
  if (a.type === "custom" || b.type === "custom") {
    const c = a.type === "custom" ? a : b;
    const r = a.type === "custom" ? b : a;
    const day = weekdayOf(c.date);
    const inRange = (!r.effectiveFrom || c.date >= r.effectiveFrom)
      && (!r.effectiveTo || c.date <= r.effectiveTo);
    return (
      inRange
      && (r.slots || []).some((s) => s.day === day && timesOverlap(s, c))
    );
  }
  const rangesOverlap = (!a.effectiveTo || !b.effectiveFrom || a.effectiveTo >= b.effectiveFrom)
    && (!b.effectiveTo || !a.effectiveFrom || b.effectiveTo >= a.effectiveFrom);
  return (
    rangesOverlap
    && (a.slots || []).some((sa) => (b.slots || []).some((sb) => sa.day === sb.day && timesOverlap(sa, sb)))
  );
};

const buildRule = async (body, current) => {
  const settings = await SystemSetting.findOne().lean();
  const today = todayKey(settings?.timezone || "Asia/Karachi");

  const type = current ? current.type : body.type;
  if (!["recurring", "custom"].includes(type)) {
    return { error: "type must be recurring or custom." };
  }

  const checkTimes = (startTime, endTime, label = "") => {
    const prefix = label ? `${label}: ` : "";
    if (!TIME_REGEX.test(startTime || "") || !TIME_REGEX.test(endTime || "")) {
      return `${prefix}startTime and endTime must be in HH:mm format.`;
    }
    if (toMin(endTime) <= toMin(startTime)) {
      return `${prefix}End time must be after start time.`;
    }
    if (
      settings
      && (toMin(startTime) < toMin(settings.clinicStartTime)
        || toMin(endTime) > toMin(settings.clinicEndTime))
    ) {
      return `${prefix}Availability must be within clinic hours (${to12(settings.clinicStartTime)}-${
        to12(settings.clinicEndTime)
      }).`;
    }
    return null;
  };

  if (type === "recurring") {
    const raw = body.slots !== undefined ? body.slots : current?.slots;
    if (!Array.isArray(raw) || raw.length === 0) {
      return { error: "Select at least one day." };
    }

    const seen = new Set();
    const slots = [];
    for (const s of raw) {
      if (!WORKING_DAYS.includes(s?.day)) return { error: "Invalid weekday." };
      if (seen.has(s.day)) {
        return { error: `${s.day} is added more than once.` };
      }
      seen.add(s.day);

      if (
        settings?.workingDays?.length
        && !settings.workingDays.includes(s.day)
      ) {
        return { error: `${s.day} is not a clinic working day.` };
      }
      const err = checkTimes(s.startTime, s.endTime, s.day);
      if (err) return { error: err };

      slots.push({ day: s.day, startTime: s.startTime, endTime: s.endTime });
    }
    slots.sort(
      (a, b) => WORKING_DAYS.indexOf(a.day) - WORKING_DAYS.indexOf(b.day),
    );
    const effectiveFrom = body.effectiveFrom || current?.effectiveFrom || today;
    const effectiveTo = body.effectiveTo !== undefined ? body.effectiveTo : current?.effectiveTo;

    if (!isValidDate(effectiveFrom)) return { error: "Invalid start date." };
    if (effectiveTo && !isValidDate(effectiveTo)) {
      return { error: "Invalid end date." };
    }
    if (effectiveTo && effectiveTo < effectiveFrom) {
      return { error: "End date cannot be before start date." };
    }
    return {
      rule: {
        type,
        slots,
        effectiveFrom,
        effectiveTo: effectiveTo || null,
        date: null,
        startTime: null,
        endTime: null,
      },
    };
  }

  const date = body.date !== undefined ? body.date : current?.date;
  const startTime = body.startTime !== undefined ? body.startTime : current?.startTime;
  const endTime = body.endTime !== undefined ? body.endTime : current?.endTime;

  if (!isValidDate(date)) return { error: "A valid date is required." };
  if (date < today) return { error: "Date cannot be in the past." };
  if (
    settings?.workingDays?.length
    && !settings.workingDays.includes(weekdayOf(date))
  ) {
    return { error: `${weekdayOf(date)} is not a clinic working day.` };
  }
  const err = checkTimes(startTime, endTime);
  if (err) return { error: err };

  return {
    rule: {
      type,
      date,
      startTime,
      endTime,
      slots: [],
      effectiveFrom: null,
      effectiveTo: null,
    },
  };
};

const findConflict = async (therapistId, rule, excludeId) => {
  const query = { therapistId, isActive: true };
  if (excludeId) query._id = { $ne: excludeId };
  const others = await TherapistAvailability.find(query).lean();
  return others.find((o) => rulesConflict(rule, o));
};

const pad = (n) => String(n).padStart(2, "0");

const formatDate = (date) => {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${
    pad(
      date.getDate(),
    )
  }`;
};

const getDayName = (date) => {
  const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return names[date.getDay()];
};

const timeToMinutes = (time) => {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
};

const minutesToTime = (minutes) => {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;

  return `${pad(h)}:${pad(m)}`;
};

const overlaps = (startA, endA, startB, endB) => {
  return (
    timeToMinutes(startA) < timeToMinutes(endB)
    && timeToMinutes(endA) > timeToMinutes(startB)
  );
};

const dateKeyOf = (d) => new Date(d).toISOString().slice(0, 10);
const addDays = (key, n) =>
  new Date(Date.parse(`${key}T00:00:00Z`) + n * DAY_MS)
    .toISOString()
    .slice(0, 10);
const sameId = (a, b) => String(a?._id || a) === String(b?._id || b);
const utcMidnight = (key) => new Date(`${key}T00:00:00Z`);

const planRange = (batch, today) => {
  const from = dateKeyOf(batch.dateFrom);
  return { from: from > today ? from : today, to: dateKeyOf(batch.dateTo) };
};

const insideClinic = (a, b, st) =>
  (st.clinicStart == null || (a >= st.clinicStart && b <= st.clinicEnd))

const availableOnDate = (rules, key, a, b) => {
  const day = weekdayOf(key);
  return rules.some((r) => {
    if (r.type === "custom") {
      return r.date === key && toMin(r.startTime) <= a && toMin(r.endTime) >= b;
    }
    if (
      (r.effectiveFrom && key < r.effectiveFrom)
      || (r.effectiveTo && key > r.effectiveTo)
    ) {
      return false;
    }
    return (r.slots || []).some(
      (s) => s.day === day && toMin(s.startTime) <= a && toMin(s.endTime) >= b,
    );
  });
};

const weeklyOptions = (rules, from, to, minutes, st) => {
  const out = {};
  WORKING_DAYS.forEach((d) => (out[d] = []));
  const seen = new Set();

  for (const r of rules) {
    if (r.type !== "recurring") continue;
    if (
      (r.effectiveTo && r.effectiveTo < from)
      || (r.effectiveFrom && r.effectiveFrom > to)
    ) {
      continue;
    }

    for (const s of r.slots || []) {
      if (!st.workingDays.includes(s.day)) continue;
      for (
        let a = toMin(s.startTime);
        a + minutes <= toMin(s.endTime);
        a += minutes
      ) {
        const b = a + minutes;
        if (!insideClinic(a, b, st)) continue;
        const k = `${s.day}|${a}`;
        if (seen.has(k)) continue;
        seen.add(k);
        out[s.day].push({
          startTime: minutesToTime(a),
          endTime: minutesToTime(b),
        });
      }
    }
  }
  Object.values(out).forEach((l) => l.sort((x, y) => x.startTime.localeCompare(y.startTime)));
  return out;
};
const analyzePlan = async (batch, body) => {
  const minutes = Number(body.sessionMinutes);

  if (!SESSION_TIMES.includes(minutes)) {
    return { error: "Session time must be 30, 45, 60, 90 or 120 minutes." };
  }

  const plans = Array.isArray(body.plans) ? body.plans : [];

  if (!plans.length) {
    return { error: "Select at least one therapist and slot." };
  }

  const seenPlan = new Set();

  for (const p of plans) {
    if (!mongoose.isValidObjectId(p.therapistId)) {
      return { error: "Invalid therapist." };
    }

    if (!batch.speciality.includes(p.speciality)) {
      return { error: "That speciality does not belong to this batch." };
    }

    const key = `${p.therapistId}|${p.speciality}`;

    if (seenPlan.has(key)) {
      return {
        error: "A therapist is listed twice for the same speciality.",
      };
    }

    seenPlan.add(key);

    if (!Array.isArray(p.slots) || !p.slots.length) {
      return {
        error: "Every selected therapist needs at least one slot.",
      };
    }

    for (const s of p.slots) {
      if (
        !WORKING_DAYS.includes(s.day)
        || !TIME_REGEX.test(s.startTime || "")
        || !TIME_REGEX.test(s.endTime || "")
        || toMin(s.endTime) - toMin(s.startTime) !== minutes
      ) {
        return { error: "One of the selected slots is invalid." };
      }
    }
  }

  const therapistIds = [
    ...new Set(plans.map((p) => String(p.therapistId))),
  ];

  const eligible = await TherapistAssignment.find({
    therapistId: { $in: therapistIds },
    specialty: { $in: batch.speciality },
  }).lean();

  const notEligible = plans.find(
    (p) =>
      !eligible.some(
        (e) =>
          String(e.therapistId) === String(p.therapistId)
          && e.specialty === p.speciality,
      ),
  );

  if (notEligible) {
    return {
      error: "A selected therapist does not match the batch speciality.",
    };
  }

  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);
  const nowMin = clockMinutes(st.tz);
  const { from, to } = planRange(batch, today);

  if (from > to) {
    return { error: "This batch has already ended." };
  }

  const [rules, users, schedules] = await Promise.all([
    TherapistAvailability.find({
      therapistId: { $in: therapistIds },
      isActive: true,
    }).lean(),

    User.find(
      {
        _id: { $in: therapistIds },
        role: "Therapist",
      },
      "fullName",
    ).lean(),

    Scheduling.find({
      therapistId: { $in: therapistIds },
      "appointments.date": {
        $gte: utcMidnight(from),
        $lte: utcMidnight(to),
      },
    })
      .populate("therapistId", "fullName")
      .populate("appointments.children.childId", "fullName")
      .lean(),
  ]);

  const names = new Map(
    users.map((u) => [String(u._id), u.fullName]),
  );

  const rulesBy = new Map(
    therapistIds.map((id) => [
      id,
      rules.filter((r) => String(r.therapistId) === id),
    ]),
  );

  const all = [];

  for (const p of plans) {
    const therapistId = String(p.therapistId);

    for (let date = from; date <= to; date = addDays(date, 1)) {
      const day = weekdayOf(date);

      for (const slot of p.slots) {
        if (slot.day !== day) continue;
        if (date === today && toMin(slot.startTime) <= nowMin) continue;
        all.push({
          therapistId,
          therapistName: names.get(therapistId) || "",
          speciality: p.speciality,
          date,
          startTime: slot.startTime,
          endTime: slot.endTime,
        });
      }
    }
  }

  const valid = [];
  const unavailable = [];

  for (const s of all) {
    const start = toMin(s.startTime);
    const end = toMin(s.endTime);

    const available = st.workingDays.includes(weekdayOf(s.date))
      && insideClinic(start, end, st)
      && availableOnDate(
        rulesBy.get(s.therapistId) || [],
        s.date,
        start,
        end,
      );

    (available ? valid : unavailable).push(s);
  }

  const byDate = {};

  for (const s of valid) {
    (byDate[s.date] ||= []).push(s);
  }

  for (const list of Object.values(byDate)) {
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];
        if (
          toMin(a.startTime) < toMin(b.endTime)
          && toMin(b.startTime) < toMin(a.endTime)
        ) {
          return {
            error: `${a.therapistName} (${to12(a.startTime)}) and ${b.therapistName} (${
              to12(b.startTime)
            }) overlap on ${a.date}. Pick different times.`,
          };
        }
      }
    }
  }

  const children = (batch.childrenIds || []).map(String);

  const busy = [];
  for (const sc of schedules) {
    for (const ap of sc.appointments || []) {
      busy.push({
        appointmentId: String(ap._id),
        therapistId: String(sc.therapistId?._id || sc.therapistId),
        therapistName: sc.therapistId?.fullName || "another therapist",

        children: (ap.children || []).map((child) => ({
          childId: String(child.childId?._id || child.childId),
          childName: child.childId?.fullName || "Child",
        })),

        date: dateKeyOf(ap.date),
        a: toMin(ap.startTime),
        b: toMin(ap.endTime),

        type: ap.type || null,
        batchId: ap.batchId ? String(ap.batchId) : null,
        batchAssignmentId: ap.batchAssignmentId
          ? String(ap.batchAssignmentId)
          : null,
      });
    }
  }

  const conflicts = [];
  const duplicates = [];
  const toCreate = [];

  const range = (a, b) => `${to12(minutesToTime(a))}-${to12(minutesToTime(b))}`;

  for (const s of valid) {
    const a = toMin(s.startTime);
    const b = toMin(s.endTime);

    const hits = busy.filter(
      (x) =>
        x.date === s.date
        && x.a < b
        && a < x.b,
    );

    if (
      hits.some(
        (x) => x.batchId === String(batch._id) && x.therapistId === s.therapistId && x.a === a && x.b === b,
      )
    ) {
      duplicates.push(s);
      continue;
    }

    const reasons = [];

    const therapistConflict = hits.find(
      (x) => x.therapistId === s.therapistId,
    );

    if (therapistConflict) {
      reasons.push(
        `${s.therapistName} already has a session at ${
          range(
            therapistConflict.a,
            therapistConflict.b,
          )
        }`,
      );
    }

    const childConflict = hits.find(
      (x) =>
        x.therapistId !== s.therapistId
        && x.children?.some((child) => children.includes(child.childId)),
    );

    if (childConflict) {
      const child = childConflict.children.find((child) => children.includes(child.childId));

      reasons.push(
        `${child?.childName || "A batch child"} already has a session with ${childConflict.therapistName} (${
          range(
            childConflict.a,
            childConflict.b,
          )
        })`,
      );
    }

    if (reasons.length) {
      conflicts.push({
        ...s,
        reasons,
      });
    } else {
      toCreate.push(s);
    }
  }

  return {
    plans,
    minutes,
    names,
    children,
    valid,
    unavailable,
    conflicts,
    duplicates,
    toCreate,
  };
};
const clockMinutes = (tz) => {
  const hhmm = new Date().toLocaleTimeString("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
  return toMin(hhmm);
};
const SLOT_STEP = 15;
const INACTIVE_TYPES = ["cancel", "postponed"];
const loadBatchAppointments = (batchId, extraMatch = {}) => {
  const id = new mongoose.Types.ObjectId(String(batchId));
  return Scheduling.aggregate([
    { $match: { "appointments.batchId": id } },
    { $unwind: "$appointments" },
    { $match: { "appointments.batchId": id, ...extraMatch } },
    {
      $replaceRoot: {
        newRoot: { $mergeObjects: ["$appointments", { therapistId: "$therapistId" }] },
      },
    },
  ]);
};
const computeFreeSlots = async ({
  therapistId,
  childIds = [],
  date,
  minutes,
  minDate = null,
  maxDate = null,
  step = SLOT_STEP,
  includeBooked = false,
}) => {
  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);

  if (!isValidDate(date)) return { error: "A valid date is required." };
  if (date < today) return { error: "Date cannot be in the past." };
  if ((minDate && date < minDate) || (maxDate && date > maxDate)) {
    return { error: "Date must be within the batch period." };
  }

  const day = weekdayOf(date);
  if (!st.workingDays.includes(day)) {
    return { slots: [], reason: `${day} is not a clinic working day.` };
  }
  const leaves = await loadTherapistLeaves(therapistId, date, date);
  if (onLeave(leaves, date)) {
    return { slots: [], onLeave: true, reason: LEAVE_MSG };
  }

  const children = childIds.map(String);
  const childObjIds = children.map((id) => new mongoose.Types.ObjectId(id));
  const therapistObjId = new mongoose.Types.ObjectId(therapistId);
  const dayStart = utcMidnight(date);
  const [year, month] = date.split("-").map(Number);

  const [rules, rows] = await Promise.all([
    TherapistAvailability.find({ therapistId, isActive: true }).lean(),
    Scheduling.aggregate([
      {
        $match: {
          $or: [
            { therapistId: therapistObjId, year, month },
            ...(childObjIds.length
              ? [
                  {
                    appointments: {
                      $elemMatch: {
                        date: dayStart,
                        "children.childId": { $in: childObjIds },
                      },
                    },
                  },
                ]
              : []),
          ],
        },
      },
      {
        $project: {
          therapistId: 1,
          appointments: {
            $filter: {
              input: "$appointments",
              as: "a",
              cond: { $eq: ["$$a.date", dayStart] },
            },
          },
        },
      },
      { $unwind: "$appointments" },
      {
        $project: {
          _id: 0,
          mine: { $eq: ["$therapistId", therapistObjId] },
          sessionType: "$appointments.sessionType",
          startTime: "$appointments.startTime",
          endTime: "$appointments.endTime",
          childIds: "$appointments.children.childId",
        },
      },
    ]),
  ]);

  const busy = [];
  for (const ap of rows) {
    if (INACTIVE_TYPES.includes(ap.sessionType)) continue;
    const hasChild = (ap.childIds || []).some((c) => children.includes(String(c)));
    if (ap.mine || hasChild) {
      busy.push({ a: toMin(ap.startTime), b: toMin(ap.endTime) });
    }
  }

  let nowMin = -1;
  if (date === today) nowMin = clockMinutes(st.tz);

  const slots = [];
  const seen = new Set();

  for (const r of rules) {
    let windows;
    if (r.type === "custom") {
      if (r.date !== date) continue;
      windows = [r];
    } else {
      if ((r.effectiveFrom && date < r.effectiveFrom) || (r.effectiveTo && date > r.effectiveTo)) {
        continue;
      }
      windows = (r.slots || []).filter((s) => s.day === day);
    }

    for (const w of windows) {
      for (let a = toMin(w.startTime); a + minutes <= toMin(w.endTime); a += step) {
        const b = a + minutes;
        if (seen.has(a)) continue;
        if (a <= nowMin) continue;
        if (!insideClinic(a, b, st)) continue;

        const isBusy = busy.some((x) => x.a < b && a < x.b);
        if (isBusy && !includeBooked) continue;

        seen.add(a);
        slots.push({
          startTime: minutesToTime(a),
          endTime: minutesToTime(b),
          ...(includeBooked && { booked: isBusy }),
        });
      }
    }
  }

  slots.sort((x, y) => x.startTime.localeCompare(y.startTime));

  return {
    slots,
    reason: !slots.length
      ? "No free time on this date. Try another day."
      : includeBooked && slots.every((s) => s.booked)
        ? "All times on this date are booked."
        : "",
  };
};
const freeSlotsForDate = ({ batch, therapistId, date, minutes }) =>
  computeFreeSlots({
    therapistId,
    childIds: batch.childrenIds || [],
    date,
    minutes,
    minDate: dateKeyOf(batch.dateFrom),
    maxDate: dateKeyOf(batch.dateTo),
  });
  const ensureTherapistChildren = (assignment, childIds) =>
    TherapistAssignment.updateOne(
      { therapistId: assignment.therapistId, specialty: assignment.speciality },
      { $addToSet: { childIds: { $each: childIds } } },
    );
const loadBatchAndAssignment = async (batchId, assignmentId) => {
  if (!mongoose.isValidObjectId(batchId) || !mongoose.isValidObjectId(assignmentId)) {
    return { status: 400, message: "Invalid batchId or assignmentId." };
  }
  const [batch, assignment] = await Promise.all([
    Batch.findById(batchId).lean(),
    BatchAssignment.findOne({ _id: assignmentId, batchId }).lean(),
  ]);
  if (!batch || !assignment) {
    return { status: 404, message: "Batch or assignment not found." };
  }
  return { batch, assignment };
};
const addBatchAppointment = async ({
  therapistId,
  date,
  startTime,
  endTime,
  batchId,
  assignmentId,
  sessionType,
  originalAppointmentId = null,
  childIds,
}) => {
  const d = utcMidnight(date);
  const year = d.getUTCFullYear();
  const month = d.getUTCMonth() + 1;

  let schedule = await Scheduling.findOne({ therapistId, year, month });
  if (!schedule) {
    schedule = new Scheduling({ therapistId, year, month, appointments: [] });
  }

  schedule.appointments.push({
    date: d,
    startTime,
    endTime,
    type: "batch",
    batchId,
    batchAssignmentId: assignmentId,
    sessionType,
    originalAppointmentId,
    children: childIds.map((childId) => ({ childId, attendance_status: "Pending" })),
  });

  await schedule.save(); // runs the overlap validation hook
  return schedule.appointments[schedule.appointments.length - 1];
};
const createExtraSession = async ({
  batch,
  assignment,
  date,
  startTime,
  endTime,
  sessionType,
  originalAppointmentId = null,
  childIds,
}) => {
  const appointment = await addBatchAppointment({
    therapistId: assignment.therapistId,
    date,
    startTime,
    endTime,
    batchId: batch._id,
    assignmentId: assignment._id,
    sessionType,
    originalAppointmentId,
    childIds,
  });
  return { appointmentId: appointment._id };
};
const resolvePackageAssignment = async (packageId, discountedPrice) => {
  if (packageId === null || packageId === "") {
    return { fields: { packageId: null, discountedPrice: null } };
  }

  if (!mongoose.isValidObjectId(packageId)) {
    return { status: 400, error: "Invalid package." };
  }

  const pkg = await Package.findById(packageId, "price").lean();
  if (!pkg) {
    return { status: 404, error: "Package not found." };
  }

  let discounted = null;

  if (discountedPrice !== undefined && discountedPrice !== null && discountedPrice !== "") {
    discounted = Number(discountedPrice);

    if (!Number.isFinite(discounted) || discounted <= 0) {
      return { status: 400, error: "Discount price must be greater than 0." };
    }
    if (discounted >= pkg.price) {
      return {
        status: 400,
        error: `Discount price must be less than the package rate (PKR ${pkg.price}).`,
      };
    }
  }

  return { fields: { packageId, discountedPrice: discounted } };
};
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "application/pdf"];

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) =>
    ALLOWED.includes(file.mimetype)
      ? cb(null, true)
      : cb(new Error("Only JPG, PNG, WEBP or PDF files are allowed.")),
}).single("file");



const defaultPermissions = {
  Admin: ["users:view", "users:create", "users:update", "users:delete", "reports:view"],
  Manager: ["users:view", "users:create", "users:update", "reports:view"],
  Therapist: ["therapistScreen"],
  // Parent: ["sessions:view"],
  Child: ["childScreen"],
};
exports.getAdminOverview = async (req, res) => {
  const userId = req.user.id || req.user._id;
  try {
    const [
      totalChild,
      therapistCount,
      totalUsers,
      leaveCount,
      unseenFeedbackCount,
      unreadNotificationCount,
      unreadMessageCount,
      unreadComplaintCount,
      totalMessageCount,
    ] = await Promise.all([
      User.countDocuments({ role: "Child" }),
      User.countDocuments({ role: "Therapist" }),
      User.countDocuments({}),
      
      LeaveRequest.countDocuments({
        "isSeen.userId": { $ne: userId },
      }),

      Feedback.countDocuments({
        "isSeen.userId": { $ne: userId },
      }),

      Notification.countDocuments({
        createdBy: { $ne: userId },
        "adminSeen.userId": { $ne: userId },
      }),

      Message.countDocuments({
        receiver: userId,
        isSeen: false,
      }),
      Complaint.countDocuments({
        "isSeen.userId": { $ne: userId },
      }),
      Conversation.countDocuments({
        participants: userId,
        deletedFor: { $ne: userId },
      }),
    ]);

    const sessionCount = 5;

    return res.status(200).json({
      success: true,
      data: {
        totalChild,
        therapistCount,
        totalUsers,
        sessionCount,
        leaveCount,
        unseenFeedbackCount,
        unreadNotificationCount,
        unreadMessageCount,
        unreadComplaintCount,
        totalMessageCount,
      },
    });
  } catch (error) {
    console.error("Error fetching admin overview stats:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch dashboard metrics.",
      error: error.message,
    });
  }
};


exports.getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = "", role = "all", status = "all" } = req.query;
    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(parseInt(limit, 10) || 10, 50);

    const filter = {};
    if (ROLES.includes(role)) filter.role = role;
    if (status === "active") filter.isActive = true;
    else if (status === "inactive") filter.isActive = false;

    const q = String(search).trim();
    if (q) {
      const rx = { $regex: escapeRegex(q), $options: "i" };
      filter.$or = [{ fullName: rx }, { email: rx }, { phone: rx }];
    }

    const [total, users, grouped, userPermissions, permissions, permissionGroups] = await Promise.all([
      User.countDocuments(filter),
      User.find(filter)
          .select(
            "fullName email phone role isActive isOnline profileImage createdAt address permissions " +
            "fatherName fatherCnic age gender diagnosis dateOfBirth documents packageId discountedPrice"
          )
          .populate("packageId", "name price type")
          .sort({ createdAt: -1 })
          .skip((pageNum - 1) * limitNum)
          .limit(limitNum)
          .lean(),
      User.aggregate([{ $group: { _id: "$role", count: { $sum: 1 } } }]),
      UserPermission.find({}).lean(),
      Permission.find({}).lean(),
      PermissionGroup.find({}).lean(),
    ]);
    const therapistIds = users.filter((u) => u.role === "Therapist").map((u) => u._id);
      if (therapistIds.length) {
        const assigns = await TherapistAssignment.find({ therapistId: { $in: therapistIds } })
          .select("therapistId specialty")
          .lean();

        const map = {};
        assigns.forEach((a) => {
          const key = String(a.therapistId);
          (map[key] = map[key] || []).push(a.specialty);
        });
        users.forEach((u) => {
          if (u.role === "Therapist") u.specialties = (map[String(u._id)] || []).filter(Boolean);
        });
      }

    const roleCounts = Object.fromEntries(grouped.map((g) => [g._id, g.count]));

    return res.status(200).json({
      success: true,
      data: users,
      userPermissions,
      permissions,
      permissionGroups,
      roleCounts,
      hasMore: pageNum * limitNum < total,
      totalCount: total,
    });
  } catch (error) {
    console.error("Get All Users Error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch users." });
  }
};
const PASSWORD_RX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,}$/;
const PHONE_RX = /^(03\d{9}|\+923\d{9})$/;

const normalizePhone = (p) =>
  p ? (p.startsWith("+92") ? "0" + p.slice(3) : p) : null;

exports.createAdmin = async (req, res) => {
  try {
    const { fullName, email, phone, address, password, isActive, permissions } = req.body;

    if (!fullName?.trim() || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Full name, email and password are required.",
      });
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
      return res.status(400).json({ success: false, message: "Enter a valid email address." });
    }
    const cleanPhone = phone?.trim() || "";

    if (cleanPhone && !PHONE_RX.test(cleanPhone)) {
      return res.status(400).json({
        success: false,
        message: "Phone number must be in 03011234567 or +923011234567 format.",
      });
    }
    if (!PASSWORD_RX.test(password)) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
      });
    }
    if (await User.exists({ email: cleanEmail })) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }

    const user = await User.create({
      fullName: fullName.trim(),
      email: cleanEmail,
      phone: normalizePhone(cleanPhone),
      address: address?.trim() || null,
      password: await bcrypt.hash(password, 10),
      role: "Admin",
      agreeTerms: true,
      isActive: isActive ?? true,
      permissions: Array.isArray(permissions) ? permissions : [],
    });

    const data = user.toObject();
    delete data.password;

    try {
      await sendEmail({
        to: user.email,
        subject: "Your Admin Account Has Been Created - Healer",
        html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">
          <h2 style="color: #2563eb;">Welcome to Healer!</h2>
          <p>Dear ${user.fullName},</p>
          <p>An administrator account has been created for you with this email address. Please use the password shared with you by your administrator to sign in.</p>
          <p>Best regards,<br/>Healer Team</p></div>`,
      });
    } catch (e) {
      console.error("Admin welcome email failed:", e.message);
    }

    return res.status(201).json({ success: true, message: "Admin created successfully.", data });
  } catch (error) {
    console.error("Create Admin Error:", error);
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }
    return res.status(500).json({ success: false, message: "Failed to create admin." });
  }
};
exports.updateAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const { fullName, email, phone, address, password, isActive } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid admin id." });
    }
    if (isActive === false && String(req.user.id || req.user._id) === id) {
      return res.status(400).json({ success: false, message: "You cannot deactivate your own account." });
    }

    const user = await User.findOne({ _id: id, role: "Admin" });
    if (!user) return res.status(404).json({ success: false, message: "Admin not found." });

    if (fullName?.trim()) user.fullName = fullName.trim();
    if (address !== undefined) user.address = address?.trim() || null;

    if (email) {
      const cleanEmail = email.trim().toLowerCase();
      if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
        return res.status(400).json({ success: false, message: "Enter a valid email address." });
      }
      if (await User.exists({ _id: { $ne: id }, email: cleanEmail })) {
        return res.status(409).json({ success: false, message: "An account with this email already exists." });
      }
      user.email = cleanEmail;
    }
    if (phone !== undefined) {
      const cleanPhone = phone?.trim() || "";

      if (cleanPhone && !PHONE_RX.test(cleanPhone)) {
        return res.status(400).json({
          success: false,
          message: "Phone number must be in 03011234567 or +923011234567 format.",
        });
      }

      user.phone = normalizePhone(cleanPhone);
    }
    if (password) {
      if (!PASSWORD_RX.test(password)) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
        });
      }
      user.password = await bcrypt.hash(password, 10);
    }
    if (typeof isActive === "boolean") user.isActive = isActive;

    await user.save();
    const data = user.toObject();
    delete data.password;
    return res.status(200).json({ success: true, message: "Admin updated successfully.", data });
  } catch (error) {
    console.error("Update Admin Error:", error);
    return res.status(500).json({ success: false, message: "Failed to update admin." });
  }
};
exports.deleteAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid admin id." });
    }
    if (String(req.user.id || req.user._id) === id) {
      return res.status(400).json({ success: false, message: "You cannot delete your own account." });
    }

    const user = await User.findOne({ _id: id, role: "Admin" });
    if (!user) return res.status(404).json({ success: false, message: "Admin not found." });

    const adminCount = await User.countDocuments({ role: "Admin" });
    if (adminCount <= 1) {
      return res.status(400).json({ success: false, message: "You cannot delete the last admin." });
    }

    await User.deleteOne({ _id: id });
    return res.status(200).json({ success: true, deleted: true, message: "Admin deleted." });
  } catch (error) {
    console.error("Delete Admin Error:", error);
    return res.status(500).json({ success: false, message: "Failed to delete admin." });
  }
};

exports.createManager = async (req, res) => {
  try {
    const { fullName, email, phone, address, password, isActive } = req.body;

    if (!fullName?.trim() || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Full name, email and password are required.",
      });
    }
    const cleanEmail = email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
      return res.status(400).json({ success: false, message: "Enter a valid email address." });
    }
    const cleanPhone = phone?.trim() || "";

    if (cleanPhone && !PHONE_RX.test(cleanPhone)) {
      return res.status(400).json({
        success: false,
        message: "Phone number must be in 03011234567 or +923011234567 format.",
      });
    }
    if (!PASSWORD_RX.test(password)) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
      });
    }
    if (await User.exists({ email: cleanEmail })) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }
    const groupIds = cleanGroupIds(req.body.groupIds);
    const groupError = await validateGroupIds(groupIds);
    if (groupError) {
      return res.status(400).json({ success: false, message: groupError });
    }
    const user = await User.create({
      fullName: fullName.trim(),
      email: cleanEmail,
      phone: normalizePhone(cleanPhone),
      address: address?.trim() || null,
      password: await bcrypt.hash(password, 10),
      role: "Manager",
      agreeTerms: true,
      isActive: isActive ?? true,
    });
    try {
      await replaceManagerGroups(user._id, groupIds, req.user?._id || req.user?.id);
    } catch (e) {
      await User.deleteOne({ _id: user._id });
      throw e;                                
    }
    const data = user.toObject();
    delete data.password;

    try {
      await sendEmail({
        to: user.email,
        subject: "Your Manager Account Has Been Created - Healer",
        html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">
          <h2 style="color: #2563eb;">Welcome to Healer!</h2>
          <p>Dear ${user.fullName},</p>
          <p>An manager account has been created for you with this email address. Please use the password shared with you by your manager to sign in.</p>
          <p>Best regards,<br/>Healer Team</p></div>`,
      });
    } catch (e) {
      console.error("Manager welcome email failed:", e.message);
    }

    return res.status(201).json({ success: true, message: "Manager created successfully.", data });
  } catch (error) {
    console.error("Create Manager Error:", error);
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }
    return res.status(500).json({ success: false, message: "Failed to create manager." });
  }
};
exports.updateManager = async (req, res) => {
  try {
    const { id } = req.params;
    const { fullName, email, phone, address, password, isActive, groupIds: rawGroupIds } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid manager id." });
    }
    if (isActive === false && String(req.user.id || req.user._id) === id) {
      return res.status(400).json({ success: false, message: "You cannot deactivate your own account." });
    }

    const user = await User.findOne({ _id: id, role: "Manager" });
    if (!user) return res.status(404).json({ success: false, message: "Manager not found." });
    const groupIds = rawGroupIds === undefined ? null : cleanGroupIds(rawGroupIds);
    if (groupIds) {
      const groupError = await validateGroupIds(groupIds);
      if (groupError) return res.status(400).json({ success: false, message: groupError });
    }
    if (fullName?.trim()) user.fullName = fullName.trim();
    if (address !== undefined) user.address = address?.trim() || null;

    if (email) {
      const cleanEmail = email.trim().toLowerCase();
      if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
        return res.status(400).json({ success: false, message: "Enter a valid email address." });
      }
      if (await User.exists({ _id: { $ne: id }, email: cleanEmail })) {
        return res.status(409).json({ success: false, message: "An account with this email already exists." });
      }
      user.email = cleanEmail;
    }
    if (phone !== undefined) {
      const cleanPhone = phone?.trim() || "";

      if (cleanPhone && !PHONE_RX.test(cleanPhone)) {
        return res.status(400).json({
          success: false,
          message: "Phone number must be in 03011234567 or +923011234567 format.",
        });
      }

      user.phone = normalizePhone(cleanPhone);
    }
    if (password) {
      if (!PASSWORD_RX.test(password)) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
        });
      }
      user.password = await bcrypt.hash(password, 10);
    }
    if (typeof isActive === "boolean") user.isActive = isActive;

    await user.save();
    if (groupIds) await replaceManagerGroups(user._id, groupIds, req.user?._id || req.user?.id);
    const data = user.toObject();
    delete data.password;
    return res.status(200).json({ success: true, message: "Manager updated successfully.", data });
  } catch (error) {
    console.error("Update Manager Error:", error);
    return res.status(500).json({ success: false, message: "Failed to update manager." });
  }
};
exports.deleteManager = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid manager id." });
    }
    if (String(req.user.id || req.user._id) === id) {
      return res.status(400).json({ success: false, message: "You cannot delete your own account." });
    }

    const user = await User.findOne({ _id: id, role: "Manager" });
    if (!user) return res.status(404).json({ success: false, message: "Manager not found." });

    const managerCount = await User.countDocuments({ role: "Manager" });
    if (managerCount <= 1) {
      return res.status(400).json({ success: false, message: "You cannot delete the last manager." });
    }

    await User.deleteOne({ _id: id });
    return res.status(200).json({ success: true, deleted: true, message: "Manager deleted." });
  } catch (error) {
    console.error("Delete Manager Error:", error);
    return res.status(500).json({ success: false, message: "Failed to delete manager." });
  }
};

exports.getProgramTherapists = async (req, res) => {
  try {
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.min(
      Math.max(Number(req.query.limit) || 5, 1),
      50,
    );
    const search = String(req.query.search || "").trim();

    const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    const pipeline = [
      {
        $lookup: {
          from: "users",
          localField: "therapistId",
          foreignField: "_id",
          as: "therapist",
        },
      },
      { $unwind: "$therapist" },
      {
        $match: {
          "therapist.role": "Therapist",
          "therapist.isActive": true,
        },
      },
      {
        $group: {
          _id: "$therapist._id",
          fullName: { $first: "$therapist.fullName" },
          email: { $first: "$therapist.email" },
          profileImage: { $first: "$therapist.profileImage" },
          isActive: { $first: "$therapist.isActive" },
        },
      },
    ];

    if (search) {
      const regex = escapeRegex(search);

      pipeline.push({
        $match: {
          $or: [
            { fullName: { $regex: regex, $options: "i" } },
            { email: { $regex: regex, $options: "i" } },
          ],
        },
      });
    }

    pipeline.push(
      { $sort: { fullName: 1, _id: 1 } },
      {
        $facet: {
          metadata: [{ $count: "total" }],
          data: [
            { $skip: (page - 1) * limit },
            { $limit: limit },
            {
              $project: {
                _id: 0,
                therapistId: { $toString: "$_id" },
                fullName: 1,
                email: 1,
                profileImage: 1,
                isActive: 1,
              },
            },
          ],
        },
      },
    );

    const [result] = await TherapistAssignment.aggregate(pipeline);

    const data = result?.data || [];
    const total = result?.metadata?.[0]?.total || 0;

    return res.status(200).json({
      success: true,
      page,
      limit,
      total,
      count: data.length,
      hasMore: page * limit < total,
      data,
    });
  } catch (error) {
    console.error("getProgramTherapists:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch therapists.",
    });
  }
};

exports.getProgramTherapistChildren = async (req, res) => {
  try {
    const { therapistId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(therapistId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid therapist ID.",
      });
    }

    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.min(
      Math.max(Number(req.query.limit) || 5, 1),
      50,
    );
    const search = String(req.query.search || "").trim();

    const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    const therapistObjectId = new mongoose.Types.ObjectId(therapistId);

    const pipeline = [
      {
        $match: {
          therapistId: therapistObjectId,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "therapistId",
          foreignField: "_id",
          as: "therapist",
        },
      },
      { $unwind: "$therapist" },
      {
        $match: {
          "therapist.role": "Therapist",
          "therapist.isActive": true,
        },
      },
      { $unwind: "$childIds" },
      {
        $lookup: {
          from: "users",
          localField: "childIds",
          foreignField: "_id",
          as: "child",
        },
      },
      { $unwind: "$child" },
      {
        $match: {
          "child.role": "Child",
          "child.isActive": true,
        },
      },
      {
        $group: {
          _id: "$child._id",
          fullName: { $first: "$child.fullName" },
          email: { $first: "$child.email" },
          profileImage: { $first: "$child.profileImage" },
          isActive: { $first: "$child.isActive" },
        },
      },
    ];

    if (search) {
      const regex = escapeRegex(search);

      pipeline.push({
        $match: {
          $or: [
            { fullName: { $regex: regex, $options: "i" } },
            { email: { $regex: regex, $options: "i" } },
          ],
        },
      });
    }

    pipeline.push(
      { $sort: { fullName: 1, _id: 1 } },
      {
        $facet: {
          metadata: [{ $count: "total" }],
          data: [
            { $skip: (page - 1) * limit },
            { $limit: limit },
            {
              $project: {
                _id: 0,
                childId: { $toString: "$_id" },
                fullName: 1,
                email: 1,
                profileImage: 1,
                isActive: 1,
              },
            },
          ],
        },
      },
    );

    const [result] = await TherapistAssignment.aggregate(pipeline);

    const data = result?.data || [];
    const total = result?.metadata?.[0]?.total || 0;

    return res.status(200).json({
      success: true,
      page,
      limit,
      total,
      count: data.length,
      hasMore: page * limit < total,
      data,
    });
  } catch (error) {
    console.error("getProgramTherapistChildren:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch assigned children.",
    });
  }
};

// exports.assignTherapistsUsers = async (req, res) => {
//   try {
//     const page = Math.max(
//       parseInt(req.query.page, 10) || 1,
//       1,
//     );

//     const limit = Math.max(
//       parseInt(req.query.limit, 10) || 10,
//       1,
//     );

//     const skip = (page - 1) * limit;

//     const {
//       search,
//       specialty,
//     } = req.query;

//     const matchStage = {};

//     if (
//       specialty
//       && specialty !== "All"
//     ) {
//       matchStage.specialty = specialty;
//     }

//     const pipeline = [
//       {
//         $match: matchStage,
//       },
//       {
//         $lookup: {
//           from: "users",
//           localField: "therapistId",
//           foreignField: "_id",
//           as: "therapist",
//         },
//       },
//       {
//         $unwind: "$therapist",
//       },
//       {
//         $unwind: "$childIds",
//       },
//       {
//         $lookup: {
//           from: "users",
//           localField: "childIds",
//           foreignField: "_id",
//           as: "child",
//         },
//       },
//       {
//         $unwind: "$child",
//       },
//       {
//         $match: {
//           "therapist.role": "Therapist",
//         },
//       },
//     ];

//     if (search?.trim()) {
//       const searchText = search.trim();

//       pipeline.push({
//         $match: {
//           $or: [
//             {
//               "child.fullName": {
//                 $regex: searchText,
//                 $options: "i",
//               },
//             },
//             {
//               "child.email": {
//                 $regex: searchText,
//                 $options: "i",
//               },
//             },
//             {
//               "therapist.fullName": {
//                 $regex: searchText,
//                 $options: "i",
//               },
//             },
//             {
//               "therapist.email": {
//                 $regex: searchText,
//                 $options: "i",
//               },
//             },
//           ],
//         },
//       });
//     }

//     pipeline.push(
//       {
//         $sort: {
//           "therapist.fullName": 1,
//           "child.fullName": 1,
//         },
//       },
//       {
//         $facet: {
//           metadata: [
//             {
//               $count: "total",
//             },
//           ],
//           data: [
//             {
//               $skip: skip,
//             },
//             {
//               $limit: limit,
//             },
//             {
//               $project: {
//                 _id: 0,
//                 assignmentId: {
//                   $toString: "$_id",
//                 },
//                 childId: {
//                   $toString: "$child._id",
//                 },
//                 childName: {
//                   $ifNull: [
//                     "$child.fullName",
//                     "$child.name",
//                   ],
//                 },
//                 childEmail: {
//                   $ifNull: [
//                     "$child.email",
//                     "",
//                   ],
//                 },
//                 childPhone: {
//                   $ifNull: [
//                     "$child.phone",
//                     "",
//                   ],
//                 },
//                 childProfileImage: {
//                   $ifNull: [
//                     "$child.profileImage",
//                     "",
//                   ],
//                 },
//                 therapistId: {
//                   $toString: "$therapist._id",
//                 },
//                 therapistName: {
//                   $ifNull: [
//                     "$therapist.fullName",
//                     "$therapist.name",
//                   ],
//                 },
//                 therapistEmail: {
//                   $ifNull: [
//                     "$therapist.email",
//                     "",
//                   ],
//                 },
//                 therapistPhone: {
//                   $ifNull: [
//                     "$therapist.phone",
//                     "",
//                   ],
//                 },
//                 therapistProfileImage: {
//                   $ifNull: [
//                     "$therapist.profileImage",
//                     "",
//                   ],
//                 },
//                 specialty: 1,
//                 maxChildren: 1,
//                 assignedChildren: {
//                   $size: {
//                     $ifNull: [
//                       "$childIdsOriginal",
//                       [],
//                     ],
//                   },
//                 },
//                 combinedName: {
//                   $concat: [
//                     {
//                       $ifNull: [
//                         "$child.fullName",
//                         "$child.name",
//                       ],
//                     },
//                     " - ",
//                     {
//                       $ifNull: [
//                         "$therapist.fullName",
//                         "$therapist.name",
//                       ],
//                     },
//                   ],
//                 },
//               },
//             },
//           ],
//         },
//       },
//     );

//     pipeline.splice(1, 0, {
//       $set: {
//         childIdsOriginal: {
//           $cond: [
//             {
//               $isArray: "$childIds",
//             },
//             "$childIds",
//             [],
//           ],
//         },
//       },
//     });

//     const result = await TherapistAssignment.aggregate(
//       pipeline,
//     );

//     const data = result[0]?.data || [];

//     const total = result[0]?.metadata?.[0]?.total
//       || 0;

//     const specialties = await TherapistAssignment.distinct(
//       "specialty",
//     );

//     return res.status(200).json({
//       success: true,
//       page,
//       limit,
//       total,
//       count: data.length,
//       hasMore: skip + data.length < total,
//       data,
//       specialties,
//     });
//   } catch (error) {
//     console.error(
//       "Get Therapist Users Error:",
//       error,
//     );

//     return res.status(500).json({
//       success: false,
//       message: "Failed to get therapist users",
//       error: error.message,
//     });
//   }
// };

exports.assignTherapistsUsers = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit, 10) || 10, 1);
    const skip = (page - 1) * limit;

    const { search, specialty } = req.query;

    const matchStage = {};

    if (specialty && specialty !== "All") {
      matchStage.specialty = specialty;
    }

    const pipeline = [
      { $match: matchStage },

      // Get therapist details
      {
        $lookup: {
          from: "users",
          localField: "therapistId",
          foreignField: "_id",
          as: "therapist",
        },
      },
      { $unwind: "$therapist" },

      // Only active therapists
      {
        $match: {
          "therapist.role": "Therapist",
          "therapist.isActive": true,
        },
      },

      // Get assigned children
      {
        $lookup: {
          from: "users",
          let: { ids: { $ifNull: ["$childIds", []] } },
          pipeline: [
            {
              $match: {
                $expr: { $in: ["$_id", "$$ids"] },
                role: "Child",
                isActive: true,
              },
            },
            {
              $project: {
                _id: 1,
                fullName: 1,
                email: 1,
                phone: 1,
                profileImage: 1,
                isActive: 1,
              },
            },
          ],
          as: "children",
        },
      },

      // Group assignments by therapist
      {
        $group: {
          _id: "$therapist._id",
          therapist: { $first: "$therapist" },
          assignments: {
            $push: {
              assignmentId: "$_id",
              specialty: "$specialty",
              maxChildren: "$maxChildren",
              children: "$children",
            },
          },
        },
      },

      // Merge children from all assignments
      {
        $project: {
          therapist: 1,
          assignments: 1,
          allChildren: {
            $reduce: {
              input: "$assignments",
              initialValue: [],
              in: {
                $concatArrays: ["$$value", "$$this.children"],
              },
            },
          },
        },
      },

      // Remove duplicate children
      {
        $set: {
          children: {
            $reduce: {
              input: "$allChildren",
              initialValue: [],
              in: {
                $cond: [
                  {
                    $in: [
                      "$$this._id",
                      {
                        $map: {
                          input: "$$value",
                          as: "child",
                          in: "$$child._id",
                        },
                      },
                    ],
                  },
                  "$$value",
                  { $concatArrays: ["$$value", ["$$this"]] },
                ],
              },
            },
          },
        },
      },

      // Output therapist with children array
      {
        $project: {
          _id: 0,
          therapistId: { $toString: "$therapist._id" },
          therapistName: "$therapist.fullName",
          therapistEmail: {
            $ifNull: ["$therapist.email", ""],
          },
          therapistPhone: {
            $ifNull: ["$therapist.phone", ""],
          },
          therapistProfileImage: {
            $ifNull: ["$therapist.profileImage", ""],
          },
          therapistIsActive: "$therapist.isActive",
          specialties: "$assignments.specialty",
          maxChildren: { $sum: "$assignments.maxChildren" },
          assignedChildren: { $size: "$children" },
          children: 1,
        },
      },
    ];

    if (search?.trim()) {
      const searchText = search.trim().replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
      );

      pipeline.push({
        $match: {
          $or: [
            {
              therapistName: {
                $regex: searchText,
                $options: "i",
              },
            },
            {
              therapistEmail: {
                $regex: searchText,
                $options: "i",
              },
            },
            {
              "children.fullName": {
                $regex: searchText,
                $options: "i",
              },
            },
            {
              "children.email": {
                $regex: searchText,
                $options: "i",
              },
            },
          ],
        },
      });
    }

    pipeline.push(
      { $sort: { therapistName: 1 } },
      {
        $facet: {
          metadata: [{ $count: "total" }],
          data: [{ $skip: skip }, { $limit: limit }],
        },
      },
    );

    const result = await TherapistAssignment.aggregate(pipeline);

    const data = result[0]?.data || [];
    const total = result[0]?.metadata?.[0]?.total || 0;

    const specialties = await TherapistAssignment.distinct(
      "specialty",
    );

    return res.status(200).json({
      success: true,
      page,
      limit,
      total,
      count: data.length,
      hasMore: skip + data.length < total,
      data,
      specialties,
    });
  } catch (error) {
    console.error("Get Therapist Users Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to get therapist users",
      error: error.message,
    });
  }
};
const sendEmailSafely = async (emailData) => {
  try {
    await sendEmail(emailData);
    return true;
  } catch (error) {
    console.error("Email sending failed:", error.message);
    return false;
  }
};
exports.getTherapistsUsers = async (req, res) => {
  try {
    const userId = req.user.id || req.user._id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 5;
    const skip = (page - 1) * limit;
    const { search, specialty, status } = req.query;

    const matchStage = { role: "Therapist" };

    if (search) {
      const regex = escapeRegex(search);
      matchStage.$or = [
        { fullName: { $regex: regex, $options: "i" } },
        { email: { $regex: regex, $options: "i" } },
      ];
    }
    if (status === "active") {
      matchStage.isActive = true;
    } else if (status === "inactive") {
      matchStage.isActive = false;
    }
    const pipeline = [
      { $match: matchStage },
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "therapistassignments",
          let: { userId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: [{ $toObjectId: "$therapistId" }, "$$userId"] },
              },
            },
          ],
          as: "assignments",
        },
      },
      {
        $lookup: {
          from: "conversations",
          let: { therapistId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $in: [
                        new mongoose.Types.ObjectId(userId),
                        "$participants",
                      ],
                    },
                    { $in: ["$$therapistId", "$participants"] },
                    { $eq: [{ $size: "$participants" }, 2] },
                  ],
                },
              },
            },
            { $project: { _id: 1 } },
            { $limit: 1 },
          ],
          as: "conversation",
        },
      },
      {
        $project: {
          fullName: 1,
          email: 1,
          phone: 1,
          role: 1,
          profileImage:1,
          isOnline:1,
          lastActive:1,
          isLogin: 1,
          createdAt: 1,
          isActive: 1,
          specialties: "$assignments.specialty",
          maxChildren: { $max: "$assignments.maxChildren" },
          conversationId: {
            $ifNull: [
              { $arrayElemAt: ["$conversation._id", 0] },
              null,
            ],
          },
          assignedChildren: {
            $sum: {
              $map: {
                input: "$assignments",
                as: "a",
                in: { $size: { $ifNull: ["$$a.childIds", []] } },
              },
            },
          },
        },
      },
    ];

    if (specialty && specialty !== "All") {
      pipeline.push({
        $match: { specialties: specialty },
      });
    }

    pipeline.push({ $skip: skip }, { $limit: limit });

    const therapists = await User.aggregate(pipeline);
    const specialties = await TherapistAssignment.distinct("specialty");

    return res.status(200).json({
      success: true,
      page,
      count: therapists.length,
      hasMore: therapists.length === limit,
      data: therapists,
      specialties: specialties,
    });
  } catch (error) {
    console.log("Get Therapists Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to get therapists",
      error: error.message,
    });
  }
};
exports.createTherapist = async (req, res) => {
  try {
    const { name, specialty, email, phone, address, password, isActive } = req.body;

    if (!name || !email || !password || !specialty) {
      return res.status(400).json({
        success: false,
        message: "Name, email, specialty and password are required.",
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(normalizedEmail)) {
      return res.status(400).json({
        success: false,
        message: "Please enter a valid email address.",
      });
    }

    const existingUser = await User.findOne({
      email: normalizedEmail,
    }).lean();

    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists.",
      });
    }

    let normalizedPhone = "";

    if (phone && phone.trim()) {
      const phoneTrimmed = phone.trim();
      const phoneRegex = /^(03\d{9}|\+923\d{9})$/;

      if (!phoneRegex.test(phoneTrimmed)) {
        return res.status(400).json({
          success: false,
          message: "Phone number must be in 03011234567 or +923011234567 format.",
        });
      }

      normalizedPhone = phoneTrimmed.startsWith("+92")
        ? "0" + phoneTrimmed.slice(3)
        : phoneTrimmed;
    }

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,}$/;

    if (!passwordRegex.test(password)) {
      return res.status(400).json({
        success: false,
        message:
          "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      fullName: name,
      email: normalizedEmail,
      phone: normalizedPhone,
      address,
      role: "Therapist",
      password: hashedPassword,
      agreeTerms: true,
      isActive,
    });

    const assignment = await TherapistAssignment.create({
      therapistId: user._id,
      specialty: specialty || "",
      childIds: [],
    });

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">
        <h2 style="color: #2563eb;">Welcome to Healer!</h2>
        <p>Dear ${name},</p>
        <p>Your account has been successfully created.</p>
        <div style="background: #f3f4f6; padding: 16px; border-radius: 8px;">
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${normalizedEmail}</p>
        </div>
        <p>If you need assistance, please contact our support team.</p>
        <p>Best regards,<br/>Healer Team</p>
      </div>
    `;

    const emailSent = await sendEmailSafely({
      to: normalizedEmail,
      subject: "Your Account Has Been Created - Healer",
      html,
    });

    return res.status(201).json({
      success: true,
      emailSent,
      message: "Therapist created successfully.",
      data: {
        id: user._id,
        name: user.fullName,
        email: user.email,
        phone: user.phone,
        address: user.address,
        specialty: assignment.specialty,
        currentLoad: 0,
        isActive,
      },
    });

  } catch (error) {
    if (error.code === 11000 && error.keyPattern?.email) {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists.",
      });
    }

    console.error("Create Therapist Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create therapist.",
    });
  }
};
exports.updateTherapist = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, specialty, maxChildren, email, phone, address, password, isActive } = req.body;
    if (
      isActive !== undefined
      && isActive !== true
      && isActive !== false
    ) {
      return res.status(400).json({
        success: false,
        message: "isActive must be true or false.",
      });
    }
    const user = await User.findOne({ _id: id, role: "Therapist" });
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "Therapist not found." });
    }
    if (email) {
      const normalizedEmail = email.trim().toLowerCase();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(normalizedEmail)) {
        return res
          .status(400)
          .json({
            success: false,
            message: "Please enter a valid email address.",
          });
      }

      const existingUser = await User.findOne({
        _id: { $ne: id },
        email: { $regex: new RegExp(`^${normalizedEmail}$`, "i") },
      });
      if (existingUser) {
        return res
          .status(400)
          .json({
            success: false,
            message: "An account with this email already exists.",
          });
      }
      user.email = normalizedEmail;
    }
    if (phone !== undefined) {
      if (phone.trim() === "") {
        user.phone = "";
      } else {
        const phoneTrimmed = phone.trim();
        const phoneRegex = /^(03\d{9}|\+923\d{9})$/;

        if (!phoneRegex.test(phoneTrimmed)) {
          return res.status(400).json({
            success: false,
            message: "Phone number must be in 03011234567 or +923011234567 format.",
          });
        }

        user.phone = phoneTrimmed.startsWith("+92")
          ? "0" + phoneTrimmed.slice(3)
          : phoneTrimmed;
      }
    }
    if (password) {
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.status(400).json({
          success: false,
          message:
            "Password must be at least 8 characters and contain 1 lowercase, 1 uppercase, and 1 special character.",
        });
      }
      user.password = await bcrypt.hash(password, 10);
    }

    if (name) user.fullName = name;
    if (email) user.email = email;
    if (phone) user.phone = phone;
    if (address) user.address = address;

    const now = new Date();
    if (isActive === false && user.isActive !== false) {
      const startOfToday = new Date(now);
      startOfToday.setHours(0, 0, 0, 0);

      const runningBatch = await Batch.findOne({
        therapistIds: user._id,
        dateFrom: { $lte: now },
        dateTo: { $gte: startOfToday },
      })
        .select("name dateFrom dateTo")
        .lean();

      if (runningBatch) {
        return res.status(409).json({
          success: false,
          message: "Therapist is in a current running batch, so they cannot be made inactive.",
          batch: runningBatch,
        });
      }

      const schedules = await Scheduling.find({ therapistId: user._id });

      for (const schedule of schedules) {
        schedule.appointments = schedule.appointments.filter((appt) => {
          const apptTime = new Date(appt.date);
          const [h = 0, m = 0] = String(appt.startTime || "00:00").split(":").map(Number);
          apptTime.setHours(h, m, 0, 0);

          if (apptTime < now) return true;
          return Boolean(appt.batchId);
        });

        if (schedule.appointments.length === 0) {
          await Scheduling.deleteOne({ _id: schedule._id });
        } else {
          await schedule.save();
        }
      }
    }

    if (isActive !== undefined) user.isActive = isActive;
    await user.save();

    let assignment = await TherapistAssignment.findOne({ therapistId: id });
    if (assignment) {
      if (specialty !== undefined) assignment.specialty = specialty;
      if (maxChildren !== undefined) {
        assignment.maxChildren = parseInt(maxChildren, 10);
      }
      await assignment.save();
    } else {
      assignment = await TherapistAssignment.create({
        therapistId: user._id,
        specialty: specialty || "",
        maxChildren: maxChildren ? parseInt(maxChildren, 10) : 15,
        childIds: [],
      });
    }

    return res.status(200).json({
      success: true,
      data: {
        id: user._id,
        name: user.fullName,
        email: user.email,
        phone: user.phone,
        address: user.address,
        specialty: assignment?.specialty,
        maxChildren: assignment?.maxChildren,
        isActive,
      },
    });
  } catch (error) {
    console.error("Update Therapist Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to update therapist.",
      error: error.message,
    });
  }
};
exports.deleteTherapist = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findOne({ _id: id, role: "Therapist" });
    if (!user) {
      return res.status(404).json({ success: false, message: "Therapist not found." });
    }

    const now = new Date();
    const startOfToday = new Date(now);
    startOfToday.setHours(0, 0, 0, 0);

    const runningBatch = await Batch.findOne({
      therapistIds: user._id,
      dateFrom: { $lte: now },
      dateTo: { $gte: startOfToday },
    })
      .select("name dateFrom dateTo")
      .lean();

    if (runningBatch) {
      return res.status(409).json({
        success: false,
        message: "Therapist is in a current running batch, so they cannot be deleted.",
        batch: runningBatch,
      });
    }

    const schedules = await Scheduling.find({ therapistId: user._id });
    let hasPastAppointments = false;

    for (const schedule of schedules) {
      schedule.appointments = schedule.appointments.filter((appt) => {
        const apptTime = new Date(appt.date);
        const [h = 0, m = 0] = String(appt.startTime || "00:00").split(":").map(Number);
        apptTime.setHours(h, m, 0, 0);

        if (apptTime < now) {
          hasPastAppointments = true;
          return true;
        }
        return Boolean(appt.batchId);
      });
    }

    const hasBatchHistory = await Batch.exists({ therapistIds: user._id });

    if (hasPastAppointments || hasBatchHistory) {
      for (const schedule of schedules) {
        if (schedule.appointments.length === 0) {
          await Scheduling.deleteOne({ _id: schedule._id });
        } else {
          await schedule.save();
        }
      }

      user.isActive = false;
      await user.save();
      const html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">

            <p>Dear ${user?.fullName},</p>

            <p>
              Your account has been deactivated.
              You will no longer be able to access your account.
            </p>

            <p>If you need assistance, please contact our support team.</p>

            <p>Best regards,<br/>Healer Team</p>
          </div>
        `
      const emailSent = await sendEmailSafely({
        to: user?.email,
        subject: "Your Account Has Been Deactivated - Healer",
        html: html,
      });
      return res.status(200).json({
        success: true,
        deactivated: true,
        emailSent,
        message: "This therapist has past appointments or batch history, so they were marked inactive instead of deleted.",
      });
    }

    await Scheduling.deleteMany({ therapistId: user._id });
    await TherapistAssignment.deleteOne({ therapistId: user._id });
    await User.deleteOne({ _id: user._id });
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">

          <p>Dear ${user?.fullName},</p>

          <p>
            Your account has been deleted.
            You will no longer be able to access your account.
          </p>

          <p>If you need assistance, please contact our support team.</p>

          <p>Best regards,<br/>Healer Team</p>
        </div>
      `
    const emailSent = await sendEmailSafely({
      to: user?.email,
      subject: "Your Account Has Been Deleted - Healer",
      html: html,
    });
    return res.status(200).json({
      success: true,
      deleted: true,
      emailSent,
      message: "Therapist deleted successfully.",
    });
  } catch (error) {
    console.error("Delete Therapist Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete therapist.",
      error: error?.message || "Unknown server error",
    });
  }
};
exports.assignChildrenToTherapist = async (req, res) => {
  try {
    const { therapistId } = req.body;
    const addChildIds = Array.isArray(req.body.addChildIds)
      ? req.body.addChildIds
      : [];
    const removeChildIds = Array.isArray(req.body.removeChildIds)
      ? req.body.removeChildIds
      : [];

    if (
      !therapistId
      || (addChildIds.length === 0 && removeChildIds.length === 0)
    ) {
      return res.status(400).json({
        success: false,
        message: "therapistId and at least one of addChildIds/removeChildIds are required.",
      });
    }

    const uniqueAddIds = [...new Set(addChildIds.map((id) => id.toString()))];
    const uniqueRemoveIds = [
      ...new Set(removeChildIds.map((id) => id.toString())),
    ];

    const therapist = await User.findOne({
      _id: therapistId,
      role: "Therapist",
    });
    if (!therapist) {
      return res
        .status(404)
        .json({ success: false, message: "Therapist not found." });
    }

    let assignment = await TherapistAssignment.findOne({ therapistId });

    if (!assignment) {
      if (uniqueAddIds.length === 0) {
        return res.status(200).json({
          success: true,
          message: "Nothing to update — no existing assignment and no children to add.",
          data: {
            therapistId,
            currentLoad: 0,
            maxChildren: 0,
            addedIds: [],
            removedIds: [],
          },
        });
      }

      const maxChildren = therapist.maxChildren || 0;

      if (uniqueAddIds.length > maxChildren) {
        return res.status(400).json({
          success: false,
          message:
            `This therapist can have a maximum of ${maxChildren} children. You tried to assign ${uniqueAddIds.length}.`,
          data: {
            therapistId,
            requestedChildren: uniqueAddIds.length,
            maxChildren,
            availableSlots: maxChildren,
          },
        });
      }

      assignment = await TherapistAssignment.create({
        therapistId,
        childIds: uniqueAddIds,
        specialty: therapist.specialty || "General",
        maxChildren,
      });

      return res.status(201).json({
        success: true,
        message: `${uniqueAddIds.length} child(ren) assigned successfully.`,
        data: {
          therapistId,
          childIds: assignment.childIds,
          currentLoad: assignment.childIds.length,
          maxChildren: assignment.maxChildren,
          availableSlots: assignment.maxChildren - assignment.childIds.length,
          addedIds: uniqueAddIds,
          removedIds: [],
          alreadyAssigned: 0,
          notAssigned: 0,
        },
      });
    }

    const existing = new Set(assignment.childIds.map((c) => c.toString()));
    const maxChildren = assignment.maxChildren;

    const toRemove = uniqueRemoveIds.filter((id) => existing.has(id));
    const notAssignedForRemoval = uniqueRemoveIds.filter(
      (id) => !existing.has(id),
    );

    const toAdd = uniqueAddIds.filter(
      (id) => !existing.has(id) && !toRemove.includes(id),
    );
    const alreadyAssignedIds = uniqueAddIds.filter(
      (id) => existing.has(id) && !toRemove.includes(id),
    );

    const currentLoad = assignment.childIds.length;
    const projectedLoad = currentLoad - toRemove.length + toAdd.length;

    if (projectedLoad > maxChildren) {
      const availableSlots = Math.max(
        maxChildren - (currentLoad - toRemove.length),
        0,
      );
      return res.status(400).json({
        success: false,
        message:
          `Only ${availableSlots} slot(s) available for this therapist after removals. You tried to add ${toAdd.length} new child(ren).`,
        data: {
          therapistId,
          currentLoad,
          maxChildren,
          availableSlots,
          attemptedToAdd: toAdd.length,
          attemptedToRemove: toRemove.length,
        },
      });
    }

    if (toAdd.length === 0 && toRemove.length === 0) {
      return res.status(200).json({
        success: true,
        message: "No changes made — selected children already reflect the current state.",
        data: {
          therapistId,
          childIds: assignment.childIds,
          currentLoad,
          maxChildren,
          availableSlots: maxChildren - currentLoad,
          alreadyAssigned: alreadyAssignedIds.length,
          notAssigned: notAssignedForRemoval.length,
          addedIds: [],
          removedIds: [],
        },
      });
    }

    assignment.childIds = assignment.childIds.filter(
      (c) => !toRemove.includes(c.toString()),
    );
    assignment.childIds.push(...toAdd);

    await assignment.save();

    const messageParts = [];
    if (toAdd.length > 0) messageParts.push(`${toAdd.length} child(ren) added`);
    if (toRemove.length > 0) {
      messageParts.push(`${toRemove.length} child(ren) removed`);
    }
    if (alreadyAssignedIds.length > 0) {
      messageParts.push(`${alreadyAssignedIds.length} were already assigned`);
    }
    if (notAssignedForRemoval.length > 0) {
      messageParts.push(`${notAssignedForRemoval.length} were not assigned`);
    }

    return res.status(200).json({
      success: true,
      message: messageParts.join(", ") + ".",
      data: {
        therapistId,
        childIds: assignment.childIds,
        currentLoad: assignment.childIds.length,
        maxChildren,
        availableSlots: maxChildren - assignment.childIds.length,
        addedIds: toAdd,
        removedIds: toRemove,
        alreadyAssigned: alreadyAssignedIds.length,
        notAssigned: notAssignedForRemoval.length,
      },
    });
  } catch (error) {
    console.error("Assign/Unassign Children Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to update child assignments.",
      error: error.message,
    });
  }
};


const pad2 = (n) => String(n).padStart(2, "0");
const mapSession = (ap, { today, nowMin, therapistId, fallbackSpec }) => {
  const date = ap.dateKey; 
  const isCustom = ap.type === "custom";
  const isPast = date < today || (date === today && toMin(ap.endTime) <= nowMin);
  return {
    id: String(ap._id),
    date,
    startTime: ap.startTime,
    endTime: ap.endTime,
    therapistId,
    type: ap.type,
    sessionType: ap.sessionType || "regular",
    batchId: ap.batchId?._id ? String(ap.batchId._id) : ap.batchId ? String(ap.batchId) : null,
    batchName: isCustom ? "Appointment with" : (ap.batchId?.batchName || "Batch Session"),
    speciality: ap.batchAssignmentId?.speciality || fallbackSpec || null,
    children: (ap.children || []).map((c) => ({
      childId: String(c.childId?._id || c.childId),
      fullName: c.childId?.fullName || "Child",
      attendance: c.attendance_status || "Pending",
    })),
    isPast,
    canCancel: isCustom && !isPast && !INACTIVE_TYPES.includes(ap.sessionType),
    canPostpone: isCustom && !isPast && !INACTIVE_TYPES.includes(ap.sessionType),
  };
};
const baseSessionStages = (therapistId, tz) => [
  { $match: { therapistId: new mongoose.Types.ObjectId(therapistId) } },
  { $unwind: "$appointments" },
  {
    $addFields: {
      "appointments.dateKey": {
        $dateToString: { format: "%Y-%m-%d", date: "$appointments.date", timezone: tz },
      },
    },
  },
  {
    $addFields: {
      "appointments.endKey": {
        $concat: ["$appointments.dateKey", " ", "$appointments.endTime"],
      },
    },
  },
];
exports.getTherapistSchedule = async (req, res) => {
  try {
    const { therapistId } = req.params;

    if (!mongoose.isValidObjectId(therapistId)) {
      return res.status(400).json({ success: false, message: "Invalid therapistId." });
    }

    const therapist = await User.findOne(
      { _id: therapistId, role: "Therapist" },
      "fullName email phone isActive",
    ).lean();

    if (!therapist) {
      return res.status(404).json({ success: false, message: "Therapist not found." });
    }

    const pastDays = Math.min(Math.max(parseInt(req.query.pastDays, 10) || 90, 1), 365);

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const nowMin = clockMinutes(st.tz);
    const cutoff = addDays(today, -pastDays);

    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const section = ["upcoming", "past"].includes(req.query.section) ? req.query.section : null;

    const nowKey = `${today} ${pad2(Math.floor(nowMin / 60))}:${pad2(nowMin % 60)}`;
    const base = baseSessionStages(therapistId, st.tz);

    const fetchSection = async (sec, pg, fallbackSpec) => {
      const isUp = sec === "upcoming";

      const rows = await Scheduling.aggregate([
        ...base,
        {
          $match: isUp
            ? { "appointments.endKey": { $gt: nowKey } }
            : {
                "appointments.endKey": { $lte: nowKey },
                "appointments.dateKey": { $gte: cutoff },
              },
        },
        { $sort: { "appointments.dateKey": isUp ? 1 : -1, "appointments.startTime": isUp ? 1 : -1 } },
        { $skip: (pg - 1) * limit },
        { $limit: limit + 1 },
        { $project: { appointments: 1 } },
      ]);

      const hasMore = rows.length > limit;
      const pageRows = rows.slice(0, limit);

      await Scheduling.populate(pageRows, [
        { path: "appointments.batchId", select: "batchName" },
        { path: "appointments.batchAssignmentId", select: "speciality" },
        { path: "appointments.children.childId", select: "fullName" },
      ]);

      const items = pageRows.map((r) =>
        mapSession(r.appointments, { today, nowMin, therapistId, fallbackSpec })
      );
      return { items, hasMore };
    };

    if (section) {
      const assignments = await TherapistAssignment.find({ therapistId }, "specialty").lean();
      const { items, hasMore } = await fetchSection(section, page, assignments[0]?.specialty);
      return res.json({ success: true, data: { section, page, hasMore, items } });
    }

    const [availability, assignments, countRows, pastCountRows] = await Promise.all([
      TherapistAvailability.find({ therapistId, isActive: true })
        .sort({ type: -1, date: 1, createdAt: 1 })
        .lean(),
      TherapistAssignment.find({ therapistId }, "specialty").lean(),

      Scheduling.aggregate([
        ...base,
        {
          $match: {
            "appointments.endKey": { $gt: nowKey },
            "appointments.sessionType": { $nin: INACTIVE_TYPES },
          },
        },
        { $count: "n" },
      ]),

      Scheduling.aggregate([
        ...base,
        {
          $match: {
            "appointments.endKey": { $lte: nowKey },
            "appointments.dateKey": { $gte: cutoff },
            "appointments.sessionType": { $nin: INACTIVE_TYPES },
          },
        },
        { $count: "n" },
      ]),
    ]);

    const upcoming = await fetchSection("upcoming", 1, assignments[0]?.specialty);

    return res.json({
      success: true,
      data: {
        today,
        pastDays,
        therapist: {
          _id: therapist._id,
          fullName: therapist.fullName,
          email: therapist.email,
          phone: therapist.phone,
          isActive: therapist.isActive,
          specialties: [...new Set(assignments.map((a) => a.specialty).filter(Boolean))],
        },
        availability,
        upcomingTotal: countRows[0]?.n || 0,
        pastTotal: pastCountRows[0]?.n || 0,
        upcoming,
      },
    });
  } catch (error) {
    console.error("getTherapistSchedule:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load therapist schedule.",
      error: error.message,
    });
  }
};

exports.childUsers = async (req, res) => {
  try {
    const adminId = req.user.id || req.user._id;
    const { page = 1, limit = 5, search = "", status = "active" } = req.query;
    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(parseInt(limit, 10) || 5, 50);

    const filter = { role: "Child" };
    const q = search.trim();
    if (q) {
      filter.fullName = {
        $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
        $options: "i",
      };
    }
    if (status === "active") filter.isActive = true;
    else if (status === "inactive") filter.isActive = false;

    const [totalCount, children] = await Promise.all([
      User.countDocuments(filter),
      User.find(filter, {
        fullName: 1, fatherName: 1, fatherCnic: 1, age: 1, email: 1, phone: 1,
        packageId: 1, discountedPrice: 1, isActive: 1,
        dateOfBirth: 1, gender: 1, diagnosis: 1, documents: 1, address: 1,
        profileImage: 1, isOnline: 1, lastActive: 1,
      })
        .populate("packageId", "name price type")
        .sort({ createdAt: -1 })
        .skip((pageNum - 1) * limitNum)
        .limit(limitNum)
        .lean(),
    ]);

    const adminObjectId = new mongoose.Types.ObjectId(adminId);
    const childIds = children.map((c) => c._id);

    const conversations = childIds.length
      ? await Conversation.find({
          $and: [
            { participants: adminObjectId },
            { participants: { $in: childIds } },
            { participants: { $size: 2 } },
          ],
        })
          .select("_id participants")
          .lean()
      : [];

    const conversationByChild = {};
    for (const conv of conversations) {
      const other = conv.participants.find(
        (p) => String(p) !== String(adminObjectId),
      );
      if (other) conversationByChild[String(other)] = conv._id;
    }

    const data = children.map((child) => ({
      ...child,
      conversationId: conversationByChild[String(child._id)] ?? null,
    }));

    return res.status(200).json({
      success: true,
      data,
      hasMore: pageNum * limitNum < totalCount,
      totalCount,
    });
  } catch (error) {
    console.error("Fetch Children Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch children.",
      error: error.message,
    });
  }
};
exports.createChild = async (req, res) => {
  try {
    const {
      fullName, fatherName, fatherCnic, dateOfBirth, gender, diagnosis,
      email, phone, password, packageId, discountedPrice, isActive, documents, address,
    } = req.body;

    const cleanEmail = typeof email === "string" ? email.trim().toLowerCase() : "";

    if (!fullName?.trim() || !cleanEmail || !password || !fatherName || !fatherCnic) {
      return res.status(400).json({
        success: false,
        message: "fullName, email, parent name, parent CNIC and password are required.",
      });
    }
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
      return res.status(400).json({ success: false, message: "Enter a valid email address." });
    }
    let normalizedPhone = "";

    if (phone && phone.trim()) {
      const phoneTrimmed = phone.trim();
      const phoneRegex = /^(03\d{9}|\+923\d{9})$/;

      if (!phoneRegex.test(phoneTrimmed)) {
        return res.status(400).json({
          success: false,
          message: "Phone number must be in 03011234567 or +923011234567 format.",
        });
      }

      normalizedPhone = phoneTrimmed.startsWith("+92")
        ? "0" + phoneTrimmed.slice(3)
        : phoneTrimmed;
    }
    let dob = null;

    if (dateOfBirth) {
      dob = new Date(dateOfBirth);

      if (isNaN(dob.getTime()) || dob > new Date()) {
        return res.status(400).json({
          success: false,
          message: "Enter a valid date of birth.",
        });
      }
    }
    if (!["Male", "Female"].includes(gender)) {
      return res.status(400).json({ success: false, message: "Gender must be Male or Female." });
    }

    const cnic = normalizeCnic(fatherCnic);
    if (!cnic) {
      return res.status(400).json({ success: false, message: "CNIC must be 13 digits." });
    }

    const [existParent, hashedPassword] = await Promise.all([
      User.findOne({ fatherCnic: cnic, role: "Child" }).select("fatherName").lean(),
      bcrypt.hash(password, 10),
    ]);

    if (existParent && normalizeName(existParent.fatherName) !== normalizeName(fatherName)) {
      return res.status(409).json({
        success: false,
        message: "This parent CNIC already exists with a different parent name.",
      });
    }

    let packageFields = { packageId: null, discountedPrice: null };
    if (packageId) {
      const r = await resolvePackageAssignment(packageId, discountedPrice);
      if (r.error) {
        return res.status(r.status).json({ success: false, message: r.error });
      }
      packageFields = r.fields;
    }

    const child = await User.create({
      fullName: fullName.trim(),
      fatherName,
      fatherCnic: cnic,
      dateOfBirth: dob,
      age: dob ? calcAge(dob) : null,
      gender,
      diagnosis: (diagnosis || "").trim(),
      email: cleanEmail,
      phone: normalizedPhone,
      address,
      password: hashedPassword,
      role: "Child",
      agreeTerms: true,
      isActive: isActive ?? false,
      documents: sanitizeDocuments(documents),
      ...packageFields,
    });
    await confirmDocuments(child.documents);
    const data = child.toObject();
    delete data.password;
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">
          <h2 style="color: #2563eb;">Welcome to Healer!</h2>

          <p>Dear ${fullName},</p>

          <p>
            Your account has been successfully created.
            You can now use your registered credentials to access your account.
          </p>

          <div style="background: #f3f4f6; padding: 16px; border-radius: 8px;">
            <p><strong>Name:</strong> ${fullName}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Password:</strong> ${password}</p>
          </div>

          <p>If you need assistance, please contact our support team.</p>

          <p>Best regards,<br/>Healer Team</p>
        </div>
      `
    await sendEmail({
      to: child.email,
      subject: "Your Account Has Been Created - Healer",
      html: html,
    });
    return res.status(201).json({
      success: true,
      message: "Child created successfully.",
      data,
    });
  } catch (error) {
    console.error("Create Child Error:", error);

    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern || {})[0];
      return res.status(409).json({
        success: false,
        message: `A user with this ${field} already exists.`,
      });
    }
    return res.status(500).json({
      success: false,
      message: "Failed to create child.",
      error: error.message,
    });
  }
};
exports.updateChild = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      fullName, fatherName, fatherCnic, dateOfBirth, gender, diagnosis, age,
      email, phone, password, packageId, discountedPrice, isActive, documents, address,
    } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid child id." });
    }
    if (!fullName || !email) {
      return res.status(400).json({
        success: false,
        message: "fullName and email are required.",
      });
    }
    if (isActive !== undefined && typeof isActive !== "boolean") {
      return res.status(400).json({
        success: false,
        message: "isActive must be true or false.",
      });
    }
    let dob;
    if (dateOfBirth) {
      dob = new Date(dateOfBirth);
      if (isNaN(dob.getTime()) || dob > new Date()) {
        return res.status(400).json({ success: false, message: "Enter a valid date of birth." });
      }
    }

    const cleanGender = gender === "" ? null : gender;
    if (cleanGender !== undefined && cleanGender !== null && !["Male", "Female"].includes(cleanGender)) {
      return res.status(400).json({ success: false, message: "Gender must be Male or Female." });
    }

    const currentChild = await User.findOne({ _id: id, role: "Child" })
      .select("fatherName fatherCnic")
      .lean();

    if (!currentChild) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }

    let cnic;
    if (fatherCnic) {
      cnic = normalizeCnic(fatherCnic);
      if (!cnic) {
        return res.status(400).json({
          success: false,
          message: "CNIC must be 13 digits.",
        });
      }
    }

    if (cnic || fatherName !== undefined) {
      const targetCnic = cnic || currentChild.fatherCnic;
      const targetName =
        fatherName !== undefined ? fatherName : currentChild.fatherName;

      if (targetCnic) {
        const others = await User.find({
          role: "Child",
          fatherCnic: targetCnic,
          _id: { $ne: id },
        })
          .select("fatherName")
          .lean();

        if (
          others.some(
            (c) => normalizeName(c.fatherName) !== normalizeName(targetName)
          )
        ) {
          return res.status(409).json({
            success: false,
            message: "This parent CNIC already exists with a different parent name.",
          });
        }
      }
    }
    let normalizedPhone;

    if (phone !== undefined) {
      if (typeof phone !== "string") {
        return res.status(400).json({
          success: false,
          message: "Phone number must be a valid string.",
        });
      }

      if (phone.trim() === "") {
        normalizedPhone = "";
      } else {
        const phoneTrimmed = phone.trim();
        const phoneRegex = /^(03\d{9}|\+923\d{9})$/;

        if (!phoneRegex.test(phoneTrimmed)) {
          return res.status(400).json({
            success: false,
            message: "Phone number must be in 03011234567 or +923011234567 format.",
          });
        }

        normalizedPhone = phoneTrimmed.startsWith("+92")
          ? "0" + phoneTrimmed.slice(3)
          : phoneTrimmed;
      }
    }

    const updateFields = {
      fullName: fullName.trim(),
      email: email,
      ...(normalizedPhone !== undefined && { phone: normalizedPhone }),
      ...(address !== undefined && { address }),
      ...(fatherName !== undefined && { fatherName }),
      ...(cnic && { fatherCnic: cnic }),
      ...(dob && { dateOfBirth: dob, age: calcAge(dob) }),
      ...(!dob && age !== undefined && { age }),
      ...(cleanGender !== undefined && { gender: cleanGender }),
      ...(diagnosis !== undefined && { diagnosis: String(diagnosis).trim() }),
      ...(isActive !== undefined && { isActive }),
    };

    let newDocs;
    if (documents !== undefined) {
      newDocs = sanitizeDocuments(documents);
      updateFields.documents = newDocs;
    }

    if (packageId !== undefined) {
      const r = await resolvePackageAssignment(packageId, discountedPrice);
      if (r.error) {
        return res.status(r.status).json({ success: false, message: r.error });
      }
      Object.assign(updateFields, r.fields);
    }

    if (password) {
      updateFields.password = await bcrypt.hash(password, 10);
    }

    const childId = new mongoose.Types.ObjectId(id);
    const now = new Date();

    if (isActive === false) {
      const activeBatch = await Batch.findOne({
        childrenIds: childId,
        dateFrom: { $lte: now },
        dateTo: { $gte: now },
      })
        .select("batchName")
        .lean();

      if (activeBatch) {
        return res.status(400).json({
          success: false,
          message:
            "Child cannot be deactivated because the child is already in an active running batch.",
          batchId: activeBatch._id,
          batchName: activeBatch.batchName,
        });
      }
    }

    const child = await User.findOneAndUpdate(
      { _id: id, role: "Child" },
      updateFields,
      { new: true, runValidators: true }
    ).select("-password");

    if (!child) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }
    if (newDocs) {
      confirmDocuments(newDocs);
      destroyDocuments(removedDocuments(currentChild.documents, newDocs));
    }

    if (isActive === false) {
      await Scheduling.updateMany(
        {
          appointments: {
            $elemMatch: { date: { $gte: now }, "children.childId": childId },
          },
        },
        [
          {
            $set: {
              updatedAt: now,
              appointments: {
                $filter: {
                  input: {
                    $map: {
                      input: "$appointments",
                      as: "a",
                      in: {
                        $cond: [
                          { $gte: ["$$a.date", now] },
                          {
                            $mergeObjects: [
                              "$$a",
                              {
                                children: {
                                  $filter: {
                                    input: "$$a.children",
                                    as: "c",
                                    cond: { $ne: ["$$c.childId", childId] },
                                  },
                                },
                              },
                            ],
                          },
                          "$$a",
                        ],
                      },
                    },
                  },
                  as: "a",
                  cond: {
                    $not: [
                      {
                        $and: [
                          { $gte: ["$$a.date", now] },
                          { $eq: ["$$a.type", "custom"] },
                          { $eq: [{ $size: "$$a.children" }, 0] },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          },
        ]
      );

      await Scheduling.deleteMany({ appointments: { $size: 0 } });
    }

    return res.status(200).json({
      success: true,
      message:
        isActive === false
          ? "Child deactivated successfully and removed from future appointments."
          : isActive === true
            ? "Child activated successfully."
            : "Child updated successfully.",
      data: child,
    });
  } catch (error) {
    console.error("Update Child Error:", error);

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "A user with this email already exists.",
      });
    }
    return res.status(500).json({
      success: false,
      message: "Failed to update child.",
      error: error.message,
    });
  }
};
exports.deleteChild = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid child id." });
    }
    const childId = new mongoose.Types.ObjectId(id);
    const now = new Date();

    const [child, activeBatch] = await Promise.all([
      User.findOne({ _id: childId, role: "Child" }).select("documents fullName email").lean(),
      Batch.findOne({
        childrenIds: childId,
        dateFrom: { $lte: now },
        dateTo: { $gte: now },
      })
        .select("batchName")
        .lean(),
    ]);

    if (!child) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }

    if (activeBatch) {
      return res.status(400).json({
        success: false,
        message: "Child is already in an active running batch.",
        batchId: activeBatch._id,
        batchName: activeBatch.batchName,
      });
    }

    const [, hasPastData] = await Promise.all([
      Scheduling.updateMany(
        {
          appointments: {
            $elemMatch: { date: { $gte: now }, "children.childId": childId },
          },
        },
        [
          {
            $set: {
              updatedAt: now,
              appointments: {
                $filter: {
                  input: {
                    $map: {
                      input: "$appointments",
                      as: "a",
                      in: {
                        $cond: [
                          { $gte: ["$$a.date", now] },
                          {
                            $mergeObjects: [
                              "$$a",
                              {
                                children: {
                                  $filter: {
                                    input: "$$a.children",
                                    as: "c",
                                    cond: { $ne: ["$$c.childId", childId] },
                                  },
                                },
                              },
                            ],
                          },
                          "$$a",
                        ],
                      },
                    },
                  },
                  as: "a",
                  cond: {
                    $not: [
                      {
                        $and: [
                          { $gte: ["$$a.date", now] },
                          { $eq: ["$$a.type", "custom"] },
                          { $eq: [{ $size: "$$a.children" }, 0] },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          },
        ],
        { updatePipeline: true },
      ),
      Scheduling.exists({
        appointments: {
          $elemMatch: { date: { $lt: now }, "children.childId": childId },
        },
      }),
    ]);

    await Scheduling.deleteMany({ appointments: { $size: 0 } });

    if (hasPastData) {
      await User.updateOne({ _id: childId }, { $set: { isActive: false } });
      const html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">

            <p>Dear ${child?.fullName},</p>

            <p>
              Your account has been deactivated.
              You will no longer be able to access your account.
            </p>

            <p>If you need assistance, please contact our support team.</p>

            <p>Best regards,<br/>Healer Team</p>
          </div>
        `
      await sendEmail({
        to: child?.email,
        subject: "Your Account Has Been Deactivated - Healer",
        html: html,
      });
      return res.status(200).json({
        success: true,
        message:
          "Child has past records, so the child was deactivated and removed from future appointments.",
        deleted: false,
      });
    }

    await Promise.all([
      Batch.updateMany({ childrenIds: childId }, { $pull: { childrenIds: childId } }),
      BatchAssignment.updateMany({ childIds: childId }, { $pull: { childIds: childId } }),
      User.deleteOne({ _id: childId, role: "Child" }),
      destroyDocuments(Object.values(child.documents || {}).filter(Boolean)),
    ]);
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px; color: #333;">

          <p>Dear ${child?.fullName},</p>

          <p>
            Your account has been deleted.
            You will no longer be able to access your account.
          </p>

          <p>If you need assistance, please contact our support team.</p>

          <p>Best regards,<br/>Healer Team</p>
        </div>
      `
    await sendEmail({
      to: child?.email,
      subject: "Your Account Has Been Deleted - Healer",
      html: html,
    });
    return res.status(200).json({
      success: true,
      message: "Child deleted permanently (no past records found).",
      deleted: true,
    });
  } catch (error) {
    console.error("Delete Child Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete child.",
      error: error.message,
    });
  }
};
exports.uploadChildDocument = (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({
        success: false,
        message: err.code === "LIMIT_FILE_SIZE" ? "Max file size is 5 MB." : err.message,
      });
    }
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded." });
    }

    try {
      const result = await new Promise((resolve, reject) => {
        cloudinary.uploader
          .upload_stream(
            { folder: "healers/child-documents", resource_type: "auto", tags: ["pending"] },
            (e, r) => (e ? reject(e) : resolve(r))
          )
          .end(req.file.buffer);
      });

      return res.status(201).json({
        success: true,
        data: {
          url: result.secure_url,
          publicId: result.public_id,
          resourceType: result.resource_type || "image",
          name: req.file.originalname,
          type: req.file.mimetype === "application/pdf" ? "pdf" : "image",
        },
      });
    } catch (error) {
      console.error("Upload Child Document Error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to upload file.",
        error: error.message,
      });
    }
  });
};


const getOnLeaveToday = async () => {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date();
  end.setHours(23, 59, 59, 999);

  const docs = await LeaveRequest.find({
    status: "approved",
    startDate: { $lte: end },
    endDate: { $gte: start },
  })
    .populate("applicantId", "fullName role")
    .sort({ endDate: 1 });

  const seen = new Set();
  return docs.filter((d) => {
    if (!d.applicantId) return false;
    const key = String(d.applicantId._id);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};
exports.getLeaveRequests = async (req, res) => {
  try {
    const userId = req.user.id || req.user._id;
    const { status = "pending", page = 1, limit = 10 } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);

    const filter = {};
    const tab = status.toLowerCase();

    if (tab === "pending") filter.status = "pending";
    else if (tab === "approved") filter.status = "approved";
    else if (tab === "rejected") filter.status = "rejected";

    const totalCount = await LeaveRequest.countDocuments(filter);

    const requests = await LeaveRequest.find(filter)
      .populate("applicantId", "fullName role")
      .populate("approved_by", "fullName")
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);
    // if (requests.length > 0) {
    //   const requestIds = requests.map((r) => r._id);
    //   await LeaveRequest.updateMany(
    //     {
    //       _id: { $in: requestIds },
    //       "isSeen.userId": { $ne: userId },
    //     },
    //     {
    //       $addToSet: {
    //         isSeen: { userId, seenAt: new Date() },
    //       },
    //     }
    //   );
    // }

    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const [pendingCount, pendingSinceYesterday, onLeaveDocs] = await Promise.all([
      LeaveRequest.countDocuments({ status: "pending" }),
      LeaveRequest.countDocuments({
        status: "pending",
        createdAt: { $gte: yesterday },
      }),
      getOnLeaveToday(),
    ]);
    await LeaveRequest.updateMany(
      {
        "isSeen.userId": { $ne: userId },
      },
      {
        $addToSet: {
          isSeen: { userId, seenAt: new Date() },
        },
      }
    );
    return res.status(200).json({
      success: true,
      data: requests,
      hasMore: pageNum * limitNum < totalCount,
      totalCount,
      stats: {
        pendingCount,
        pendingSinceYesterday,
        onLeaveToday: onLeaveDocs.length,
        onLeaveNames: onLeaveDocs.map((d) => d.applicantId.fullName),
      },
    });
  } catch (error) {
    console.error("Fetch Leave Requests Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch leave requests.",
      error: error.message,
    });
  }
};
const cancelSessionsForLeave = async (therapistId, startDate, endDate) => {
  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);
  const nowMin = clockMinutes(st.tz);

  const startKey = dateKeyOf(startDate);
  const from = startKey < today ? today : startKey;
  const to = dateKeyOf(endDate);
  if (to < from) return { count: 0, childIds: [] };

  const schedules = await Scheduling.find({
    therapistId,
    appointments: {
      $elemMatch: { date: { $gte: utcMidnight(from), $lte: utcMidnight(to) } },
    },
  });

  let count = 0;
  const childIds = new Set();

  for (const sc of schedules) {
    let changed = false;
    for (const ap of sc.appointments) {
      if (INACTIVE_TYPES.includes(ap.sessionType)) continue;
      
      const date = dateKeyOf(ap.date);
      if (date < from || date > to) continue;
      if (date === today && toMin(ap.endTime) <= nowMin) continue;
      ap.sessionType = "cancel";
      ap.therapist_attendance = "cancel";
      (ap.children || []).forEach((c) => childIds.add(String(c.childId)));
      count++;
      changed = true;
    }
    if (changed) await sc.save();
  }

  return { count, childIds: [...childIds] };
};
exports.approveLeaveRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const adminId = req.user?.id;
    
    const leaveRequest = await LeaveRequest.findById(id);

    if (!leaveRequest) {
      return res.json({
        success: false,
        message: "Leave request not found.",
      });
    }

    if (leaveRequest.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: `This request has already been ${leaveRequest.status}.`,
      });
    }

    leaveRequest.status = "approved";
    leaveRequest.approved_by = adminId || null;
    leaveRequest.actionedAt = new Date();
    leaveRequest.rejectionReason = "";

    await leaveRequest.save();
    let cancelled = { count: 0, childIds: [] };
    if (leaveRequest.role === "Therapist") {
      cancelled = await cancelSessionsForLeave(
        leaveRequest.applicantId,
        leaveRequest.startDate,
        leaveRequest.endDate,
      );
      const childMessage = cancelled.count > 0
      ? `Your ${cancelled.count} upcoming session(s) have been cancelled because the therapist is on leave.`
      : "";
      if (cancelled.childIds.length && childMessage) {
        await sendNotifications({
          title: "Session Cancelled",
          message: childMessage,
          type: "Appointment",
          audience: "users",
          users: cancelled.childIds,
          createdBy: adminId,
          sendPush: true,
        });
      }
    }
    const message = cancelled.count > 0
      ? `Your leave request has been approved. ${cancelled.count} upcoming session(s) have been cancelled during your leave period.`
      : "Your leave request has been approved.";

    if (leaveRequest?.applicantId) {
      await sendNotifications({
        title: "Leave Request Approved",
        message: message,
        type: "Reminder",
        audience: "users",
        users: [String(leaveRequest?.applicantId)],
        createdBy: adminId,
        sendPush: true,
      });
    }
    return res.status(200).json({
      success: true,
      message: "Leave request approved successfully.",
      data: leaveRequest,
    });
  } catch (error) {
    console.error("Approve Leave Request Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to approve leave request.",
      error: error.message,
    });
  }
};
exports.rejectLeaveRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { rejectionReason } = req.body;
    const adminId = req.user?.id;

    if (!rejectionReason || !rejectionReason.trim()) {
      return res.status(400).json({
        success: false,
        message: "A rejection reason is required.",
      });
    }

    const leaveRequest = await LeaveRequest.findById(id);

    if (!leaveRequest) {
      return res.json({
        success: false,
        message: "Leave request not found.",
      });
    }

    if (leaveRequest.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: `This request has already been ${leaveRequest.status}.`,
      });
    }

    leaveRequest.status = "rejected";
    leaveRequest.rejectionReason = rejectionReason.trim();
    leaveRequest.approved_by = adminId || null;
    leaveRequest.actionedAt = new Date();

    await leaveRequest.save();
    if (leaveRequest?.applicantId) {
      await sendNotifications({
        title: "Leave Request Rejected",
        message: `Your leave request has been rejected. Reason: ${rejectionReason.trim()}`,
        type: "Reminder",
        audience: "users",
        users: [String(leaveRequest?.applicantId)],
        createdBy: adminId,
        sendPush: true,
      });
    }
    return res.status(200).json({
      success: true,
      message: "Leave request rejected.",
      data: leaveRequest,
    });
  } catch (error) {
    console.error("Reject Leave Request Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to reject leave request.",
      error: error.message,
    });
  }
};
// exports.markAllLeavesSeen = async (req, res) => {
//   try {
//     const result = await LeaveRequest.updateMany(
//       {
//         $or: [
//           { isSeen: false },
//           { isSeen: { $exists: false } },
//         ],
//       },
//       {
//         $set: { isSeen: true },
//       },
//     );

//     return res.status(200).json({
//       success: true,
//       message: "All leave requests marked as seen.",
//       modifiedCount: result.modifiedCount,
//     });
//   } catch (error) {
//     console.error("Error marking leaves as seen:", error);

//     return res.status(500).json({
//       success: false,
//       message: "Failed to mark leave requests as seen.",
//     });
//   }
// };
exports.getStaffOnLeaveToday = async (req, res) => {
  try {
    const pageNum = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limitNum = Math.max(parseInt(req.query.limit, 10) || 10, 1);

    const all = await getOnLeaveToday();
    const start = (pageNum - 1) * limitNum;
    const data = all.slice(start, start + limitNum);

    return res.status(200).json({
      success: true,
      data,
      hasMore: start + limitNum < all.length,
      totalCount: all.length,
    });
  } catch (error) {
    console.error("Staff On Leave Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch staff on leave.",
      error: error.message,
    });
  }
};

exports.getAdminFeedbackManagement = async (req, res) => {
  try {
    const { status } = req.params;
    const userId = req.user.id || req.user._id;
    if (!["all", "pending", "new"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status. Use all, pending, or new.",
      });
    }

    const now = new Date();

    // =========================================================
    // 1. STATS
    // =========================================================

    const startOfYesterday = new Date();
    startOfYesterday.setDate(startOfYesterday.getDate() - 1);
    startOfYesterday.setHours(0, 0, 0, 0);

    const [ratingResult, sinceYesterdayFeedback] = await Promise.all([
      Feedback.aggregate([
        {
          $group: {
            _id: null,
            averageRating: {
              $avg: "$rating",
            },
          },
        },
      ]),

      Feedback.countDocuments({
        createdAt: {
          $gte: startOfYesterday,
        },
        notes: {
          $nin: [null, ""],
        },
      }),
    ]);

    const averageSatisfaction = ratingResult.length
      ? Number(ratingResult[0].averageRating.toFixed(1))
      : 0;

    // =========================================================
    // 2. FETCH FEEDBACK ONCE
    // =========================================================
    //
    // We don't add any appointmentId index.
    // We simply load the fields we actually need.
    //
    // =========================================================

    const feedbacks = await Feedback.find(
      {
        notes: {
          $nin: [null, ""],
        },
      },
      {
        appointmentId: 1,
        therapistId: 1,
        rating: 1,
        notes: 1,
        replies: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    )
      .populate("therapistId", "fullName email role")
      .lean()
      .sort({ createdAt: -1 });

    // =========================================================
    // 3. CREATE FEEDBACK MAP
    // =========================================================

    const feedbackMap = new Map();

    for (const feedback of feedbacks) {
      if (!feedback.appointmentId) continue;

      feedbackMap.set(
        feedback.appointmentId.toString(),
        feedback,
      );
    }

    // =========================================================
    // 4. FETCH SCHEDULES
    // =========================================================
    //
    // We need schedules because appointment data is embedded
    // inside Scheduling.
    //
    // =========================================================

    const schedules = await Scheduling.find({})
      .populate("therapistId", "fullName email role")
      .populate("appointments.children.childId", "fullName")
      .lean();

    // =========================================================
    // 5. BUILD APPOINTMENT MAP ONCE
    // =========================================================

    const appointmentMap = new Map();

    for (const schedule of schedules) {
      for (const appointment of schedule.appointments || []) {
        appointmentMap.set(
          appointment._id.toString(),
          {
            appointment,
            therapistId: schedule.therapistId,
          },
        );
      }
    }

    // =========================================================
    // 6. FIND PENDING FEEDBACK
    // =========================================================

    const pendingFeedback = [];

    for (const schedule of schedules) {
      for (const appointment of schedule.appointments || []) {
        // Don't ask feedback for cancelled appointments
        if (appointment.sessionType === "cancel") {
          continue;
        }

        // -----------------------------------------------------
        // Calculate actual appointment END datetime
        // -----------------------------------------------------

        const appointmentEnd = new Date(appointment.date);

        const [hours, minutes] = appointment.endTime
          .split(":")
          .map(Number);

        appointmentEnd.setHours(hours, minutes, 0, 0);

        // Appointment hasn't finished yet
        if (appointmentEnd >= now) {
          continue;
        }

        // -----------------------------------------------------
        // Check feedback
        // -----------------------------------------------------

        const feedback = feedbackMap.get(
          appointment._id.toString(),
        );

        // Feedback already exists
        if (feedback) {
          continue;
        }

        // -----------------------------------------------------
        // KEEP YOUR EXISTING FRONTEND STRUCTURE
        // -----------------------------------------------------

        pendingFeedback.push({
          appointmentId: appointment._id,

          therapistId: schedule.therapistId,

          childId: appointment.children?.length > 0
            ? appointment.children[0].childId
            : null,

          session: {
            date: appointment.date,
            startTime: appointment.startTime,
            endTime: appointment.endTime,

            attendanceStatus: appointment.children?.length > 0
              ? appointment.children[0].attendance_status
              : null,
          },
        });
      }
    }

    // =========================================================
    // 7. RESPONSE DATA
    // =========================================================

    let data = [];

    // =========================================================
    // ALL
    // =========================================================

    if (status === "all") {
      data = feedbacks.map((feedback) => {
        const appointmentData = feedback.appointmentId
          ? appointmentMap.get(
            feedback.appointmentId.toString(),
          )
          : null;

        const { replies, ...feedbackData } = feedback;

        return {
          ...feedbackData,

          isRespond: Array.isArray(replies)
            && replies.length > 0,

          appointment: appointmentData
            ? {
              startTime: appointmentData.appointment.startTime,
            }
            : null,
        };
      });
    }

    // =========================================================
    // NEW
    // =========================================================

    if (status === "new") {
      const threeDaysAgo = new Date();

      threeDaysAgo.setDate(
        threeDaysAgo.getDate() - 3,
      );

      data = feedbacks
        .filter(
          (feedback) => feedback.createdAt >= threeDaysAgo,
        )
        .map((feedback) => {
          const appointmentData = feedback.appointmentId
            ? appointmentMap.get(
              feedback.appointmentId.toString(),
            )
            : null;

          return {
            ...feedback,

            appointment: appointmentData
              ? {
                startTime: appointmentData.appointment
                  .startTime,
              }
              : null,
          };
        });
    }

    // =========================================================
    // PENDING
    // =========================================================

    if (status === "pending") {
      data = pendingFeedback;

      data.sort(
        (a, b) =>
          new Date(b.session.date)
          - new Date(a.session.date),
      );
    }

    // =========================================================
    // RESPONSE
    // =========================================================
    await Feedback.updateMany(
      {
        notes: { $nin: [null, ""] },
        "isSeen.userId": { $ne: userId },
      },
      {
        $addToSet: {
          isSeen: { userId, seenAt: new Date() },
        },
      }
    );
    return res.status(200).json({
      success: true,

      status,

      stats: {
        pendingFeedback: pendingFeedback.length,
        sinceYesterdayFeedback,
        averageSatisfaction,
      },

      count: data.length,

      data,
    });
  } catch (error) {
    console.error(
      "Admin Feedback Management Error:",
      error,
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch feedback management data.",
      error: error.message,
    });
  }
};

exports.getFeedbackReplies = async (req, res) => {
  try {
    const { feedbackId } = req.params;

    const feedback = await Feedback.findById(feedbackId)
      .populate("replies.repliedBy", "fullName role email")
      .lean();

    if (!feedback) {
      return res.json({ success: false, message: "Feedback not found." });
    }

    let appt = null;
    if (feedback.appointmentId) {
      const apptId = new mongoose.Types.ObjectId(feedback.appointmentId);
      const schedule = await Scheduling.findOne(
        { "appointments._id": apptId },
        { "appointments.$": 1 },
      ).lean();

      appt = schedule?.appointments?.[0] || null;
    }

    return res.status(200).json({
      success: true,
      data: {
        feedbackId: feedback._id,
        appointmentId: feedback.appointmentId,
        startTime: appt?.startTime || null,
        endTime: appt?.endTime || null,
        appointmentDate: appt?.date || null,
        attendanceStatus: appt?.attendance_status || null,
        replies: (feedback.replies || []).map((r) => ({
          _id: r._id,
          message: r.message,
          repliedByRole: r.repliedByRole,
          createdAt: r.createdAt,
          repliedBy: {
            id: r.repliedBy?._id,
            name: r.repliedBy?.fullName || "Unknown",
          },
        })),
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
exports.addFeedbackReply = async (req, res) => {
  try {
    const { feedbackId } = req.params;
    const { message } = req.body;

    if (!message?.trim()) {
      return res.json({
        success: false,
        message: "Reply message is required.",
      });
    }

    const feedback = await Feedback.findById(feedbackId);

    if (!feedback) {
      return res.json({
        success: false,
        message: "Feedback not found.",
      });
    }

    feedback.replies.push({
      repliedBy: req.user.id,
      repliedByRole: req.user.role,
      message: message.trim(),
    });

    await feedback.save();

    const updatedFeedback = await Feedback.findById(feedbackId)
      .populate("replies.repliedBy")
      .lean();

    return res.status(201).json({
      success: true,
      message: "Reply added successfully.",
      data: {
        feedbackId: updatedFeedback._id,
        replies: updatedFeedback.replies,
      },
    });
  } catch (error) {
    console.error("Add Feedback Reply Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to add reply.",
      error: error.message,
    });
  }
};
exports.deleteFeedback = async (req, res) => {
  try {
    const { feedbackId } = req.params;

    const feedback = await Feedback.findByIdAndDelete(feedbackId);

    if (!feedback) {
      return res.status(404).json({
        success: false,
        message: "Feedback not found.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Feedback deleted successfully.",
    });
  } catch (error) {
    console.error("Delete Feedback Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete feedback.",
      error: error.message,
    });
  }
};

const BATCH_POPULATE = [
  { path: "therapistIds", select: "fullName email" },
  // { path: "packageIds", select: "name type price sessions sessionMinutes specialities" },
];
exports.getBatches = async (req, res) => {
  try {
    const { page = 1, limit = 20, speciality, search="" } = req.query;
    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);

    const filter = {};
    if (speciality) {
      const specialityList = Array.isArray(speciality)
        ? speciality
        : speciality.split(",");
      filter.speciality = { $in: specialityList };
    }
    if (search.trim()) {
      filter.batchName = {
        $regex: search.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
        $options: "i",
      };
    }

    const totalCount = await Batch.countDocuments(filter);

    const batches = await Batch.find(filter)
      .populate("therapistIds", "fullName email")
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);

    return res.status(200).json({
      success: true,
      data: batches,
      hasMore: pageNum * limitNum < totalCount,
      totalCount,
    });
  } catch (error) {
    console.error("Get Batches Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch batches.",
      error: error.message,
    });
  }
};
exports.createBatch = async (req, res) => {
  try {
    const { batchName, speciality, dateFrom, dateTo, maxChild, packageIds } = req.body;
    const specialityList = Array.isArray(speciality) ? speciality : [];

    if (
      !batchName
      || !specialityList.length
      || !dateFrom
      || !dateTo
      || !maxChild
    ) {
      return res.status(400).json({
        success: false,
        message: "batchName, speciality (at least one), dateFrom, dateTo and Batch Size are required.",
      });
    }

    // const pk = await resolvePackageIds(packageIds);
    // if (pk.error) {
    //   return res.status(400).json({ success: false, message: pk.error });
    // }

    const batch = await Batch.create({
      batchName: batchName.trim(),
      speciality: specialityList,
      dateFrom: new Date(dateFrom),
      dateTo: new Date(dateTo),
      maxChild: parseInt(maxChild, 10),
      // packageIds: pk.ids,
    });

    const populated = await batch.populate(BATCH_POPULATE);

    return res.status(201).json({
      success: true,
      message: "Batch created successfully.",
      data: populated,
    });
  } catch (error) {
    console.error("Create Batch Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to create batch.",
      error: error.message,
    });
  }
};
exports.updateBatch = async (req, res) => {
  try {
    const { id } = req.params;
    const { batchName, speciality, dateFrom, dateTo, maxChild, packageIds } = req.body;

    const batch = await Batch.findById(id);
    if (!batch) {
      return res.json({ success: false, message: "Batch not found." });
    }

    if (batchName !== undefined) batch.batchName = batchName.trim();
    if (speciality !== undefined) {
      batch.speciality = Array.isArray(speciality) ? speciality : [];
    }
    if (dateFrom !== undefined) batch.dateFrom = new Date(dateFrom);
    if (dateTo !== undefined) batch.dateTo = new Date(dateTo);
    if (maxChild !== undefined) batch.maxChild = parseInt(maxChild, 10);

    // if (packageIds !== undefined) {
    //   const pk = await resolvePackageIds(packageIds);
    //   if (pk.error) {
    //     return res.status(400).json({ success: false, message: pk.error });
    //   }
    //   batch.packageIds = pk.ids;
    // }

    await batch.save();
    const populated = await batch.populate(BATCH_POPULATE);

    return res.status(200).json({
      success: true,
      message: "Batch updated successfully.",
      data: populated,
    });
  } catch (error) {
    console.error("Update Batch Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to update batch.",
      error: error.message,
    });
  }
};
exports.deleteBatch = async (req, res) => {
  try {
    const { id } = req.params;
    const batch = await Batch.findByIdAndDelete(id);

    if (!batch) {
      return res.json({ success: false, message: "Batch not found." });
    }

    return res.status(200).json({ success: true, message: "Batch deleted." });
  } catch (error) {
    console.error("Delete Batch Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete batch.",
      error: error.message,
    });
  }
};
exports.getBatchPackageOptions = async (req, res) => {
  try {
    const packages = await Package.find({ type: "batch" })
      .select("name type price sessions sessionMinutes specialities")
      .sort({ createdAt: -1 })
      .lean();
    return res.status(200).json({ success: true, data: packages });
  } catch (error) {
    console.error("getBatchPackageOptions:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch packages." });
  }
};

async function resolveRecipients(audience, roles, users, batchIds = []) {
  if (audience === "all") {
    return User.find({ role: { $in: ["Therapist", "Child", "Manager","Admin"] } }, "_id").lean();
  }
  if (audience === "role") {
    return User.find({ role: { $in: roles } }, "_id").lean();
  }
  if (audience === "users") {
    return User.find({ _id: { $in: users } }, "_id").lean();
  }
  if (audience === "batch") {
    const batches = await Batch.find({ _id: { $in: batchIds } }, "childrenIds").lean();
    const ids = [...new Set(batches.flatMap((b) => (b.childrenIds || []).map(String)))];
    if (!ids.length) return [];

    return User.find(
      { _id: { $in: ids }, role: "Child", isActive: { $ne: false } },
      "_id"
    ).lean();
  }
  return [];
}
const parseFutureDate = (value) => {
  const d = new Date(value);
  return isNaN(d.getTime()) || d <= new Date() ? null : d;
};
exports.createBroadcast = async (req, res) => {
  try {
    const {
      title,
      message,
      audience,
      roles,
      users,
      deliverySchedule,
      sendAt,
      type,
      batchIds,
    } = req.body;

    if (!title?.trim() || !message?.trim()) {
      return res
        .status(400)
        .json({ success: false, message: "Title and message are required." });
    }
    const VALID_TYPES = [
      "System",
      "Appointment",
      "Therapy",
      "Message",
      "Reminder",
      "Alert",
      "General",
    ];
    const notifType = VALID_TYPES.includes(type) ? type : "General";
    if (!["all", "role", "users","batch"].includes(audience)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid audience." });
    }

    let parsedRoles = [];
    let parsedUsers = [];
    let parsedBatchIds = [];
    try {
      parsedRoles = roles ? JSON.parse(roles) : [];
      parsedUsers = users ? JSON.parse(users) : [];
      parsedBatchIds = batchIds ? JSON.parse(batchIds) : [];
    } catch {
      return res
        .status(400)
        .json({
          success: false,
          message: "roles/users/batchIds must be valid JSON arrays.",
        });
    }
    if (audience === "batch") {
      parsedBatchIds = [...new Set(parsedBatchIds.filter((id) => mongoose.isValidObjectId(id)))];
      if (!parsedBatchIds.length) {
        return res.status(400).json({ success: false, message: "Select at least one batch." });
      }
    }
    if (audience === "role" && parsedRoles.length === 0) {
      return res
        .status(400)
        .json({
          success: false,
          message: "Select at least one role (Therapist/Child).",
        });
    }
    if (audience === "users" && parsedUsers.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "Select at least one user." });
    }

    let attachment = { url: null, name: null, type: null };
    if (req.file) {
      attachment = {
        url: `/assets/broadcasts/${req.file.filename}`,
        name: req.file.originalname,
        type: MIME_TO_TYPE[req.file.mimetype] || null,
      };
    }

    let status = "draft";
    let finalSendAt = null;

    if (deliverySchedule === "now") {
      status = "sending";
    } else if (deliverySchedule === "later") {
      if (!sendAt) {
        return res
          .status(400)
          .json({
            success: false,
            message: "sendAt is required for scheduled delivery.",
          });
      }
      const when = parseFutureDate(sendAt);
      if (!when) {
        return res.status(400).json({
          success: false,
          message: "sendAt must be a valid future date/time.",
        });
      }
      status = "scheduled";
      finalSendAt = when;
    }

    const notification = new Notification({
      title: title.trim(),
      message: message.trim(),
      audience,
      type: notifType,
      roles: audience === "role" ? parsedRoles : [],
      users: audience === "users" ? parsedUsers : [],
      batchIds: audience === "batch" ? parsedBatchIds : [],
      createdBy: req.user.id,
      attachment,
      status,
      sendAt: finalSendAt,
      adminSeen: [{ userId: req.user.id, seenAt: new Date() }],
    });
    let recipientUsers = [];
    if (status === "sending") {
      recipientUsers = await resolveRecipients(
        audience,
        parsedRoles,
        parsedUsers,
        parsedBatchIds,
      );
      if (audience === "batch" && !recipientUsers.length) {
        return res.status(400).json({
          success: false,
          message: "The selected batches have no active children.",
        });
      }
      notification.recipients = buildRecipients(recipientUsers);
      notification.status = "sent";
      notification.sentAt = new Date();
    }

    await notification.save();
    if (status === "sending" && recipientUsers.length > 0) {
      const recipientIds = recipientUsers.map((user) =>
        String(user._id || user)
      );

      const payload = {
        title: title.trim(),
        body: message.trim(),
        data: {
          screen: "Notifications",
          notificationId: String(notification._id),
          type: notifType,
          sound: "audio1",
          channelId: "default",
        },
      };

      try {
        const result = await sendBulkPushToUsers(
          recipientIds,
          payload
        );

        console.log("Broadcast push results:", result);
      } catch (error) {
        console.error("Broadcast push failed:", error);
      }
    }

    return res.status(201).json({
      success: true,
      message: status === "draft"
        ? "Draft saved."
        : status === "scheduled"
        ? "Broadcast scheduled."
        : "Broadcast sent.",
      data: notification,
    });
  } catch (error) {
    console.error("Create Broadcast Error:", error);
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to create broadcast.",
        error: error.message,
      });
  }
};
exports.getAllBroadcasts = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      search = "",
      status = "",
      type = "",
    } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const userId = req.user.id || req.user._id;
    const filter = {};
    if (search.trim()) {
      const regex = escapeRegex(search);
      filter.$or = [
        { title: { $regex: regex, $options: "i" } },
        { message: { $regex: regex, $options: "i" } },
      ];
    }
    if (status.trim() && status !== "all") filter.status = status.trim();
    if (type.trim() && type !== "all") filter.type = type.trim();

    const [broadcasts, total] = await Promise.all([
      Notification.find(filter)
        .populate("createdBy", "fullName email role")
        .populate("batchIds", "batchName")
        .populate("users", "fullName role")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      Notification.countDocuments(filter),
    ]);
    const data = broadcasts.map((b) => ({
      ...b,
      recipientCount: b.recipients?.length || 0,
      readCount: b.recipients?.filter((r) => r.readAt).length || 0,
    }));
    await Notification.updateMany(
      {
        "adminSeen.userId": { $ne: userId },
      },
      {
        $addToSet: {
          adminSeen: { userId, seenAt: new Date() },
        },
      }
    );
    return res.status(200).json({
      success: true,
      data,
      pagination: { page: Number(page), limit: Number(limit), total },
    });
  } catch (error) {
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to fetch broadcasts.",
        error: error.message,
      });
  }
};
exports.getBroadcastById = async (req, res) => {
  try {
    const { broadcastId } = req.params;
    const broadcast = await Notification.findById(broadcastId)
      .populate("createdBy", "fullName email role")
      .populate("batchIds", "batchName")
      .populate("users", "fullName role")
      .lean();

    if (!broadcast) {
      return res
        .status(404)
        .json({ success: false, message: "Broadcast not found." });
    }

    return res.status(200).json({
      success: true,
      data: {
        ...broadcast,
        recipientCount: broadcast.recipients?.length || 0,
        readCount: broadcast.recipients?.filter((r) => r.readAt).length || 0,
      },
    });
  } catch (error) {
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to fetch broadcast.",
        error: error.message,
      });
  }
};
exports.updateBroadcast = async (req, res) => {
  try {
    const { broadcastId } = req.params;
    const {
      title,
      message,
      audience,
      type,
      roles,
      users,
      deliverySchedule,
      sendAt,
      removeAttachment,
      batchIds,
    } = req.body;

    const broadcast = await Notification.findById(broadcastId);
    if (!broadcast) {
      return res
        .status(404)
        .json({ success: false, message: "Broadcast not found." });
    }
    if (broadcast.status === "sent") {
      return res
        .status(400)
        .json({ success: false, message: "Sent broadcasts can't be edited." });
    }

    if (title !== undefined) broadcast.title = title.trim();
    if (message !== undefined) broadcast.message = message.trim();
    if (type !== undefined) {
      const VALID_TYPES = [
        "System",
        "Appointment",
        "Therapy",
        "Message",
        "Reminder",
        "Alert",
        "General",
      ];
      broadcast.type = VALID_TYPES.includes(type) ? type : broadcast.type;
    }
    if (audience !== undefined) {
      if (!["all", "role", "users","batch"].includes(audience)) {
        return res
          .status(400)
          .json({ success: false, message: "Invalid audience." });
      }
      let parsedRoles = [];
      let parsedUsers = [];
      let parsedBatchIds = [];
      try {
        parsedRoles = roles ? JSON.parse(roles) : [];
        parsedUsers = users ? JSON.parse(users) : [];
        parsedBatchIds = batchIds ? JSON.parse(batchIds) : [];
      } catch {
        return res
          .status(400)
          .json({
            success: false,
            message: "roles/users/batchIds must be valid JSON arrays.",
          });
      }
      parsedBatchIds = parsedBatchIds.filter((id) => mongoose.isValidObjectId(id));
      if (audience === "batch" && !parsedBatchIds.length) {
        return res.status(400).json({ success: false, message: "Select at least one batch." });
      }
      broadcast.audience = audience;
      broadcast.roles = audience === "role" ? parsedRoles : [];
      broadcast.users = audience === "users" ? parsedUsers : [];
      broadcast.batchIds = audience === "batch" ? parsedBatchIds : [];
    }

    if (deliverySchedule === "now") {
      broadcast.status = "sending";
      broadcast.sendAt = null;
    } else if (deliverySchedule === "later") {
      if (!sendAt) {
        return res
          .status(400)
          .json({
            success: false,
            message: "sendAt is required for scheduled delivery.",
          });
      }
      const when = parseFutureDate(sendAt);
      if (!when) {
        return res.status(400).json({
          success: false,
          message: "sendAt must be a valid future date/time.",
        });
      }
      broadcast.status = "scheduled";
      broadcast.sendAt = when;
    } else if (deliverySchedule === "draft") {
      broadcast.status = "draft";
      broadcast.sendAt = null;
    }

    if (removeAttachment === "true" && broadcast.attachment?.url) {
      const oldPath = path.join(
        __dirname,
        "..",
        broadcast.attachment.url.replace(/^\//, ""),
      );
      fs.unlink(oldPath, () => {});
      broadcast.attachment = { url: null, name: null, type: null };
    }

    if (req.file) {
      if (broadcast.attachment?.url) {
        const oldPath = path.join(
          __dirname,
          "..",
          broadcast.attachment.url.replace(/^\//, ""),
        );
        fs.unlink(oldPath, () => {});
      }
      broadcast.attachment = {
        url: `/assets/broadcasts/${req.file.filename}`,
        name: req.file.originalname,
        type: MIME_TO_TYPE[req.file.mimetype] || null,
      };
    }
    let recipientUsers = [];
    const shouldSendPush = deliverySchedule === "now" && broadcast.status !== "sent";
    if (broadcast.status === "sending") {
      recipientUsers = await resolveRecipients(
        broadcast.audience,
        broadcast.roles,
        broadcast.users,
        broadcast.batchIds
      );
      if (broadcast.audience === "batch" && !recipientUsers.length) {
        return res.status(400).json({
          success: false,
          message: "The selected batches have no active children.",
        });
      }
      broadcast.recipients = buildRecipients(recipientUsers);
      broadcast.status = "sent";
      broadcast.sentAt = new Date();
    }

    await broadcast.save();
    let pushResults = null;
    if (shouldSendPush && recipientUsers.length > 0) {
      const payload = {
        title: broadcast.title,
        body: broadcast.message,
        data: {
          screen: "Notifications",
          notificationId: String(broadcast._id),
          type: broadcast.type,
        },
      };

      const results = await Promise.allSettled(
        recipientUsers.map((user) =>
          sendPushToUser(
            String(user._id || user),
            payload
          )
        )
      );
    }

    return res
      .status(200)
      .json({ success: true, message: "Broadcast updated.", data: broadcast });
  } catch (error) {
    console.error("Update Broadcast Error:", error);
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to update broadcast.",
        error: error.message,
      });
  }
};
exports.deleteBroadcast = async (req, res) => {
  try {
    const { broadcastId } = req.params;
    const { IsHide = false, userID = null } = req.body;

    const broadcast = await Notification.findById(broadcastId);

    if (!broadcast) {
      return res
        .status(404)
        .json({ success: false, message: "Broadcast not found." });
    }

    if (IsHide === true || IsHide === "true") {
      if (!userID) {
        return res.status(400).json({
          success: false,
          message: "userID is required when hiding a broadcast.",
        });
      }

      const recipient = broadcast.recipients.find(
        (item) => item.user?.toString() === userID.toString(),
      );

      if (!recipient) {
        return res.status(404).json({
          success: false,
          message: "User is not a recipient of this broadcast.",
        });
      }

      recipient.isDelete = true;

      await broadcast.save();

      return res.status(200).json({
        success: true,
        message: "Broadcast hidden for this user.",
      });
    }

    await Notification.findByIdAndDelete(broadcastId);

    if (broadcast.attachment?.url) {
      const filePath = path.join(
        __dirname,
        "..",
        broadcast.attachment.url.replace(/^\//, ""),
      );
      fs.unlink(filePath, () => {}); // best-effort cleanup, no need to block response on it
    }
    return res
      .status(200)
      .json({ success: true, message: "Broadcast deleted." });
  } catch (error) {
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to delete broadcast.",
        error: error.message,
      });
  }
};

exports.getComplaints = async (req, res) => {
  try {
    const userId = req.user.id || req.user._id;
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 5, 10);
    const { status, priority, role } = req.query;
    const search = (req.query.search || "").trim();
    
    const filter = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (role) filter.complainantRole = role;

    if (search) {
      const regex = new RegExp(escapeRegex(search), "i");
      const users = await User.find({ fullName: regex }, "_id").lean();
      filter.$or = [
        { title: regex },
        { description: regex },
        { complainantId: { $in: users.map((u) => u._id) } },
      ];
    }

    const weekStart = new Date();
    const day = weekStart.getDay() || 7;
    weekStart.setDate(weekStart.getDate() - day + 1);
    weekStart.setHours(0, 0, 0, 0);

    const [total, list, pendingWeek, resolvedWeek] = await Promise.all([
      Complaint.countDocuments(filter),
      Complaint.find(filter)
        .select("-messages")
        .populate(POPULATE)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Complaint.countDocuments({
        status: "Pending",
        createdAt: { $gte: weekStart },
      }),
      Complaint.countDocuments({
        status: "Resolved",
        createdAt: { $gte: weekStart },
      }),
    ]);

    const unread = await Complaint.aggregate([
      { $match: { _id: { $in: list.map((c) => c._id) } } },
      {
        $project: {
          count: {
            $size: {
              $filter: {
                input: "$messages",
                as: "m",
                cond: {
                  $and: [
                    { $ne: ["$$m.senderRole", "Admin"] },
                    { $eq: ["$$m.readByRecipient", false] },
                  ],
                },
              },
            },
          },
        },
      },
    ]);
    const unreadMap = new Map(unread.map((u) => [String(u._id), u.count]));
    await Complaint.updateMany(
      {
        "isSeen.userId": { $ne: userId },
      },
      {
        $addToSet: {
          isSeen: { userId, seenAt: new Date() },
        },
      }
    );
    return res.status(200).json({
      success: true,
      data: list.map((c) => ({
        ...c,
        unreadCount: unreadMap.get(String(c._id)) || 0,
      })),
      hasMore: page * limit < total,
      stats: {
        total: await Complaint.countDocuments(),
        pending: pendingWeek,
        resolved: resolvedWeek,
      },
    });
  } catch (error) {
    console.error("Get Complaints Error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to fetch complaints." });
  }
};

exports.resolveComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findOneAndUpdate(
      { _id: req.params.id, status: "Pending" },
      {
        status: "Resolved",
        resolvedBy: req.user.id,
        resolvedAt: new Date(),
        resolutionNote: (req.body?.resolutionNote || "").trim().slice(0, 500),
      },
      { returnDocument: "after", projection: { messages: 0 } },
    ).populate(POPULATE);

    if (!complaint) {
      return res.json({
        success: false,
        message: "Complaint not found or already resolved.",
      });
    }

    await sendNotifications({
      title: "Complaint Resolved",
      message: `Your complaint has been reviewed and resolved successfully.${
        complaint.resolutionNote
          ? ` Resolution: ${complaint.resolutionNote}`
          : ""
      }`,
      type: "Reminder",
      audience: "users",
      users: [
        String(complaint.complainantId?._id || complaint.complainantId)
      ],
      createdBy: req.user.id,
      sendPush: true,
    });

    return res.status(200).json({ success: true, data: complaint });
  } catch (error) {
    console.error("Resolve Complaint Error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to resolve complaint." });
  }
};
exports.updateComplaintPriority = async (req, res) => {
  try {
    const { priority } = req.body;
    if (!["High", "Normal"].includes(priority)) {
      return res
        .status(400)
        .json({ success: false, message: "Priority must be High or Normal." });
    }

    const complaint = await Complaint.findOneAndUpdate(
      { _id: req.params.id, status: "Pending" },
      { priority },
      { new: true, projection: { messages: 0 } },
    ).populate(POPULATE);

    if (!complaint) {
      return res
        .status(404)
        .json({
          success: false,
          message: "Complaint not found or already resolved.",
        });
    }
    return res.status(200).json({ success: true, data: complaint });
  } catch (error) {
    console.error("Update Priority Error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to update priority." });
  }
};
exports.getComplaintMessages = async (req, res) => {
  try {
    const { id } = req.params;

    const complaint = await Complaint.findById(id)
      .select("status messages")
      .lean();
    if (!complaint) {
      return res.json({ success: false, message: "Complaint not found." });
    }

    await Complaint.updateOne(
      { _id: id },
      { $set: { "messages.$[m].readByRecipient": true } },
      { arrayFilters: [{ "m.senderRole": { $ne: "Admin" }, "m.readByRecipient": false }] },
    );

    return res.status(200).json({
      success: true,
      data: {
        status: complaint.status,
        messages: complaint.messages.slice(-200),
      },
    });
  } catch (error) {
    console.error("Get Messages Error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to fetch messages." });
  }
};
exports.sendComplaintMessage = async (req, res) => {
  try {
    const text = (req.body?.text || "").trim();
    if (!text) {
      return res
        .status(400)
        .json({ success: false, message: "Message cannot be empty." });
    }
    if (text.length > 1000) {
      return res
        .status(400)
        .json({
          success: false,
          message: "Message can be at most 1000 characters.",
        });
    }

    const updated = await Complaint.findOneAndUpdate(
      { _id: req.params.id, status: "Pending" },
      { $push: { messages: { senderId: req.user.id, senderRole: "Admin", text } } },
      { new: true, projection: { messages: { $slice: -1 } } },
    ).lean();

    if (!updated) {
      const exists = await Complaint.exists({ _id: req.params.id });
      return res.status(exists ? 400 : 404).json({
        success: false,
        message: exists
          ? "This complaint is resolved, chat is read-only."
          : "Complaint not found.",
      });
    }

    return res.status(201).json({ success: true, data: updated.messages[0] });
  } catch (error) {
    console.error("Send Message Error:", error);
    return res
      .status(500)
      .json({ success: false, message: "Failed to send message." });
  }
};

exports.getMyNotifications = async (req, res) => {
  try {
    const userId = req.user.id;
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 15, 50);
    const { typeFilter = "All" } = req.query;

    const isUnreadFilter = typeFilter === "Unread";

    const recipientFilter = {
      user: userId,
      ...(isUnreadFilter ? { readAt: null } : {}),
      $or: [
        { isDelete: false },
        { isDelete: { $exists: false } },
      ],
    };

    const filter = {
      status: "sent",
      recipients: {
        $elemMatch: recipientFilter,
      },
    };

    if (typeFilter !== "All" && !isUnreadFilter) {
      filter.type = typeFilter;
    }

    const unreadFilter = {
      status: "sent",
      recipients: {
        $elemMatch: {
          user: userId,
          readAt: null,
          $or: [
            { isDelete: false },
            { isDelete: { $exists: false } },
          ],
        },
      },
    };

    const [total, notifications, unreadCount] = await Promise.all([
      Notification.countDocuments(filter),

      Notification.find(filter)
        .populate("createdBy", "fullName role")
        .sort({ sentAt: -1, createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),

      Notification.countDocuments(unreadFilter),
    ]);

    const data = notifications.map((n) => {
      const mine = (n.recipients || []).find(
        (r) => String(r.user) === String(userId)
      );

      const { recipients, ...rest } = n;

      return {
        ...rest,
        isRead: !!mine?.readAt,
        readAt: mine?.readAt || null,
        deliveredAt: mine?.deliveredAt || null,
      };
    });

    return res.status(200).json({
      success: true,
      data,
      hasMore: page * limit < total,
      totalCount: total,
      unreadCount,
    });

  } catch (error) {
    console.error("Get My Notifications Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch notifications.",
      error: error.message,
    });
  }
};
exports.markNotificationRead = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const notification = await Notification.findOneAndUpdate(
      { _id: id, "recipients.user": userId },
      {
        $set: {
          "recipients.$.readAt": new Date(),
        },
        $setOnInsert: {},
      },
      { new: true, projection: { recipients: 1 } },
    );

    if (!notification) {
      return res.json({ success: false, message: "Notification not found." });
    }

    const mine = notification.recipients.find(
      (r) => String(r.user) === String(userId),
    );
    if (!mine?.deliveredAt) {
      await Notification.updateOne(
        { _id: id, "recipients.user": userId },
        { $set: { "recipients.$.deliveredAt": new Date() } },
      );
    }

    return res.status(200).json({
      success: true,
      message: "Notification marked as read.",
      data: { id, readAt: mine?.readAt },
    });
  } catch (error) {
    console.error("Mark Notification Read Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to mark notification as read.",
      error: error.message,
    });
  }
};
exports.markAllNotificationsRead = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await Notification.updateMany(
      {
        status: "sent",
        recipients: { $elemMatch: { user: userId, readAt: null } },
      },
      { $set: { "recipients.$[r].readAt": new Date() } },
      { arrayFilters: [{ "r.user": userId, "r.readAt": null }] },
    );

    return res.status(200).json({
      success: true,
      message: "All notifications marked as read.",
      modified: result.modifiedCount ?? result.nModified,
    });
  } catch (error) {
    console.error("Mark All Notifications Read Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to mark notifications as read.",
      error: error.message,
    });
  }
};


const findBlockingSessions = async (therapistId, oldRule, newRule = null) => {
  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);
  const nowMin = clockMinutes(st.tz);
  const [ty, tm] = today.split("-").map(Number);

  const schedules = await Scheduling.find({
    therapistId,
    $or: [{ year: { $gt: ty } }, { year: ty, month: { $gte: tm } }],
  }).lean();

  const blocking = [];
  for (const sc of schedules) {
    for (const ap of sc.appointments || []) {
      if (INACTIVE_TYPES.includes(ap.sessionType)) continue;

      const date = dateKeyOf(ap.date);
      const a = toMin(ap.startTime);
      const b = toMin(ap.endTime);

      if (date < today || (date === today && b <= nowMin)) continue;

      if (!availableOnDate([oldRule], date, a, b)) continue;

      if (newRule && availableOnDate([newRule], date, a, b)) continue;

      blocking.push({ date, startTime: ap.startTime, endTime: ap.endTime });
    }
  }

  blocking.sort((x, y) =>
    x.date === y.date
      ? x.startTime.localeCompare(y.startTime)
      : x.date.localeCompare(y.date)
  );
  return blocking;
};
const blockedMessage = (action, list) => {
  const sample = list
    .slice(0, 3)
    .map((s) => `${s.date} ${to12(s.startTime)}-${to12(s.endTime)}`)
    .join(", ");
  return `Cannot ${action} this availability: ${list.length} upcoming session(s) are scheduled in it (${sample}${
    list.length > 3 ? ", ..." : ""
  }). Cancel or reschedule them first.`;
};
exports.getAvailability = async (req, res) => {
  try {
    const { therapistId } = req.query;
    if (!mongoose.isValidObjectId(therapistId)) {
      return res
        .status(400)
        .json({ success: false, message: "Valid therapistId is required." });
    }

    const data = await TherapistAvailability.find({ therapistId })
      .sort({ type: -1, date: 1, createdAt: 1 })
      .lean();

    return res.status(200).json({ success: true, count: data.length, data });
  } catch (error) {
    console.error("Get Availability Error:", error);
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to fetch availability.",
        error: error.message,
      });
  }
};
exports.createAvailability = async (req, res) => {
  try {
    const { therapistId } = req.body;
    if (!mongoose.isValidObjectId(therapistId)) {
      return res
        .status(400)
        .json({ success: false, message: "Valid therapistId is required." });
    }

    const therapist = await User.findOne({
      _id: therapistId,
      role: "Therapist",
    }).lean();
    if (!therapist) {
      return res
        .status(404)
        .json({ success: false, message: "Therapist not found." });
    }

    const { rule, error } = await buildRule(req.body, null);
    if (error) return res.status(400).json({ success: false, message: error });

    const clash = await findConflict(therapistId, rule);
    if (clash) {
      return res.status(409).json({
        success: false,
        message: `This overlaps with an existing availability (${describe(clash)}).`,
      });
    }

    const created = await TherapistAvailability.create({
      therapistId,
      ...rule,
    });
    return res
      .status(201)
      .json({ success: true, message: "Availability added.", data: created });
  } catch (error) {
    console.error("Create Availability Error:", error);
    return res
      .status(500)
      .json({
        success: false,
        message: "Failed to add availability.",
        error: error.message,
      });
  }
};
exports.updateAvailability = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }

    const existing = await TherapistAvailability.findById(id);
    if (!existing) {
      return res
        .status(404)
        .json({ success: false, message: "Availability not found." });
    }

    const { rule, error } = await buildRule(req.body, existing);
    if (error) return res.status(400).json({ success: false, message: error });

    const clash = await findConflict(existing.therapistId, rule, existing._id);
    if (clash) {
      return res.status(409).json({
        success: false,
        message: `This overlaps with an existing availability (${describe(clash)}).`,
      });
    }

    if (existing.isActive) {
      const deactivating = req.body.isActive !== undefined && !req.body.isActive;
      const blocking = await findBlockingSessions(
        existing.therapistId,
        existing.toObject(),
        deactivating ? null : rule,
      );
      if (blocking.length) {
        return res.status(409).json({
          success: false,
          message: blockedMessage("update", blocking),
          sessions: blocking,
        });
      }
    }

    Object.assign(existing, rule);
    if (req.body.isActive !== undefined) {
      existing.isActive = !!req.body.isActive;
    }
    await existing.save();

    return res.status(200).json({
      success: true,
      message: "Availability updated.",
      data: existing,
    });
  } catch (error) {
    console.error("Update Availability Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to update availability.",
      error: error.message,
    });
  }
};
exports.deleteAvailability = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }

    const existing = await TherapistAvailability.findById(id).lean();
    if (!existing) {
      return res
        .status(404)
        .json({ success: false, message: "Availability not found." });
    }

    if (existing.isActive) {
      const blocking = await findBlockingSessions(existing.therapistId, existing, null);
      if (blocking.length) {
        return res.status(409).json({
          success: false,
          message: blockedMessage("delete", blocking),
          sessions: blocking,
        });
      }
    }

    await TherapistAvailability.deleteOne({ _id: id });
    return res
      .status(200)
      .json({ success: true, message: "Availability deleted." });
  } catch (error) {
    console.error("Delete Availability Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete availability.",
      error: error.message,
    });
  }
};


exports.getBatchTherapistOptions = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId).lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const { from, to } = planRange(batch, today);

    if (from > to) {
      return res.status(400).json({
        success: false,
        message: "This batch has already ended.",
      });
    }

    const activeIds = await User.find({
      role: "Therapist",
      isActive: { $ne: false },
    }).distinct("_id");

    const [assignments, existing] = await Promise.all([
      TherapistAssignment.find({
        specialty: { $in: batch.speciality },
        therapistId: { $in: activeIds },
      })
        .populate("therapistId", "fullName email")
        .lean(),

      BatchAssignment.find({ batchId: batch._id }).lean(),
    ]);

    const therapistIds = [
      ...new Set(
        assignments
          .filter((a) => a.therapistId)
          .map((a) => String(a.therapistId._id)),
      ),
    ];

    const availability = therapistIds.length
      ? await TherapistAvailability.find({
        therapistId: { $in: therapistIds },
        isActive: true,
      }).lean()
      : [];

    const availabilityMap = new Set(
      availability
        .filter((r) =>
          r.type === "custom"
            ? r.date >= from && r.date <= to
            : (!r.effectiveTo || r.effectiveTo >= from)
              && (!r.effectiveFrom || r.effectiveFrom <= to)
        )
        .map((r) => String(r.therapistId)),
    );

    const assignedMap = new Set(
      existing.map(
        (a) => `${String(a.therapistId)}|${a.speciality}`,
      ),
    );

    const data = batch.speciality.map((speciality) => {
      const map = new Map();

      for (const a of assignments) {
        if (!a.therapistId || a.specialty !== speciality) continue;

        const therapistId = String(a.therapistId._id);

        if (!map.has(therapistId)) {
          map.set(therapistId, {
            _id: a.therapistId._id,
            fullName: a.therapistId.fullName,
            email: a.therapistId.email,
            speciality,
            hasAvailability: availabilityMap.has(therapistId),
            alreadyAssigned: assignedMap.has(
              `${therapistId}|${speciality}`,
            ),
          });
        }
      }

      return {
        speciality,
        therapists: [...map.values()],
      };
    });

    return res.json({
      success: true,
      data,
    });
  } catch (error) {
    console.error("getBatchTherapistOptions:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch therapists.",
    });
  }
};
exports.getBatchSlotOptions = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId).lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }

    const minutes = Number(req.body.sessionMinutes);

    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const team = Array.isArray(req.body.therapists)
      ? req.body.therapists
      : [];

    if (!team.length) {
      return res.status(400).json({
        success: false,
        message: "Select at least one therapist.",
      });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const { from, to } = planRange(batch, today);

    if (from > to) {
      return res.status(400).json({
        success: false,
        message: "This batch has already ended.",
      });
    }

    const ids = [
      ...new Set(team.map((t) => String(t.therapistId))),
    ];

    const [rules, existing] = await Promise.all([
      TherapistAvailability.find({
        therapistId: { $in: ids },
        isActive: true,
      }).lean(),

      BatchAssignment.find({
        batchId: batch._id,
        therapistId: { $in: ids },
      })
        .populate("therapistId", "fullName")
        .lean(),
    ]);

    const data = team.map((t) => {
      const therapistRules = rules.filter(
        (r) => String(r.therapistId) === String(t.therapistId),
      );

      return {
        therapistId: String(t.therapistId),
        speciality: t.speciality,
        days: weeklyOptions(
          therapistRules,
          from,
          to,
          minutes,
          st,
        ),
      };
    });

    const blocked = {};

    WORKING_DAYS.forEach((day) => {
      blocked[day] = [];
    });

    const nameById = new Map(
      existing.map((a) => [String(a.therapistId?._id), a.therapistId?.fullName || "Therapist"]),
    );
    const specByAssignment = new Map(existing.map((a) => [String(a._id), a.speciality]));

    const batchAps = await loadBatchAppointments(batch._id);
    for (const ap of batchAps) {
      const tid = String(ap.therapistId);
      const date = dateKeyOf(ap.date);
      if (!ids.includes(tid) || INACTIVE_TYPES.includes(ap.sessionType) || date < today) continue;

      const day = weekdayOf(date);
      const exists = blocked[day].some(
        (x) => x.therapistId === tid && x.startTime === ap.startTime && x.endTime === ap.endTime,
      );
      if (!exists) {
        blocked[day].push({
          therapistId: tid,
          speciality: specByAssignment.get(String(ap.batchAssignmentId)),
          startTime: ap.startTime,
          endTime: ap.endTime,
          therapistName: nameById.get(tid) || "Therapist",
        });
      }
    }

    return res.json({
      success: true,
      data,
      blocked,
    });
  } catch (error) {
    console.error("getBatchSlotOptions:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load available slots.",
    });
  }
};
exports.previewBatchSchedule = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId).lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }

    const r = await analyzePlan(batch, req.body);

    if (r.error) {
      return res.status(400).json({
        success: false,
        message: r.error,
      });
    }

    const count = (list, plan) =>
      list.filter(
        (s) =>
          String(s.therapistId) === String(plan.therapistId)
          && s.speciality === plan.speciality,
      ).length;

    const perTherapist = r.plans.map((plan) => ({
      therapistId: String(plan.therapistId),
      speciality: plan.speciality,
      name: r.names.get(String(plan.therapistId)) || "",
      sessions: count(r.toCreate, plan),
      conflicts: count(r.conflicts, plan),
      unavailable: count(r.unavailable, plan),
      existing: count(r.duplicates, plan),
    }));

    return res.json({
      success: true,
      data: {
        children: r.children.length,
        total: r.toCreate.length,
        perTherapist,
        conflicts: r.conflicts,
        unavailableCount: r.unavailable.length,
        existingCount: r.duplicates.length,
      },
    });
  } catch (error) {
    console.error("previewBatchSchedule:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to check the schedule.",
    });
  }
};
exports.saveBatchSchedule = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId).lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }

    const r = await analyzePlan(batch, req.body);

    if (r.error) {
      return res.status(400).json({
        success: false,
        message: r.error,
      });
    }

    if (r.conflicts.length && !req.body.skipConflicts) {
      return res.status(409).json({
        success: false,
        hasConflicts: true,
        message: "Some sessions conflict with existing bookings.",
        conflicts: r.conflicts,
      });
    }

    if (!r.toCreate.length) {
      return res.status(400).json({
        success: false,
        message: "No new sessions to create. Every date conflicts, is outside availability, or already exists.",
      });
    }

    let created = 0;

    for (const plan of r.plans) {
      const therapistId = String(plan.therapistId);
      const sessions = r.toCreate.filter(
        (s) => s.therapistId === therapistId && s.speciality === plan.speciality,
      );
      if (!sessions.length) continue;

      const key = { batchId: batch._id, therapistId, speciality: plan.speciality };
      await BatchAssignment.updateOne(
        key,
        {
          $set: { childIds: r.children, sessionMinutes: r.minutes },
          $setOnInsert: { maxChildren: batch.maxChild },
        },
        { upsert: true },
      );
      const assignment = await BatchAssignment.findOne(key).select("_id").lean();

      const byMonth = new Map();
      for (const s of sessions) {
        const k = s.date.slice(0, 7);
        if (!byMonth.has(k)) byMonth.set(k, []);
        byMonth.get(k).push(s);
      }

      for (const [k, list] of byMonth) {
        const [year, month] = k.split("-").map(Number);
        const schedule = (await Scheduling.findOne({ therapistId, year, month }))
          || new Scheduling({ therapistId, year, month, appointments: [] });

        for (const s of list) {
          const exists = schedule.appointments.some(
            (ap) =>
              ap.type === "batch"
              && String(ap.batchAssignmentId) === String(assignment._id)
              && dateKeyOf(ap.date) === s.date
              && ap.startTime === s.startTime,
          );
          if (exists) continue;

          schedule.appointments.push({
            date: utcMidnight(s.date),
            startTime: s.startTime,
            endTime: s.endTime,
            type: "batch",
            batchId: batch._id,
            batchAssignmentId: assignment._id,
            sessionType: "regular",
            originalAppointmentId: null,
            children: r.children.map((childId) => ({ childId, attendance_status: "Pending" })),
          });
          created++;
        }
        await schedule.save();
      }
    }

    await Batch.updateOne(
      { _id: batch._id },
      {
        $addToSet: {
          therapistIds: {
            $each: r.plans.map((p) => p.therapistId),
          },
        },
      },
    );
    await Promise.all(
      r.plans.map((p) =>
        TherapistAssignment.updateOne(
          { therapistId: p.therapistId, specialty: p.speciality },
          { $addToSet: { childIds: { $each: r.children } } },
        ),
      ),
    );

    return res.status(201).json({
      success: true,
      message: "Batch schedule created.",
      data: {
        created,
        children: r.children.length,
        skippedConflicts: r.conflicts.length,
        unavailable: r.unavailable.length,
        alreadyExisting: r.duplicates.length,
      },
    });
  } catch (error) {
    console.error("saveBatchSchedule:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to save batch schedule.",
      error: error.message,
    });
  }
};
exports.getBatchEligibleChildren = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId)
      .select("childrenIds maxChild")
      .lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }

    const currentIds = (batch.childrenIds || []).map(String);

    const search = String(req.query.search || "").trim();

    const filter = {
      role: "Child",
      _id: { $nin: currentIds },
      isActive: { $ne: false },
    };

    if (search) {
      const regex = escapeRegex(search);
      filter.$or = [
        { fullName: { $regex: regex, $options: "i" } },
        { email: { $regex: regex, $options: "i" } },
      ];
    }

    const children = await User.find(
      filter,
      "fullName email",
    )
      .sort({ fullName: 1 })
      .lean();

    const remaining = Math.max(
      Number(batch.maxChild) - currentIds.length,
      0,
    );

    return res.json({
      success: true,
      data: {
        children,
        currentCount: currentIds.length,
        maxChild: batch.maxChild,
        remaining,
      },
    });
  } catch (error) {
    console.error("getBatchEligibleChildren:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to load eligible children.",
    });
  }
};
exports.updateBatchChildren = async (req, res) => {
  try {
    const batch = await Batch.findById(req.params.batchId)
      .select("childrenIds therapistIds maxChild dateTo")
      .lean();

    if (!batch) {
      return res.status(404).json({
        success: false,
        message: "Batch not found.",
      });
    }
    
    const normalizeIds = (value) => [
      ...new Set(
        (Array.isArray(value) ? value : [])
          .filter((id) => mongoose.isValidObjectId(id))
          .map(String),
      ),
    ];
    const st = await loadScheduleSettings();
        const today = todayKey(st.tz);

        const nowTime = new Intl.DateTimeFormat("en-GB", {
          timeZone: st.tz,
          hour: "2-digit",
          minute: "2-digit",
          hourCycle: "h23",
        }).format(new Date());
    const remove = normalizeIds(req.body.removeChildIds);
    const add = normalizeIds(req.body.addChildIds);

    const current = new Set(
      (batch.childrenIds || []).map(String),
    );

    const actualRemove = remove.filter((id) => current.has(id));

    const actualAdd = add.filter((id) => !current.has(id));

    if (!actualRemove.length && !actualAdd.length) {
      return res.status(400).json({
        success: false,
        message: "Nothing to update.",
      });
    }

    const newCount = current.size
      - actualRemove.length
      + actualAdd.length;

    if (newCount > batch.maxChild) {
      return res.status(400).json({
        success: false,
        message: `This batch can hold ${batch.maxChild} children.`,
      });
    }
    if (actualAdd.length) {
      const validCount = await User.countDocuments({
        _id: { $in: actualAdd },
        role: "Child",
      });

      if (validCount !== actualAdd.length) {
        return res.status(400).json({
          success: false,
          message: "Some children were not found.",
        });
      }
    }

    actualRemove.forEach((id) => current.delete(id));
    actualAdd.forEach((id) => current.add(id));

    const finalChildren = [...current];

    await Batch.updateOne(
      { _id: batch._id },
      {
        $set: {
          childrenIds: finalChildren,
        },
      },
    );
    const therapistIds = batch.therapistIds || [];

    if (therapistIds.length > 0) {
      const therapistFilter = {
        therapistId: { $in: therapistIds },
      };

      if (actualAdd.length > 0) {
        await TherapistAssignment.updateMany(
          therapistFilter,
          {
            $addToSet: {
              childIds: { $each: actualAdd },
            },
          }
        );
      }

      if (actualRemove.length > 0) {

        const removeFromTherapist = [];
        const keepInTherapist = [];

        for (const childId of actualRemove) {
          const childObjectId =
            new mongoose.Types.ObjectId(childId);

          const schedules = await Scheduling.find({
            "appointments.children.childId": childObjectId,
          })
            .select("appointments")
            .lean();

          let hasPastAppointment = false;
          let hasFutureCustomAppointment = false;

          for (const schedule of schedules) {
            for (const ap of schedule.appointments || []) {
              const hasChild = (ap.children || []).some(
                (c) => String(c.childId) === childId
              );

              if (!hasChild) continue;

              const appointmentDate = dateKeyOf(ap.date);

              if (
                appointmentDate < today ||
                (
                  appointmentDate === today &&
                  ap.startTime < nowTime
                )
              ) {
                hasPastAppointment = true;
                break;
              }

              if (
                appointmentDate > today ||
                (
                  appointmentDate === today &&
                  ap.startTime >= nowTime
                )
              ) {
                if (ap.type === "custom") {
                  hasFutureCustomAppointment = true;
                }
              }
            }

            if (hasPastAppointment) break;
          }

          if (
            hasPastAppointment ||
            hasFutureCustomAppointment
          ) {
            keepInTherapist.push({
              childId,
              reason: hasPastAppointment
                ? "Child has a past appointment."
                : "Child has a future custom appointment.",
            });
          } else {
            removeFromTherapist.push(childObjectId);
          }
        }

        if (removeFromTherapist.length > 0) {
          await TherapistAssignment.updateMany(
            therapistFilter,
            {
              $pull: {
                childIds: {
                  $in: removeFromTherapist,
                },
              },
            }
          );
        }

        console.log("Removed from therapist assignments:",
          removeFromTherapist.map(String));

        console.log("Kept in therapist assignments:",
          keepInTherapist);
      }
    }
    const assignments = await BatchAssignment.find({
      batchId: batch._id,
    })
      .select("_id therapistId sessions")
      .lean();

    if (!assignments.length) {
      return res.json({
        success: true,
        message: "Batch children updated.",
        data: {
          added: actualAdd.length,
          removed: actualRemove.length,
          skippedSessions: 0,
          skipped: [],
        },
      });
    }

    await BatchAssignment.updateMany(
      { batchId: batch._id },
      {
        $set: {
          childIds: finalChildren,
        },
      },
    );

    const batchEnd = dateKeyOf(batch.dateTo);

    if (actualRemove.length) {
      const schedules = await Scheduling.find({
        appointments: {
          $elemMatch: {
            type: "batch",
            batchId: batch._id,
            date: {
              $gte: utcMidnight(today),
              $lte: utcMidnight(batchEnd),
            },
            children: {
              $elemMatch: {
                childId: {
                  $in: actualRemove.map(
                    (id) => new mongoose.Types.ObjectId(id)
                  ),
                },
                attendance_status: "Pending",
              },
            },
          },
        },
      }).select("appointments");

      const ops = [];

      for (const schedule of schedules) {
        for (const ap of schedule.appointments) {
          if (
            ap.type !== "batch" ||
            String(ap.batchId) !== String(batch._id)
          ) {
            continue;
          }

          const appointmentDate = dateKeyOf(ap.date);

          if (appointmentDate < today) continue;

          if (appointmentDate > today && appointmentDate > batchEnd) {
            continue;
          }

          if (
            appointmentDate === today &&
            toMin(ap.endTime) <= toMin(nowTime)
          ) {
            continue;
          }

          ops.push({
            updateOne: {
              filter: {
                _id: schedule._id,
                "appointments._id": ap._id,
              },
              update: {
                $pull: {
                  "appointments.$.children": {
                    childId: {
                      $in: actualRemove.map(
                        (id) => new mongoose.Types.ObjectId(id)
                      ),
                    },
                    attendance_status: "Pending",
                  },
                },
              },
            },
          });
        }
      }

      for (let i = 0; i < ops.length; i += 500) {
        await Scheduling.bulkWrite(
          ops.slice(i, i + 500),
          { ordered: false }
        );
      }
    }

    if (!actualAdd.length) {
      return res.json({
        success: true,
        message: "Batch children updated.",
        data: {
          added: 0,
          removed: actualRemove.length,
          skippedSessions: 0,
          skipped: [],
        },
      });
    }

    const addObjIds = actualAdd.map((id) => new mongoose.Types.ObjectId(id));

    const busyRows = await Scheduling.aggregate([
      { $match: { "appointments.children.childId": { $in: addObjIds } } },
      { $unwind: "$appointments" },
      {
        $match: {
          "appointments.children.childId": { $in: addObjIds },
          "appointments.date": { $gte: utcMidnight(today) },
          "appointments.sessionType": { $nin: INACTIVE_TYPES },
        },
      },
      { $replaceRoot: { newRoot: "$appointments" } },
    ]);

    const childBusy = new Map(actualAdd.map((id) => [id, []]));
    for (const ap of busyRows) {
      for (const c of ap.children || []) {
        const list = childBusy.get(String(c.childId));
        if (list) list.push({ date: dateKeyOf(ap.date), startTime: ap.startTime, endTime: ap.endTime });
      }
    }

    const upcomingAps = await loadBatchAppointments(batch._id, {
      "appointments.sessionType": { $nin: INACTIVE_TYPES },
      "appointments.date": { $gte: utcMidnight(today) },
    });

    const eligibleAps = upcomingAps.filter((ap) => {
      const appointmentDate = dateKeyOf(ap.date);

      if (appointmentDate > today) return true;
      if (appointmentDate < today) return false;

      return toMin(ap.endTime) > toMin(nowTime);
    });

    const skipped = [];
    const ops = [];

    for (const ap of eligibleAps) {
      const date = dateKeyOf(ap.date);
      const already = new Set((ap.children || []).map((c) => String(c.childId)));
      const toAdd = [];

      for (const childId of actualAdd) {
        if (already.has(childId)) continue;
        const clash = (childBusy.get(childId) || []).some(
          (b) =>
            b.date === date
            && toMin(b.startTime) < toMin(ap.endTime)
            && toMin(ap.startTime) < toMin(b.endTime),
        );
        if (clash) {
          skipped.push({
            childId,
            date,
            startTime: ap.startTime,
            endTime: ap.endTime,
            reason: "Child already has another appointment.",
          });
        } else {
          toAdd.push({ childId, attendance_status: "Pending" });
        }
      }

      if (toAdd.length) {
        ops.push({
          updateOne: {
            filter: { "appointments._id": ap._id },
            update: { $push: { "appointments.$.children": { $each: toAdd } } },
          },
        });
      }
    }

    for (let i = 0; i < ops.length; i += 500) {
      await Scheduling.bulkWrite(ops.slice(i, i + 500), { ordered: false });
    }

    return res.json({
      success: true,
      message: "Batch children updated.",
      data: {
        added: actualAdd.length,
        removed: actualRemove.length,
        skippedSessions: skipped.length,
        skipped,
      },
    });
  } catch (error) {
    console.error(
      "updateBatchChildren:",
      error,
    );

    return res.status(500).json({
      success: false,
      message: "Failed to update batch children.",
    });
  }
};
exports.removeBatchAssignment = async (req, res) => {
  try {
    const { batchId, assignmentId } = req.params;

    if (!mongoose.isValidObjectId(batchId) || !mongoose.isValidObjectId(assignmentId)) {
      return res.status(400).json({ success: false, message: "Invalid batchId or assignmentId." });
    }

    const assignment = await BatchAssignment.findOne({ _id: assignmentId, batchId })
      .select("_id therapistId batchId speciality childIds")
      .lean();

    if (!assignment) {
      return res.status(404).json({ success: false, message: "Batch assignment not found." });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const nowTime = new Intl.DateTimeFormat("en-GB", {
      timeZone: st.tz,
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    }).format(new Date());
    const nowMin = toMin(nowTime);
    const schedules = await Scheduling.find({
      "appointments.batchAssignmentId": assignment._id,
    })
      .select("_id appointments._id appointments.date appointments.endTime appointments.batchAssignmentId")
      .lean();

    const futureAppointmentIds = [];
    const scheduleIds = [];

    for (const schedule of schedules) {
      let touched = false;

      for (const ap of schedule.appointments || []) {
        if (String(ap.batchAssignmentId) !== String(assignment._id)) continue;

        const date = dateKeyOf(ap.date);
        const isPast =
          date < today || (date === today && toMin(ap.endTime) <= nowMin);
        if (isPast) continue; 

        futureAppointmentIds.push(ap._id);
        touched = true;
      }

      if (touched) scheduleIds.push(schedule._id);
    }

    let removedAppointments = 0;

    if (futureAppointmentIds.length) {
      removedAppointments = futureAppointmentIds.length;

      await Scheduling.updateMany(
        { _id: { $in: scheduleIds } },
        { $pull: { appointments: { _id: { $in: futureAppointmentIds } } } },
      );
      await Scheduling.deleteMany({
        _id: { $in: scheduleIds },
        appointments: { $size: 0 },
      });
    }

    const hasPast = await Scheduling.exists({
      "appointments.batchAssignmentId": assignment._id,
    });

    if (hasPast) {
      return res.json({
        success: true,
        message: "Upcoming sessions removed. Past sessions were kept for history.",
        data: { removedAppointments },
      });
    }

    await BatchAssignment.deleteOne({ _id: assignment._id });

    const therapistStillAssigned = await BatchAssignment.exists({
      batchId,
      therapistId: assignment.therapistId,
    });

    if (!therapistStillAssigned) {
      await Batch.updateOne(
        { _id: batchId },
        { $pull: { therapistIds: assignment.therapistId } },
      );
    }

    const childIds = assignment.childIds || [];
    const keptChildren = [];
    let removedChildren = 0;

    if (childIds.length) {
      const busy = await Scheduling.aggregate([
        {
          $match: {
            therapistId: assignment.therapistId,
            "appointments.children.childId": { $in: childIds },
          },
        },
        { $unwind: "$appointments" },
        { $match: { "appointments.children.childId": { $in: childIds } } },
        { $unwind: "$appointments.children" },
        { $match: { "appointments.children.childId": { $in: childIds } } },
        { $group: { _id: "$appointments.children.childId" } },
      ]);

      const busySet = new Set(busy.map((b) => String(b._id)));
      const removable = childIds.filter((id) => !busySet.has(String(id)));

      for (const id of childIds) {
        if (busySet.has(String(id))) {
          keptChildren.push({
            childId: String(id),
            reason: "Child has appointments with this therapist.",
          });
        }
      }

      if (removable.length) {
        await TherapistAssignment.updateOne(
          { therapistId: assignment.therapistId, specialty: assignment.speciality },
          { $pull: { childIds: { $in: removable } } },
        );
        removedChildren = removable.length;
      }
    }

    return res.json({
      success: true,
      message: "Batch assignment removed.",
      data: {
        assignmentId: String(assignment._id),
        therapistId: String(assignment.therapistId),
        removedAppointments,
        removedChildren,
        keptChildren,
      },
    });
  } catch (error) {
    console.error("removeBatchAssignment:", error);
    return res.status(500).json({ success: false, message: "Failed to remove batch assignment." });
  }
};
exports.getBatchScheduleData = async (req, res) => {
  try {
    const { batchId } = req.params;

    if (!mongoose.isValidObjectId(batchId)) {
      return res.status(400).json({ success: false, message: "Invalid batchId." });
    }

    const [batch, assignments] = await Promise.all([
      Batch.findById(batchId)
        .populate("therapistIds", "fullName email")
        .populate("childrenIds", "fullName")
        .lean(),
      BatchAssignment.find({ batchId })
        .populate("therapistId", "fullName email")
        .populate("childIds", "fullName")
        .lean(),
    ]);

    if (!batch) {
      return res.status(404).json({ success: false, message: "Batch not found." });
    }

    const aps = await loadBatchAppointments(batch._id);
    const byAssignment = new Map();
    for (const ap of aps) {
      const key = String(ap.batchAssignmentId);
      if (!byAssignment.has(key)) byAssignment.set(key, []);
      byAssignment.get(key).push({
        _id: ap._id,
        date: dateKeyOf(ap.date),
        startTime: ap.startTime,
        endTime: ap.endTime,
        sessionType: ap.sessionType || "regular",
        status: INACTIVE_TYPES.includes(ap.sessionType) ? "cancelled" : "scheduled",
      });
    }
    for (const a of assignments) {
      a.sessions = (byAssignment.get(String(a._id)) || []).sort((x, y) =>
        x.date === y.date ? x.startTime.localeCompare(y.startTime) : x.date.localeCompare(y.date)
      );
    }
    return res.json({ success: true, data: { batch, assignments } });
  } catch (error) {
    console.error("getBatchScheduleData:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load batch schedule data.",
    });
  }
};
exports.getSessionSlotOptions = async (req, res) => {
  try {
    const loaded = await loadBatchAndAssignment(req.params.batchId, req.params.assignmentId);
    if (loaded.status) {
      return res.status(loaded.status).json({ success: false, message: loaded.message });
    }

    const minutes = Number(req.body.sessionMinutes);
    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const r = await freeSlotsForDate({
      batch: loaded.batch,
      therapistId: loaded.assignment.therapistId,
      date: req.body.date,
      minutes,
    });

    if (r.error) return res.status(400).json({ success: false, message: r.error });

    return res.json({ success: true, data: { slots: r.slots, reason: r.reason } });
  } catch (error) {
    console.error("getSessionSlotOptions:", error);
    return res.status(500).json({ success: false, message: "Failed to load available times." });
  }
};
exports.createAdditionalSession = async (req, res) => {
  try {
    const loaded = await loadBatchAndAssignment(req.params.batchId, req.params.assignmentId);
    if (loaded.status) {
      return res.status(loaded.status).json({ success: false, message: loaded.message });
    }
    const { batch, assignment } = loaded;
    const { date, startTime, endTime } = req.body;

    if (!TIME_REGEX.test(startTime || "") || !TIME_REGEX.test(endTime || "")) {
      return res.status(400).json({ success: false, message: "Start and end time must be HH:mm." });
    }
    const minutes = toMin(endTime) - toMin(startTime);
    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const r = await freeSlotsForDate({
      batch,
      therapistId: assignment.therapistId,
      date,
      minutes,
    });
    if (r.error) return res.status(400).json({ success: false, message: r.error });

    if (!r.slots.some((s) => s.startTime === startTime && s.endTime === endTime)) {
      return res.status(409).json({
        success: false,
        message: "That time is no longer available. Pick another one.",
      });
    }

    await createExtraSession({
      batch,
      assignment,
      date,
      startTime,
      endTime,
      sessionType: "additional",
      childIds: batch.childrenIds || [],
    });
    
    return res.status(201).json({
      success: true,
      message: "Additional class created.",
      data: { date, startTime, endTime, children: (batch.childrenIds || []).length },
    });
  } catch (error) {
    console.error("createAdditionalSession:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to create additional class.",
      error: error.message,
    });
  }
};
exports.postponeBatchSession = async (req, res) => {
  try {
    const { batchId, assignmentId, sessionId } = req.params;
    const loaded = await loadBatchAndAssignment(batchId, assignmentId);
    if (loaded.status) {
      return res.status(loaded.status).json({ success: false, message: loaded.message });
    }
    const { batch, assignment } = loaded;

    const { sessionId: appointmentId } = req.params;

    const originalDoc = await Scheduling.findOne(
      { appointments: { $elemMatch: { _id: appointmentId, batchAssignmentId: assignment._id } } },
      { therapistId: 1, "appointments.$": 1 },
    ).lean();
    const originalAp = originalDoc?.appointments?.[0];
    if (!originalAp) {
      return res.status(404).json({ success: false, message: "Session not found." });
    }
    if (INACTIVE_TYPES.includes(originalAp.sessionType)) {
      return res.status(400).json({ success: false, message: "This session was already postponed or cancelled." });
    }

    const st = await loadScheduleSettings();
    const origDate = dateKeyOf(originalAp.date);
    if (
      origDate < todayKey(st.tz) || (origDate === todayKey(st.tz) && toMin(originalAp.endTime) <= clockMinutes(st.tz))
    ) {
      return res.status(400).json({ success: false, message: "Past sessions can't be postponed." });
    }

    const createAlternate = req.body.createAlternate === true || req.body.createAlternate === "true";
    const minutes = toMin(originalAp.endTime) - toMin(originalAp.startTime);

    let alternate = null;
    if (createAlternate) {
      const { date, startTime, endTime } = req.body;

      if (!TIME_REGEX.test(startTime || "") || !TIME_REGEX.test(endTime || "")) {
        return res.status(400).json({ success: false, message: "Pick a date and time for the alternate session." });
      }
      if (toMin(endTime) - toMin(startTime) !== minutes) {
        return res.status(400).json({
          success: false,
          message: `The alternate session must be ${minutes} minutes long.`,
        });
      }

      const r = await freeSlotsForDate({
        batch,
        therapistId: assignment.therapistId,
        date,
        minutes,
      });
      if (r.error) return res.status(400).json({ success: false, message: r.error });

      if (!r.slots.some((s) => s.startTime === startTime && s.endTime === endTime)) {
        return res.status(409).json({
          success: false,
          message: "That time is no longer available. Pick another one.",
        });
      }

      const childIds = originalAp
        ? (originalAp.children || []).map((c) => c.childId)
        : batch.childrenIds || [];

      alternate = await createExtraSession({
        batch,
        assignment,
        date: req.body.date,
        startTime: req.body.startTime,
        endTime: req.body.endTime,
        sessionType: "alternate",
        originalAppointmentId: originalAp._id,
        childIds: (originalAp.children || []).map((c) => c.childId),
      });
    }

    await Scheduling.updateOne(
      { _id: originalDoc._id, "appointments._id": originalAp._id },
      { $set: { "appointments.$.sessionType": createAlternate ? "postponed" : "cancel" } },
    );

    return res.json({
      success: true,
      message: createAlternate ? "Session postponed and alternate session created." : "Session postponed.",
      data: { alternateSessionId: alternate ? String(alternate.appointmentId) : null },
    });
  } catch (error) {
    console.error("postponeBatchSession:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to postpone session.",
      error: error.message,
    });
  }
};
exports.deleteBatchSession = async (req, res) => {
  try {
    const { assignmentId, sessionId } = req.params;
    if (!mongoose.isValidObjectId(assignmentId) || !mongoose.isValidObjectId(sessionId)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }

    const doc = await Scheduling.findOne(
      { appointments: { $elemMatch: { _id: sessionId, batchAssignmentId: assignmentId } } },
      { therapistId: 1, "appointments.$": 1 },
    ).lean();
    const ap = doc?.appointments?.[0];
    if (!ap) return res.status(404).json({ success: false, message: "Session not found." });

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const date = dateKeyOf(ap.date);
    if (date < today || (date === today && toMin(ap.endTime) <= clockMinutes(st.tz))) {
      return res.status(400).json({ success: false, message: "Past sessions can't be deleted." });
    }

    await Scheduling.updateOne({ _id: doc._id }, { $pull: { appointments: { _id: ap._id } } });
    return res.json({ success: true, message: "Session deleted." });
  } catch (error) {
    console.error("deleteBatchSession:", error);
    return res.status(500).json({ success: false, message: "Failed to delete session." });
  }
};

const loadChild = (childId) =>
  mongoose.isValidObjectId(childId)
    ? User.findOne({ _id: childId, role: "Child" }, "fullName email").lean()
    : null;

exports.getChildSchedule = async (req, res) => {
  try {
    const { childId } = req.params;
    const child = await loadChild(childId);
    if (!child) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }

    const pastDays = Math.min(Math.max(parseInt(req.query.pastDays, 10) || 90, 1), 365);

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const nowMin = clockMinutes(st.tz);
    const cutoff = addDays(today, -pastDays);

    const [schedules, batches] = await Promise.all([
      Scheduling.find({ "appointments.children.childId": childId })
        .populate("therapistId", "fullName")
        .populate("appointments.batchId", "batchName")
        .populate("appointments.batchAssignmentId", "speciality")
        .lean(),

      Batch.find({ childrenIds: childId })
        .select("batchName speciality dateFrom dateTo maxChild childrenIds")
        .sort({ dateFrom: -1 })
        .lean(),
    ]);

    const therapistIds = [
      ...new Set(schedules.map((s) => String(s.therapistId?._id || s.therapistId))),
    ];
    const therapistAssignments = therapistIds.length
      ? await TherapistAssignment.find({ therapistId: { $in: therapistIds } }, "therapistId specialty").lean()
      : [];
    const specByTherapist = new Map();
    for (const a of therapistAssignments) {
      if (a.specialty && !specByTherapist.has(String(a.therapistId))) {
        specByTherapist.set(String(a.therapistId), a.specialty);
      }
    }

    const sessions = [];

    for (const sc of schedules) {
      const therapistKey = String(sc.therapistId?._id || sc.therapistId);

      for (const ap of sc.appointments || []) {
        const mine = (ap.children || []).find((c) => String(c.childId) === String(childId));
        if (!mine) continue;

        const date = dateKeyOf(ap.date);
        if (date < cutoff) continue;

        const isCustom = ap.type === "custom";
        const sessionType = ap.sessionType || "regular";
        const isPast = date < today || (date === today && toMin(ap.endTime) <= nowMin);

        sessions.push({
          id: String(ap._id),
          date,
          startTime: ap.startTime,
          endTime: ap.endTime,
          type: ap.type,
          sessionType,
          batchId: ap.batchId?._id ? String(ap.batchId._id) : ap.batchId ? String(ap.batchId) : null,
          batchName: isCustom ? null : ap.batchId?.batchName || "Batch Session",
          speciality: ap.batchAssignmentId?.speciality || specByTherapist.get(therapistKey) || null,
          therapistId: therapistKey,
          therapistName: sc.therapistId?.fullName || "Therapist",
          attendance: mine.attendance_status || "Pending",
          isPast,
          canCancel: isCustom && !isPast && !INACTIVE_TYPES.includes(sessionType),
          canPostpone: isCustom && !isPast && !INACTIVE_TYPES.includes(sessionType),
        });
      }
    }

    sessions.sort((a, b) => a.date === b.date ? a.startTime.localeCompare(b.startTime) : a.date.localeCompare(b.date));

    const upcoming = sessions.filter((s) => !s.isPast);
    const past = sessions.filter((s) => s.isPast).reverse();

    const counted = past.filter((s) => !INACTIVE_TYPES.includes(s.sessionType));
    const stats = {
      present: counted.filter((s) => s.attendance === "Complete").length,
      absent: counted.filter((s) => s.attendance === "Absent").length,
      notMarked: counted.filter((s) => s.attendance === "Pending").length,
      total: counted.length,
    };

    return res.json({
      success: true,
      data: {
        today,
        pastDays,
        child,
        stats,
        batches: batches.map((b) => ({
          _id: b._id,
          batchName: b.batchName,
          speciality: b.speciality,
          dateFrom: b.dateFrom,
          dateTo: b.dateTo,
          maxChild: b.maxChild,
          childCount: (b.childrenIds || []).length,
        })),
        upcoming,
        past,
      },
    });
  } catch (error) {
    console.error("getChildSchedule:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load child schedule.",
      error: error.message,
    });
  }
};
exports.getSessions = async (req, res) => {
  try {
    const scope = req.query.scope === "past" ? "past" : "upcoming";
    const type = ["batch", "custom"].includes(req.query.type) ? req.query.type : "all";
    const search = String(req.query.search || "").trim().toLowerCase();
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 15, 1), 50);

    const settings = await SystemSetting.findOne().lean();
    const tz = settings?.timezone || "Asia/Karachi";
    const today = new Date().toLocaleDateString("en-CA", { timeZone: tz });
    const nowMin = clockMinutes(tz);
    const cutoff = new Date(Date.parse(`${today}T00:00:00Z`) - PAST_DAYS * DAY_MS)
      .toISOString()
      .slice(0, 10);
    const range = [
      "this_week",
      "last_week",
      "this_month",
      "last_month",
    ].includes(req.query.range)
      ? req.query.range
      : "all";

    let rangeFrom = null;
    let rangeTo = null;

    if (range !== "all") {
      const weekStart = addDays(
        today,
        -WORKING_DAYS.indexOf(weekdayOf(today))
      );

      switch (range) {
        case "this_week":
          rangeFrom = weekStart;
          rangeTo = addDays(weekStart, 6);
          break;

        case "last_week":
          rangeFrom = addDays(weekStart, -7);
          rangeTo = addDays(weekStart, -1);
          break;

        case "this_month": {
          const firstDayThisMonth = `${today.slice(0, 7)}-01`;

          rangeFrom = firstDayThisMonth;

          if (scope === "upcoming") {
            const firstDayNextMonth = addDays(
              addDays(firstDayThisMonth, 32).slice(0, 7) + "-01",
              0
            );

            rangeTo = addDays(firstDayNextMonth, -1);
          } else {
            rangeTo = today;
          }

          break;
        }

        case "last_month": {
          const firstDayThisMonth = `${today.slice(0, 7)}-01`;
          rangeTo = addDays(firstDayThisMonth, -1);
          rangeFrom = `${rangeTo.slice(0, 7)}-01`;
          break;
        }

        default:
          break;
      }
    }

    const [ty, tm] = today.split("-").map(Number);
    const [cy, cm] = cutoff.split("-").map(Number);

    const monthFilter = scope === "upcoming"
      ? { $or: [{ year: { $gt: ty } }, { year: ty, month: { $gte: tm } }] }
      : {
        $and: [
          { $or: [{ year: { $lt: ty } }, { year: ty, month: { $lte: tm } }] },
          { $or: [{ year: { $gt: cy } }, { year: cy, month: { $gte: cm } }] },
        ],
      };

    const schedules = await Scheduling.find(monthFilter)
      .populate("therapistId", "fullName")
      .populate("appointments.batchId", "batchName")
      .populate("appointments.batchAssignmentId", "speciality")
      .populate("appointments.children.childId", "fullName")
      .lean();
    const therapistIds = [
      ...new Set(
        schedules.map((sc) =>
          String(sc.therapistId?._id || sc.therapistId)
        )
      ),
    ];
    const therapistAssignments = await TherapistAssignment.find({
      therapistId: { $in: therapistIds },
    })
      .select("therapistId specialty")
      .lean();
    const specialtyMap = new Map();

    for (const assignment of therapistAssignments) {
      const id = String(assignment.therapistId);
      if (!specialtyMap.has(id) && assignment.specialty) {
        specialtyMap.set(id, assignment.specialty);
      }
    }

    const items = [];

    for (const sc of schedules) {
      const therapistId = String(sc.therapistId?._id || sc.therapistId);
      const therapistName = sc.therapistId?.fullName || "Therapist";

      for (const ap of sc.appointments || []) {
        if (type !== "all" && ap.type !== type) continue;

        const date = dateKeyOf(ap.date);
        if ((rangeFrom && date < rangeFrom) || (rangeTo && date > rangeTo)) continue;
        const isPast = date < today || (date === today && toMin(ap.endTime) <= nowMin);

        if ((scope === "past") !== isPast) continue;
        if (scope === "past" && date < cutoff) continue;

        const isCustom = ap.type === "custom";
        const sessionType = ap.sessionType || "regular";

        const children = (ap.children || []).map((c) => ({
          childId: String(c.childId?._id || c.childId),
          fullName: c.childId?.fullName || "Child",
          attendance: c.attendance_status || "Pending",
        }));

        const batchName = isCustom ? null : ap.batchId?.batchName || "Batch Session";

        if (search) {
          const hay = [therapistName, batchName || "custom", ...children.map((c) => c.fullName)]
            .join(" ")
            .toLowerCase();
          if (!hay.includes(search)) continue;
        }

        items.push({
          id: String(ap._id),
          date,
          startTime: ap.startTime,
          endTime: ap.endTime,
          type: ap.type,
          sessionType,
          batchId: ap.batchId?._id ? String(ap.batchId._id) : ap.batchId ? String(ap.batchId) : null,
          batchName,
          speciality: isCustom
                      ? specialtyMap.get(therapistId) || null
                      : ap.batchAssignmentId?.speciality || null,
          therapistId,
          therapistName,
          children,
          isPast,
          canCancel: isCustom && !isPast && !INACTIVE_TYPES.includes(sessionType),
          canPostpone: isCustom && !isPast && !INACTIVE_TYPES.includes(sessionType),
        });
      }
    }

    items.sort((a, b) => {
      const cmp = a.date === b.date ? a.startTime.localeCompare(b.startTime) : a.date.localeCompare(b.date);
      return scope === "past" ? -cmp : cmp;
    });

    const start = (page - 1) * limit;

    return res.json({
      success: true,
      today,
      page,
      totalCount: items.length,
      hasMore: start + limit < items.length,
      data: items.slice(start, start + limit),
    });
  } catch (error) {
    console.error("getSessions:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load schedule.",
      error: error.message,
    });
  }
};
exports.getChildBatchOptions = async (req, res) => {
  try {
    const { childId } = req.params;
    const child = await loadChild(childId);
    if (!child) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);

    const batches = await Batch.find({
      childrenIds: { $ne: childId },
      dateTo: { $gte: utcMidnight(today) },
      $expr: { $lt: [{ $size: { $ifNull: ["$childrenIds", []] } }, "$maxChild"] },
    })
      .select("batchName speciality dateFrom dateTo maxChild childrenIds")
      .sort({ dateFrom: 1 })
      .lean();

    return res.json({
      success: true,
      data: batches.map((b) => {
        const count = (b.childrenIds || []).length;
        return {
          _id: b._id,
          batchName: b.batchName,
          speciality: b.speciality,
          dateFrom: b.dateFrom,
          dateTo: b.dateTo,
          maxChild: b.maxChild,
          childCount: count,
          remaining: Math.max(b.maxChild - count, 0),
        };
      }),
    });
  } catch (error) {
    console.error("getChildBatchOptions:", error);
    return res.status(500).json({ success: false, message: "Failed to load batches." });
  }
};
exports.getChildCustomSlotOptions = async (req, res) => {
  try {
    const { childId } = req.params;
    const { therapistId, date } = req.body;
    const minutes = Number(req.body.sessionMinutes);

    if (!mongoose.isValidObjectId(childId)) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }
    if (!mongoose.isValidObjectId(therapistId)) {
      return res.status(400).json({ success: false, message: "Select a therapist." });
    }
    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const [child, r] = await Promise.all([
      loadChild(childId),
      computeFreeSlots({ therapistId, childIds: [childId], date, minutes, step: minutes, includeBooked: true }),
    ]);

    if (!child) return res.status(404).json({ success: false, message: "Child not found." });
    if (r.error) return res.status(400).json({ success: false, message: r.error });

    return res.json({ success: true, data: { slots: r.slots, reason: r.reason, onLeave: !!r.onLeave }});
  } catch (error) {
    console.error("getChildCustomSlotOptions:", error);
    return res.status(500).json({ success: false, message: "Failed to load available times." });
  }
};
exports.createChildCustomAppointment = async (req, res) => {
  try {
    const { childId } = req.params;
    const { therapistId, date, startTime, endTime } = req.body;

    if (!mongoose.isValidObjectId(childId)) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }
    if (!mongoose.isValidObjectId(therapistId)) {
      return res.status(400).json({ success: false, message: "Select a therapist." });
    }
    if (!TIME_REGEX.test(startTime || "") || !TIME_REGEX.test(endTime || "")) {
      return res.status(400).json({ success: false, message: "Start and end time must be HH:mm." });
    }
    const minutes = toMin(endTime) - toMin(startTime);
    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const [child, therapist, r] = await Promise.all([
      loadChild(childId),
      User.exists({ _id: therapistId, role: "Therapist" }),
      computeFreeSlots({ therapistId, childIds: [childId], date, minutes }),
    ]);

    if (!child) return res.status(404).json({ success: false, message: "Child not found." });
    if (!therapist) return res.status(404).json({ success: false, message: "Therapist not found." });
    if (r.error) return res.status(400).json({ success: false, message: r.error });
    if (r.onLeave) {
      return res.status(409).json({ success: false, message: LEAVE_MSG });
    }
    if (!r.slots.some((s) => s.startTime === startTime && s.endTime === endTime)) {
      return res.status(409).json({
        success: false,
        message: "That time is no longer available. Pick another one.",
      });
    }

    const d = utcMidnight(date);

    await Scheduling.updateOne(
      { therapistId, year: d.getUTCFullYear(), month: d.getUTCMonth() + 1 },
      {
        $push: {
          appointments: {
            _id: new mongoose.Types.ObjectId(),
            date: d,
            startTime,
            endTime,
            type: "custom",
            sessionType: "regular",
            session_status: "Upcoming",
            children: [{ childId, attendance_status: "Pending" }],
          },
        },
      },
      { upsert: true },
    );
    await TherapistAssignment.updateMany(
      { therapistId: new mongoose.Types.ObjectId(therapistId) },
      {
        $addToSet: {
          childIds: new mongoose.Types.ObjectId(childId),
        },
      }
    );
    await sendNotifications({
      title: "New Session Scheduled",
      message: `A new session has been scheduled for ${date} from ${startTime} to ${endTime}.`,
      type: "Appointment",
      audience: "users",
      users: [String(childId), String(therapistId)],
      createdBy: req.user?.id,
      sendPush: true,
    });

    return res.status(201).json({
      success: true,
      message: "Appointment created.",
      data: { date, startTime, endTime },
    });
  } catch (error) {
    console.error("createChildCustomAppointment:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to create appointment.",
      error: error.message,
    });
  }
};
exports.deleteChildCustomAppointment = async (req, res) => {
  try {
    const { childId, appointmentId } = req.params;

    if (!mongoose.isValidObjectId(childId) || !mongoose.isValidObjectId(appointmentId)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }

    const doc = await Scheduling.findOne({
      appointments: {
        $elemMatch: { _id: appointmentId, type: "custom", "children.childId": childId },
      },
    });
    const ap = doc?.appointments.id(appointmentId);

    if (!ap) {
      return res.status(404).json({ success: false, message: "Appointment not found." });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const date = dateKeyOf(ap.date);
    if (date < today || (date === today && toMin(ap.endTime) <= clockMinutes(st.tz))) {
      return res.status(400).json({
        success: false,
        message: "Past appointments can't be cancelled.",
      });
    }

    if ((ap.children || []).length > 1) {
      ap.children = ap.children.filter((c) => String(c.childId) !== String(childId));
    } else {
      doc.appointments.pull(ap._id);
    }

    await doc.save();
    const otherAppointment = await Scheduling.exists({
      therapistId: doc.therapistId,
      "appointments.children.childId": new mongoose.Types.ObjectId(childId),
    });
    const otherBatchAssignment = await BatchAssignment.exists({
      therapistId: doc.therapistId,
      childIds: new mongoose.Types.ObjectId(childId),
    });
    if (!otherAppointment && !otherBatchAssignment) {
      await TherapistAssignment.updateMany(
        { therapistId: doc.therapistId },
        {
          $pull: {
            childIds: new mongoose.Types.ObjectId(childId),
          },
        }
      );
    }
    return res.json({ success: true, message: "Appointment cancelled." });
  } catch (error) {
    console.error("deleteChildCustomAppointment:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to cancel appointment.",
      error: error.message,
    });
  }
};
const BULK_DELETE_TYPES = ["custom"];

exports.bulkDeleteAppointments = async (req, res) => {
  try {
    const raw = Array.isArray(req.body?.items) ? req.body.items : [];
    if (!raw.length) {
      return res.status(400).json({ success: false, message: "Select at least one appointment." });
    }
    if (raw.length > 200) {
      return res.status(400).json({ success: false, message: "Too many appointments selected." });
    }

    const byAppointment = new Map();
    for (const it of raw) {
      const appointmentId = String(it?.appointmentId || "");
      const childId = it?.childId ? String(it.childId) : null;
      if (
        !mongoose.isValidObjectId(appointmentId) ||
        (childId && !mongoose.isValidObjectId(childId))
      ) {
        return res.status(400).json({ success: false, message: "Invalid id." });
      }
      byAppointment.set(appointmentId, { appointmentId, childId });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const nowMin = clockMinutes(st.tz);
    const isPastAp = (ap) => {
      const d = dateKeyOf(ap.date);
      return d < today || (d === today && toMin(ap.endTime) <= nowMin);
    };

    const docs = await Scheduling.find({
      "appointments._id": { $in: [...byAppointment.keys()] },
    });

    const deleted = [];
    const skipped = [];
    const found = new Set();
    const cleanup = new Map();

    for (const doc of docs) {
      let changed = false;

      for (const ap of [...doc.appointments]) {
        const id = String(ap._id);
        const item = byAppointment.get(id);
        if (!item) continue;
        found.add(id);

        if (!BULK_DELETE_TYPES.includes(ap.type)) {
          skipped.push({ appointmentId: id, reason: "This type can't be bulk deleted." });
          continue;
        }
        if (isPastAp(ap)) {
          skipped.push({
            appointmentId: id,
            reason: "Past appointments can't be deleted."
          });
          continue;
        }

        if (["cancel", "postponed","postpond"].includes(ap.sessionType)) {
          skipped.push({
            appointmentId: id,
            reason: "Cancelled or postponed appointments can't be deleted."
          });
          continue;
        }

        const kids = ap.children || [];

        if (item.childId) {
          if (!kids.some((c) => String(c.childId) === item.childId)) {
            skipped.push({ appointmentId: id, reason: "Child is not in this appointment." });
            continue;
          }
          if (kids.length > 1) {
            ap.children = kids.filter((c) => String(c.childId) !== item.childId);
          } else {
            doc.appointments.pull(ap._id);
          }
          cleanup.set(`${doc.therapistId}:${item.childId}`, {
            therapistId: doc.therapistId,
            childId: item.childId,
          });
        } else if (kids.length === 0) {
          doc.appointments.pull(ap._id);
        } else {
          skipped.push({ appointmentId: id, reason: "Child id is required." });
          continue;
        }

        changed = true;
        deleted.push(id);
      }

      for (const ap of [...doc.appointments]) {
        if (ap.type === "custom" && !(ap.children || []).length && !isPastAp(ap)) {
          doc.appointments.pull(ap._id);
          changed = true;
        }
      }

      if (!changed) continue;

      if (!doc.appointments.length) {
        await doc.deleteOne(); 
      } else {
        await doc.save();
      }
    }

    for (const id of byAppointment.keys()) {
      if (!found.has(id)) skipped.push({ appointmentId: id, reason: "Appointment not found." });
    }

    for (const { therapistId, childId } of cleanup.values()) {
      const cid = new mongoose.Types.ObjectId(childId);
      const stillBooked = await Scheduling.exists({
        therapistId,
        "appointments.children.childId": cid,
      });
      const inBatch = await BatchAssignment.exists({ therapistId, childIds: cid });
      if (!stillBooked && !inBatch) {
        await TherapistAssignment.updateMany({ therapistId }, { $pull: { childIds: cid } });
      }
    }
    console.log(deleted,skipped)
    return res.json({
      success: true,
      deletedCount: deleted.length,
      skipped,
      message: `${deleted.length} appointment(s) deleted.`,
    });
  } catch (error) {
    console.error("bulkDeleteAppointments:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete appointments.",
      error: error.message,
    });
  }
};

const PACKAGE_TYPE = "per-month";

const parsePackageBody = (body = {}) => {
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const price = Number(body.price);

  if (!name) {
    return { error: "Package name is required." };
  }

  if (!Number.isFinite(price) || price <= 0) {
    return { error: "Monthly rate must be a number greater than 0." };
  }

  return { name, price };
};


exports.getAllPackages = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(
      Math.max(parseInt(req.query.limit, 10) || 5, 1),
      50
    );
    const skip = (page - 1) * limit;

    const search = String(req.query.search || "").trim();

    let filter = {};

    if (search) {
      const escapedSearch = escapeRegex(search);

      const conditions = [
        { name: { $regex: escapedSearch, $options: "i" } },
      ];

      // Search by exact package amount
      const amount = Number(search);

      if (Number.isFinite(amount) && search !== "") {
        conditions.push({ price: amount });
      }

      filter = { $or: conditions };
    }

    const [packages, total] = await Promise.all([
      Package.find(filter)
        .populate("createdBy", "fullName email")
        .sort({ createdAt: -1, _id: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      Package.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      page,
      limit,
      count: packages.length,
      total,
      totalPages: Math.ceil(total / limit),
      hasMore: skip + packages.length < total,
      data: packages,
    });
  } catch (error) {
    console.error("getAllPackages:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch packages.",
    });
  }
};

exports.getPackageById = async (req, res) => {
  try {
    const { packageId } = req.params;

    if (!mongoose.isValidObjectId(packageId)) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    const packageData = await Package.findById(packageId)
      .populate("createdBy", "fullName email")
      .lean();

    if (!packageData) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    return res.status(200).json({ success: true, data: packageData });
  } catch (error) {
    console.error("getPackageById:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch package.",
    });
  }
};

exports.createPackage = async (req, res) => {
  try {
    const userId = req.user?._id || req.user?.id;

    if (!userId) {
      return res.status(401).json({ success: false, message: "Unauthorized." });
    }

    const parsed = parsePackageBody(req.body);
    if (parsed.error) {
      return res.status(400).json({ success: false, message: parsed.error });
    }

    const packageData = await Package.create({
      name: parsed.name,
      type: PACKAGE_TYPE,
      price: parsed.price,
      createdBy: userId,
    });

    return res.status(201).json({
      success: true,
      message: "Package created successfully.",
      data: packageData,
    });
  } catch (error) {
    console.error("createPackage:", error);

    if (error.name === "ValidationError") {
      return res.status(400).json({ success: false, message: error.message });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to create package.",
    });
  }
};

exports.updatePackage = async (req, res) => {
  try {
    const { packageId } = req.params;

    if (!mongoose.isValidObjectId(packageId)) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    const parsed = parsePackageBody(req.body);
    if (parsed.error) {
      return res.status(400).json({ success: false, message: parsed.error });
    }

    const packageData = await Package.findById(packageId);

    if (!packageData) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    if (parsed.price < packageData.price) {
      const conflicting = await User.countDocuments({
        role: "Child",
        packageId,
        discountedPrice: { $ne: null, $gte: parsed.price },
      });

      if (conflicting > 0) {
        return res.status(409).json({
          success: false,
          message:
            `${conflicting} child(ren) have a discount price equal to or above PKR ${parsed.price}. Update their discount first.`,
        });
      }
    }

    packageData.name = parsed.name;
    packageData.price = parsed.price;
    packageData.type = PACKAGE_TYPE;

    await packageData.save();

    return res.status(200).json({
      success: true,
      message: "Package updated successfully.",
      data: packageData,
    });
  } catch (error) {
    console.error("updatePackage:", error);

    if (error.name === "ValidationError") {
      return res.status(400).json({ success: false, message: error.message });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to update package.",
    });
  }
};

exports.deletePackage = async (req, res) => {
  try {
    const { packageId } = req.params;

    if (!mongoose.isValidObjectId(packageId)) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    const packageData = await Package.findById(packageId).lean();

    if (!packageData) {
      return res.status(404).json({ success: false, message: "Package not found." });
    }

    const assigned = await User.countDocuments({ role: "Child", packageId });

    if (assigned > 0) {
      return res.status(409).json({
        success: false,
        message: `This package is assigned to ${assigned} child(ren). Remove it from them before deleting.`,
      });
    }

    await Package.findByIdAndDelete(packageId);

    return res.status(200).json({
      success: true,
      message: "Package deleted successfully.",
    });
  } catch (error) {
    console.error("deletePackage:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete package.",
    });
  }
};


const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;

const shapeService = (s) => ({
  id: String(s._id),
  label: s.label,
  color: s.color,
  bg: s.bg,
  isActive: s.isActive,
});

const validateServiceIds = async (value, { allowInactive = false } = {}) => {
  const ids = [...new Set((Array.isArray(value) ? value : []).map(String))];
  if (!ids.length || ids.some((id) => !mongoose.isValidObjectId(id))) {
    return { error: "Invalid service selected." };
  }
  const filter = { _id: { $in: ids } };
  if (!allowInactive) filter.isActive = true;
  if ((await Service.countDocuments(filter)) !== ids.length) {
    return { error: "One or more selected services are not available." };
  }
  return { ids };
};

exports.getServices = async (req, res) => {
  try {
    const { search = "", includeInactive, status, page, limit } = req.query;

    const filter = {};

    if (status === "active") filter.isActive = true;
    else if (status === "inactive") filter.isActive = false;
    else if (status !== "all" && includeInactive !== "true") filter.isActive = true;

    const term = String(search).trim();
    if (term) filter.label = { $regex: escapeRegex(term), $options: "i" };

    const query = Service.find(filter).sort({ createdAt: 1, _id: 1 }).lean();

    if (page === undefined) {
      const list = await query;
      return res.status(200).json({ success: true, data: list.map(shapeService) });
    }

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 50);

    const [totalCount, list] = await Promise.all([
      Service.countDocuments(filter),
      query.skip((pageNum - 1) * limitNum).limit(limitNum),
    ]);

    return res.status(200).json({
      success: true,
      data: list.map(shapeService),
      hasMore: pageNum * limitNum < totalCount,
      totalCount,
    });
  } catch (error) {
    console.error("getServices:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch services." });
  }
};

exports.createService = async (req, res) => {
  try {
    const label = String(req.body.label || "").trim();
    const { color, bg } = req.body;

    if (!label) return res.status(400).json({ success: false, message: "Service name is required." });
    if (!HEX.test(color || "") || !HEX.test(bg || "")) {
      return res.status(400).json({ success: false, message: "Valid colors are required." });
    }

    const created = await Service.create({ label, color, bg });
    return res.status(201).json({ success: true, data: shapeService(created) });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "This service already exists." });
    }
    console.error("createService:", error);
    return res.status(500).json({ success: false, message: "Failed to create service." });
  }
};

exports.updateService = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }
    const doc = await Service.findById(req.params.id);
    if (!doc) return res.status(404).json({ success: false, message: "Service not found." });

    const { label, color, bg, isActive } = req.body;

    if (label !== undefined) {
      if (!String(label).trim()) {
        return res.status(400).json({ success: false, message: "Service name is required." });
      }
      doc.label = String(label).trim();
    }
    if (color !== undefined) {
      if (!HEX.test(color)) return res.status(400).json({ success: false, message: "Invalid color." });
      doc.color = color;
    }
    if (bg !== undefined) {
      if (!HEX.test(bg)) return res.status(400).json({ success: false, message: "Invalid color." });
      doc.bg = bg;
    }
    if (isActive !== undefined) doc.isActive = !!isActive;

    await doc.save();
    return res.status(200).json({ success: true, data: shapeService(doc) });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "This service already exists." });
    }
    console.error("updateService:", error);
    return res.status(500).json({ success: false, message: "Failed to update service." });
  }
};

exports.deleteService = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid id." });
    }
    const doc = await Service.findById(req.params.id);
    if (!doc) return res.status(404).json({ success: false, message: "Service not found." });

    const id = String(doc._id);
    const [inBatch, inPackage, inTherapist] = await Promise.all([
      Batch.exists({ speciality: id }),
      TherapistAssignment.exists({ specialty: id }),
    ]);

    if (inBatch || inTherapist) {
      return res.status(409).json({
        success: false,
        message: "This service is used by batches or therapists. Deactivate it instead.",
      });
    }

    await doc.deleteOne();
    return res.status(200).json({ success: true, message: "Service deleted." });
  } catch (error) {
    console.error("deleteService:", error);
    return res.status(500).json({ success: false, message: "Failed to delete service." });
  }
};

const DEFAULTS = {
  clinicName: "",
  address: "",
  phone: "",
  email: "",
  timezone: "Asia/Karachi",
  clinicStartTime: "09:00",
  clinicEndTime: "17:00",
  workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
};

const EDITABLE_FIELDS = Object.keys(DEFAULTS);

const isValidTimezone = (tz) => {
  try {
    new Intl.DateTimeFormat("en-GB", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
};

const saveSettings = async (payload) => {
  let settings = await SystemSetting.findOne();
  if (!settings) settings = new SystemSetting();
  settings.set(payload);
  await settings.save();
  return settings;
};

exports.getSettings = async (req, res) => {
  try {
    const settings = await SystemSetting.findOne().lean();
    return res.status(200).json({
      success: true,
      configured: Boolean(settings),
      data: settings || DEFAULTS,
    });
  } catch (error) {
    console.error("getSettings:", error);
    return res.status(500).json({ success: false, message: "Failed to load settings." });
  }
};

exports.updateSettings = async (req, res) => {
  try {
    const payload = {};
    for (const key of EDITABLE_FIELDS) {
      if (req.body[key] !== undefined) payload[key] = req.body[key];
    }

    if (payload.timezone !== undefined && !isValidTimezone(payload.timezone)) {
      return res.status(400).json({
        success: false,
        message: "Invalid timezone. Use a format like Asia/Karachi.",
      });
    }

    if (payload.email && !/^\S+@\S+\.\S+$/.test(payload.email)) {
      return res.status(400).json({ success: false, message: "Invalid email address." });
    }

    if (payload.workingDays !== undefined) {
      if (!Array.isArray(payload.workingDays)) {
        return res.status(400).json({ success: false, message: "workingDays must be an array." });
      }
      payload.workingDays = WORKING_DAYS.filter((d) => payload.workingDays.includes(d)); // dedupe + order
      if (payload.workingDays.length === 0) {
        return res.status(400).json({
          success: false,
          message: "Select at least one working day.",
        });
      }
    }

    let settings;
    try {
      settings = await saveSettings(payload);
    } catch (err) {
      if (err?.code === 11000) settings = await saveSettings(payload);
      else throw err;
    }

    return res.status(200).json({
      success: true,
      message: "Settings saved.",
      data: settings,
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const first = Object.values(error.errors)[0]?.message || "Invalid settings.";
      return res.status(400).json({ success: false, message: first });
    }
    console.error("updateSettings:", error);
    return res.status(500).json({ success: false, message: "Failed to save settings." });
  }
};
exports.sendFeedbackReminderNotification = async (req, res) => {
  try {
    const { appointmentId } = req.body;

    if (!appointmentId) {
      return res.status(400).json({
        success: false,
        message: "appointmentId is required.",
      });
    }

    const schedulingDoc = await Scheduling.findOne({
      "appointments._id": appointmentId,
    })
      .populate("therapistId", "fullName")
      .populate("appointments.children.childId", "fullName");

    if (!schedulingDoc) {
      return res.status(404).json({
        success: false,
        message: "Appointment session not found.",
      });
    }

    const appointment = schedulingDoc.appointments.id(appointmentId);

    if (!appointment) {
      return res.status(404).json({
        success: false,
        message: "Appointment not found.",
      });
    }

    const recipientUserIds = [];

    const therapist = schedulingDoc.therapistId;

    if (therapist?._id) {
      recipientUserIds.push(String(therapist._id));
    }

    (appointment.children || []).forEach((child) => {
      if (child.childId?._id) {
        recipientUserIds.push(String(child.childId._id));
      }
    });

    const uniqueRecipients = [...new Set(recipientUserIds)];

    if (!uniqueRecipients.length) {
      return res.status(400).json({
        success: false,
        message: "No valid therapist or child recipients found.",
      });
    }

    const formattedDate = appointment.date
      ? new Date(appointment.date).toLocaleDateString("en-GB", {
          month: "short",
          day: "numeric",
          year: "numeric",
        })
      : "upcoming session";

    const senderId = req.user?._id || process.env.SYSTEM_USER_ID;

    if (!senderId) {
      return res.status(500).json({
        success: false,
        message: "Notification sender is not configured.",
      });
    }

    const notification = await sendNotifications({
      title: "Session Feedback Reminder",
      message: `Please submit your feedback for the session on ${formattedDate} (${appointment.startTime || ""} - ${appointment.endTime || ""}).`,
      type: "Reminder",
      audience: "users",
      users: uniqueRecipients,
      createdBy: senderId,
      sendPush:true
    });

    return res.status(200).json({
      success: true,
      message: "Feedback reminder sent successfully to therapist and children.",
      data: notification,
    });
  } catch (error) {
    console.error("Send Feedback Reminder Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to send feedback reminder.",
      error: error.message,
    });
  }
};

const CUSTOM_MAX_RANGE_DAYS = 180;
const MAX_CUSTOM_SESSIONS = 400;

const rangeLabel = (x) => `${to12(minutesToTime(x.a))}-${to12(minutesToTime(x.b))}`;
const findHit = (list, date, a, b) => list.find((x) => x.date === date && x.a < b && a < x.b);

const checkCustomRange = (startDate, endDate, today) => {
  if (!isValidDate(startDate) || !isValidDate(endDate)) return "Pick a valid start and end date.";
  if (startDate < today) return "Start date cannot be in the past.";
  if (endDate < startDate) return "End date cannot be before start date.";
  if ((Date.parse(`${endDate}T00:00:00Z`) - Date.parse(`${startDate}T00:00:00Z`)) / DAY_MS > CUSTOM_MAX_RANGE_DAYS) {
    return `Date range can be at most ${CUSTOM_MAX_RANGE_DAYS} days.`;
  }
  return null;
};
const loadCustomAppointment = async (childId, appointmentId) => {
  if (!mongoose.isValidObjectId(childId) || !mongoose.isValidObjectId(appointmentId)) {
    return { status: 400, error: "Invalid id." };
  }
 
  const doc = await Scheduling.findOne({
    appointments: {
      $elemMatch: { _id: appointmentId, type: "custom", "children.childId": childId },
    },
  });
  const ap = doc?.appointments.id(appointmentId);
  if (!ap) return { status: 404, error: "Appointment not found." };
 
  if (INACTIVE_TYPES.includes(ap.sessionType)) {
    return { status: 400, error: "This appointment was already cancelled or postponed." };
  }
 
  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);
  const date = dateKeyOf(ap.date);
  if (date < today || (date === today && toMin(ap.endTime) <= clockMinutes(st.tz))) {
    return { status: 400, error: "Past appointments can't be changed." };
  }
 
  return { doc, ap };
};
const loadCustomBusy = async ({ therapistId, childId, from, to }) => {
  const tObj = new mongoose.Types.ObjectId(String(therapistId));
  const cObj = new mongoose.Types.ObjectId(String(childId));
  const [fy] = from.split("-").map(Number);
  const [ty] = to.split("-").map(Number);
  const gte = utcMidnight(from);
  const lte = utcMidnight(to);

  const rows = await Scheduling.aggregate([
    {
      $match: {
        $or: [
          { therapistId: tObj, year: { $gte: fy, $lte: ty } },
          { appointments: { $elemMatch: { date: { $gte: gte, $lte: lte }, "children.childId": cObj } } },
        ],
      },
    },
    { $unwind: "$appointments" },
    {
      $match: {
        "appointments.date": { $gte: gte, $lte: lte },
        "appointments.sessionType": { $nin: INACTIVE_TYPES },
      },
    },
    {
      $project: {
        _id: 0,
        mine: { $eq: ["$therapistId", tObj] },
        date: "$appointments.date",
        startTime: "$appointments.startTime",
        endTime: "$appointments.endTime",
        childIds: "$appointments.children.childId",
      },
    },
  ]);

  const therapist = [];
  const child = [];
  for (const r of rows) {
    const item = { date: dateKeyOf(r.date), a: toMin(r.startTime), b: toMin(r.endTime) };
    if (r.mine) therapist.push(item);
    if ((r.childIds || []).some((id) => String(id) === String(childId))) child.push(item);
  }
  return { therapist, child };
};
const analyzeCustomPlan = async (childId, body) => {
  const { therapistId } = body;
  const minutes = Number(body.sessionMinutes);
  const sessions = Array.isArray(body.sessions) ? body.sessions : [];

  if (!mongoose.isValidObjectId(childId)) return { status: 404, error: "Child not found." };
  if (!mongoose.isValidObjectId(therapistId)) return { status: 400, error: "Select a therapist." };
  if (!SESSION_TIMES.includes(minutes)) {
    return { status: 400, error: "Session time must be 30, 45, 60, 90 or 120 minutes." };
  }
  if (!sessions.length) return { status: 400, error: "Select at least one session." };
  if (sessions.length > MAX_CUSTOM_SESSIONS) {
    return { status: 400, error: `You can create at most ${MAX_CUSTOM_SESSIONS} sessions at once.` };
  }

  const st = await loadScheduleSettings();
  const today = todayKey(st.tz);
  const nowMin = clockMinutes(st.tz);

  const seen = new Set();
  const planned = [];
  for (const s of sessions) {
    if (!isValidDate(s?.date) || !TIME_REGEX.test(s?.startTime || "") || !TIME_REGEX.test(s?.endTime || "")) {
      return { status: 400, error: "One of the selected sessions is invalid." };
    }
    if (toMin(s.endTime) - toMin(s.startTime) !== minutes) {
      return { status: 400, error: `Every session must be ${minutes} minutes long.` };
    }
    if (s.date < today) return { status: 400, error: "Sessions cannot be in the past." };

    const key = `${s.date}|${s.startTime}`;
    if (seen.has(key)) return { status: 400, error: "The same session is selected twice." };
    seen.add(key);
    planned.push({ date: s.date, startTime: s.startTime, endTime: s.endTime });
  }

  const byDate = {};
  for (const s of planned) (byDate[s.date] ||= []).push(s);
  for (const list of Object.values(byDate)) {
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        if (timesOverlap(list[i], list[j])) {
          return { status: 400, error: `Two selected sessions overlap on ${list[i].date}.` };
        }
      }
    }
  }

  const dates = planned.map((s) => s.date).sort();
  const from = dates[0];
  const to = dates[dates.length - 1];

  const [child, therapist, rules, busy, leaves] = await Promise.all([
    loadChild(childId),
    User.findOne({ _id: therapistId, role: "Therapist" }, "fullName").lean(),
    TherapistAvailability.find({ therapistId, isActive: true }).lean(),
    loadCustomBusy({ therapistId, childId, from, to }),
    loadTherapistLeaves(therapistId, from, to),
  ]);
  if (!child) return { status: 404, error: "Child not found." };
  if (!therapist) return { status: 404, error: "Therapist not found." };

  const conflicts = [];
  for (const s of planned) {
    const a = toMin(s.startTime);
    const b = toMin(s.endTime);
    const day = weekdayOf(s.date);
    const reasons = [];

    if (!st.workingDays.includes(day)) {
      reasons.push(`${day} is not a clinic working day.`);
    } else if (onLeave(leaves, s.date)) {
      reasons.push(`${therapist.fullName} is on leave on this day.`);
    } else if (!insideClinic(a, b, st)) {
      reasons.push("This time is outside clinic hours.");
    } else if (s.date === today && a <= nowMin) {
      reasons.push("This time has already passed.");
    } else if (!availableOnDate(rules, s.date, a, b)) {
      reasons.push(`${therapist.fullName} is not available at this time.`);
    }

    const tHit = findHit(busy.therapist, s.date, a, b);
    if (tHit) reasons.push(`${therapist.fullName} already has a session at ${rangeLabel(tHit)}.`);

    const cHit = findHit(busy.child, s.date, a, b);
    if (cHit) reasons.push(`${child.fullName} already has a session at ${rangeLabel(cHit)}.`);

    if (reasons.length) conflicts.push({ ...s, reasons });
  }

  planned.sort((x, y) => (x.date === y.date ? x.startTime.localeCompare(y.startTime) : x.date.localeCompare(y.date)));
  conflicts.sort((x, y) => (x.date === y.date ? x.startTime.localeCompare(y.startTime) : x.date.localeCompare(y.date)));

  return { minutes, sessions: planned, conflicts };
};
exports.getChildCustomWeekOptions = async (req, res) => {
  try {
    const { childId } = req.params;
    const { therapistId, startDate, endDate } = req.body;
    const minutes = Number(req.body.sessionMinutes);

    if (!mongoose.isValidObjectId(childId)) {
      return res.status(404).json({ success: false, message: "Child not found." });
    }
    if (!mongoose.isValidObjectId(therapistId)) {
      return res.status(400).json({ success: false, message: "Select a therapist." });
    }
    if (!SESSION_TIMES.includes(minutes)) {
      return res.status(400).json({
        success: false,
        message: "Session time must be 30, 45, 60, 90 or 120 minutes.",
      });
    }

    const st = await loadScheduleSettings();
    const today = todayKey(st.tz);
    const nowMin = clockMinutes(st.tz);

    const rangeError = checkCustomRange(startDate, endDate, today);
    if (rangeError) return res.status(400).json({ success: false, message: rangeError });

    const [child, therapist, rules, busy, leaves] = await Promise.all([
      loadChild(childId),
      User.exists({ _id: therapistId, role: "Therapist" }),
      TherapistAvailability.find({ therapistId, isActive: true }).lean(),
      loadCustomBusy({ therapistId, childId, from: startDate, to: endDate }),
      loadTherapistLeaves(therapistId, startDate, endDate),
    ]);
    if (!child) return res.status(404).json({ success: false, message: "Child not found." });
    if (!therapist) return res.status(404).json({ success: false, message: "Therapist not found." });

    const dates = {};
    WORKING_DAYS.forEach((d) => (dates[d] = []));
    for (let d = startDate; d <= endDate; d = addDays(d, 1)) {
      const day = weekdayOf(d);
      if (st.workingDays.includes(day)) dates[day].push(d);
    }

    const days = weeklyOptions(rules, startDate, endDate, minutes, st);

    for (const day of WORKING_DAYS) {
      days[day] = (days[day] || []).map((slot) => {
        const a = toMin(slot.startTime);
        const b = toMin(slot.endTime);
        let bad = 0;

        for (const date of dates[day]) {
          if (onLeave(leaves, date)) bad++;
          else if (date === today && a <= nowMin) bad++;
          else if (!availableOnDate(rules, date, a, b)) bad++;
          else if (findHit(busy.therapist, date, a, b) || findHit(busy.child, date, a, b)) bad++;
        }

        return {
          ...slot,
          booked: dates[day].length > 0 && bad === dates[day].length,
          conflicts: bad, 
        };
      });
    }

    return res.json({ success: true, data: { days, dates } });
  } catch (error) {
    console.error("getChildCustomWeekOptions:", error);
    return res.status(500).json({ success: false, message: "Failed to load available times." });
  }
};
exports.previewChildCustomSchedule = async (req, res) => {
  try {
    const r = await analyzeCustomPlan(req.params.childId, req.body);
    if (r.error) return res.status(r.status).json({ success: false, message: r.error });

    return res.json({
      success: true,
      data: { total: r.sessions.length, conflicts: r.conflicts },
    });
  } catch (error) {
    console.error("previewChildCustomSchedule:", error);
    return res.status(500).json({ success: false, message: "Failed to check the schedule." });
  }
};
exports.saveChildCustomSchedule = async (req, res) => {
  try {
    const { childId } = req.params;
    const { therapistId } = req.body;

    const r = await analyzeCustomPlan(childId, req.body);
    if (r.error) return res.status(r.status).json({ success: false, message: r.error });
    
    if (r.conflicts.length) {
      return res.status(409).json({
        success: false,
        hasConflicts: true,
        message: "Some sessions conflict with existing bookings. Review the schedule again.",
        conflicts: r.conflicts,
      });
    }

    const byMonth = new Map();
    for (const s of r.sessions) {
      const k = s.date.slice(0, 7);
      if (!byMonth.has(k)) byMonth.set(k, []);
      byMonth.get(k).push(s);
    }

    let created = 0;
    for (const [k, list] of byMonth) {
      const [year, month] = k.split("-").map(Number);
      const schedule = (await Scheduling.findOne({ therapistId, year, month }))
        || new Scheduling({ therapistId, year, month, appointments: [] });

      for (const s of list) {
        schedule.appointments.push({
          date: utcMidnight(s.date),
          startTime: s.startTime,
          endTime: s.endTime,
          type: "custom",
          sessionType: "regular",
          session_status: "Upcoming",
          children: [{ childId, attendance_status: "Pending" }],
        });
        created++;
      }
      await schedule.save(); 
    }

    await TherapistAssignment.updateMany(
      { therapistId: new mongoose.Types.ObjectId(therapistId) },
      { $addToSet: { childIds: new mongoose.Types.ObjectId(childId) } },
    );
    await sendNotifications({
      title: "New Sessions Scheduled",
      message: `${created} new therapy session(s) have been scheduled for you.`,
      type: "Appointment",
      audience: "users",
      users: [String(childId), String(therapistId)],
      createdBy: req.user?.id,
      sendPush: true,
    });


    return res.status(201).json({
      success: true,
      message: "Appointments created.",
      data: { created },
    });
  } catch (error) {
    console.error("saveChildCustomSchedule:", error);
    return res.status(500).json({
      success: false,
      message: error?.errors?.appointments?.message || "Failed to create appointments.",
      error: error.message,
    });
  }
};
const cancelCore = async ({ childId, appointmentId }) => {
  try {
    const r = await loadCustomAppointment(childId, appointmentId);
    if (r.error) return { status: r.status, error: r.error };
    const { doc, ap } = r;

    if ((ap.children || []).length > 1) {
      ap.children = ap.children.filter((c) => String(c.childId) !== String(childId));
    } else {
      ap.sessionType = "cancel";
    }

    await doc.save();
    return { status: 200, therapistId: String(doc.therapistId) };
  } catch (error) {
    console.error("cancelCore:", error);
    return { status: 500, error: "Failed to cancel appointment." };
  }
};

exports.cancelChildCustomAppointment = async (req, res) => {
  const { childId, appointmentId } = req.params;
  const r = await cancelCore({ childId, appointmentId });
  if (r.error) return res.status(r.status).json({ success: false, message: r.error });

  try {
    await sendNotifications({
      title: "Session Cancelled",
      message: "A therapy session scheduled for you has been cancelled.",
      type: "Reminder",
      audience: "users",
      users: [String(childId), r.therapistId],
      createdBy: req.user?.id,
      sendPush: true,
    });
  } catch (e) {
    console.error("cancel notify:", e);
  }
  return res.json({ success: true, message: "Appointment cancelled." });
};

exports.bulkCancelAppointments = async (req, res) => {
  try {
    const items = Array.isArray(req.body.items) ? req.body.items : [];
    if (!items.length || items.length > 50) {
      return res.status(400).json({ success: false, message: "Select 1 to 50 appointments." });
    }

    const results = [];
    const notify = new Map(); 

    for (const it of items) {
      const r = await cancelCore(it);
      if (r.error) {
        results.push({ appointmentId: it.appointmentId, success: false, message: r.error });
        continue;
      }
      results.push({ appointmentId: it.appointmentId, success: true });

      const key = String(it.childId);
      const entry = notify.get(key) || { count: 0, therapists: new Set() };
      entry.count += 1;
      entry.therapists.add(r.therapistId);
      notify.set(key, entry);
    }

    for (const [childId, { count, therapists }] of notify) {
      try {
        await sendNotifications({
          title: "Session Cancelled",
          message:
            count === 1
              ? "A therapy session scheduled for you has been cancelled."
              : `${count} therapy sessions scheduled for you have been cancelled.`,
          type: "Reminder",
          audience: "users",
          users: [childId, ...therapists],
          createdBy: req.user?.id,
          sendPush: true,
        });
      } catch (e) {
        console.error("bulk cancel notify:", e);
      }
    }

    const done = results.filter((x) => x.success).length;
    return res.json({
      success: done > 0,
      message: done === results.length ? "Appointments cancelled." : `${done} cancelled, ${results.length - done} failed.`,
      data: { done, failed: results.length - done, results },
    });
  } catch (error) {
    console.error("bulkCancelAppointments:", error);
    return res.status(500).json({ success: false, message: "Failed to cancel appointments." });
  }
};
const postponeCore = async ({
  childId, appointmentId, date, startTime, endTime, therapistId, actorId,
}) => {
  try {
    const r = await loadCustomAppointment(childId, appointmentId);
    if (r.error) return { status: r.status, error: r.error };
    const { doc, ap } = r;

    if (!isValidDate(date) || !TIME_REGEX.test(startTime || "") || !TIME_REGEX.test(endTime || "")) {
      return { status: 400, error: "Pick a new date and time." };
    }

    const oldTherapistId = String(doc.therapistId);
    const newTherapistId =
      therapistId && mongoose.isValidObjectId(therapistId) ? String(therapistId) : oldTherapistId;
    const sameTherapist = newTherapistId === oldTherapistId;

    const minutes = toMin(ap.endTime) - toMin(ap.startTime);
    if (toMin(endTime) - toMin(startTime) !== minutes) {
      return { status: 400, error: `The new session must be ${minutes} minutes long.` };
    }
    if (sameTherapist && date === dateKeyOf(ap.date) && startTime === ap.startTime) {
      return { status: 400, error: "Pick a different date or time." };
    }

    const free = await computeFreeSlots({
      therapistId: newTherapistId,
      childIds: [childId],
      date,
      minutes,
      step: minutes,
      includeBooked: true,
    });
    if (free.error) return { status: 400, error: free.error };
    if (free.onLeave) return { status: 409, error: LEAVE_MSG };

    const ok = free.slots.some(
      (s) => s.startTime === startTime && s.endTime === endTime && !s.booked,
    );
    if (!ok) return { status: 409, error: "That time is no longer available. Pick another one." };

    if ((ap.children || []).length > 1) {
      ap.children = ap.children.filter((c) => String(c.childId) !== String(childId));
    } else {
      ap.sessionType = "postponed";
    }

    const d = utcMidnight(date);
    const year = d.getUTCFullYear();
    const month = d.getUTCMonth() + 1;

    const sameDoc = sameTherapist && doc.year === year && doc.month === month;
    const target = sameDoc
      ? doc
      : (await Scheduling.findOne({ therapistId: newTherapistId, year, month }))
        || new Scheduling({ therapistId: newTherapistId, year, month, appointments: [] });

    target.appointments.push({
      date: d,
      startTime,
      endTime,
      type: "custom",
      sessionType: "alternate",
      originalAppointmentId: ap._id,
      session_status: "Upcoming",
      children: [{ childId, attendance_status: "Pending" }],
    });

    await target.save();
    if (!sameDoc) await doc.save();

    await sendNotifications({
      title: "Session Rescheduled",
      message: `Your therapy session has been rescheduled to ${date} from ${startTime} to ${endTime}.`,
      type: "Reminder",
      audience: "users",
      users: [...new Set([String(childId), newTherapistId, oldTherapistId])],
      createdBy: actorId,
      sendPush: true,
    });

    const created = target.appointments[target.appointments.length - 1];
    return { status: 200, data: { appointmentId: String(created._id), date, startTime, endTime } };
  } catch (error) {
    console.error("postponeCore:", error);
    if (error.name === "ValidationError") {
      return {
        status: 409,
        error: error?.errors?.appointments?.message || "That time conflicts with another appointment.",
      };
    }
    return { status: 500, error: "Failed to postpone appointment." };
  }
};

// single (modal purana wala, behavior same)
exports.postponeChildCustomAppointment = async (req, res) => {
  const { childId, appointmentId } = req.params;
  const r = await postponeCore({ childId, appointmentId, ...req.body, actorId: req.user?.id });
  if (r.error) return res.status(r.status).json({ success: false, message: r.error });
  return res.json({ success: true, message: "Appointment postponed.", data: r.data });
};

// bulk
exports.bulkPostponeAppointments = async (req, res) => {
  try {
    const items = Array.isArray(req.body.items) ? req.body.items : [];
    if (!items.length || items.length > 50) {
      return res.status(400).json({ success: false, message: "Select 1 to 50 appointments." });
    }

    // sequential on purpose: same Scheduling doc par parallel save VersionError deta hai,
    // aur pehle save hui booking agle slot check ko nazar aati hai
    const results = [];
    for (const it of items) {
      const r = await postponeCore({ ...it, actorId: req.user?.id });
      results.push(
        r.error
          ? { appointmentId: it.appointmentId, success: false, message: r.error }
          : { appointmentId: it.appointmentId, success: true },
      );
    }
    const done = results.filter((x) => x.success).length;
    return res.json({
      success: done > 0,
      message: done === results.length ? "Appointments rescheduled." : `${done} rescheduled, ${results.length - done} failed.`,
      data: { done, failed: results.length - done, results },
    });
  } catch (error) {
    console.error("bulkPostponeAppointments:", error);
    return res.status(500).json({ success: false, message: "Failed to reschedule appointments." });
  }
};

const statusFromProgress = (progress) => {
  if (progress >= 100) return "completed";
  if (progress > 0) return "in_progress";
  return "pending";
};
const attachLiveProgress = async (reports) => {
  const programIds = [
    ...new Set(
      reports.flatMap((r) =>
        (r.programs || []).map((p) => String(p.programId)).filter(Boolean),
      ),
    ),
  ];
  if (!programIds.length) return reports;

  const dbPrograms = await Program.find({ _id: { $in: programIds } })
    .select("programGoals")
    .lean();

  const goalMap = new Map();
  dbPrograms.forEach((p) =>
    (p.programGoals || []).forEach((g) => goalMap.set(String(g._id), g)),
  );

  return reports.map((r) => ({
    ...r,
    programs: (r.programs || []).map((p) => ({
      ...p,
      goals: (p.goals || []).map((g) => {
        const live = goalMap.get(String(g.goalId));
        if (!live) return g;
        const progress = typeof live.progress === "number" ? live.progress : 0;
        return {
          ...g,
          progress,
          status: statusFromProgress(progress),
        };
      }),
    })),
  }));
};

exports.adminListQuarterlyReports = async (req, res) => {
  try {
    const { year, quarter, therapistId, search, page = 1, limit = 15 } = req.query;

    const q = {};
    if (year) q.year = Number(year);
    if (quarter) q.quarter = quarter;
    if (therapistId) q.therapistId = therapistId;

    if (search?.trim()) {
      const rx = new RegExp(search.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      const people = await User.find({ $or: [{ fullName: rx }, { name: rx }] })
        .select("_id")
        .lean();
      const ids = people.map((p) => p._id);
      q.$or = [{ userId: { $in: ids } }, { therapistId: { $in: ids } }];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [items, total, childIds, therapistIds] = await Promise.all([
      QuarterlyReport.find(q)
        .populate("userId", "fullName name profileImage")
        .populate("therapistId", "fullName name")
        .sort({ updatedAt: -1 })
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      QuarterlyReport.countDocuments(q),
      QuarterlyReport.distinct("userId", q),
      QuarterlyReport.distinct("therapistId", q),
    ]);
    const dataWithProgress = await attachLiveProgress(items);
    return res.status(200).json({
      success: true,
      data: dataWithProgress,
      stats: { total, children: childIds.length, therapists: therapistIds.length },
      pagination: { page: Number(page), hasMore: skip + items.length < total },
    });
  } catch (error) {
    console.error("Admin list quarterly reports error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch quarterly reports." });
  }
};
exports.adminGetQuarterlyReport = async (req, res) => {
  try {
    const report = await QuarterlyReport.findById(req.params.id)
      .populate("userId", "fullName name profileImage")
      .populate("therapistId", "fullName name")
      .lean();
    if (!report) return res.status(404).json({ success: false, message: "Report not found." });
    const [withProgress] = await attachLiveProgress([report]);
    return res.status(200).json({ success: true, data: withProgress });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Failed to fetch report." });
  }
};

const formatAppDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  return `${year}-${month}-${day}`;
};

const validDateKey = (value) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;

  const date = new Date(`${value}T00:00:00.000Z`);

  return !Number.isNaN(date.getTime())
    && date.toISOString().slice(0, 10) === value;
};

const appointmentDateKey = (value) => {
  if (!value) return null;

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return null;

  return date.toISOString().slice(0, 10);
};

const addCalendarDays = (dateKey, count) => {
  const date = new Date(`${dateKey}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + count);

  return date.toISOString().slice(0, 10);
};

const normalizeStatus = (value) => {
  if (value === "Complete" || value === "Present") {
    return "Present";
  }

  if (value === "Absent") return "Absent";

  return "Pending";
};


exports.getAdminAttendance = async (req, res) => {
  try {
    const {
      year,
      month,
      mode = "today",
      date,
      attendanceType = "child",
      page = 1,
      limit = 5,
    } = req.query;

    // Admin authorization
    const role = String(req.user?.role || "").toLowerCase();

    if (!["admin", "superadmin"].includes(role)) {
      return res.status(403).json({
        success: false,
        message: "Admin access required.",
      });
    }

    const selectedType = String(attendanceType).toLowerCase();

    if (!["child", "therapist"].includes(selectedType)) {
      return res.status(400).json({
        success: false,
        message: "Invalid attendance type.",
      });
    }

    const selectedMode = String(mode).toLowerCase();

    if (!["today", "tomorrow", "week", "month"].includes(selectedMode)) {
      return res.status(400).json({
        success: false,
        message: "Invalid attendance mode.",
      });
    }

    const currentDate = formatAppDate(new Date());

    let selectedDate = date
      ? String(date)
      : selectedMode === "tomorrow"
      ? addCalendarDays(currentDate, 1)
      : currentDate;

    if (!validDateKey(selectedDate)) {
      return res.status(400).json({
        success: false,
        message: "Invalid date.",
      });
    }

    const selectedYear = Number(selectedDate.slice(0, 4));
    const selectedMonth = Number(selectedDate.slice(5, 7));

    const currentPage = Math.max(1, Number(page) || 1);
    const pageLimit = Math.min(50, Math.max(1, Number(limit) || 5));

    if (
      (year !== undefined && Number(year) !== selectedYear) ||
      (month !== undefined && Number(month) !== selectedMonth)
    ) {
      return res.status(400).json({
        success: false,
        message: "Year and month must match the selected date.",
      });
    }

    // ==========================================
    // 1. FETCH ALL SCHEDULES
    // ==========================================

    const schedules = await Scheduling.find({
      year: selectedYear,
      month: selectedMonth,
    })
      .select("_id therapistId year month appointments")
      .lean();

    if (!schedules.length) {
      return res.status(200).json({
        success: true,
        data: [],
        count: 0,
        pagination: {
          page: currentPage,
          limit: pageLimit,
          total: 0,
          totalPages: 0,
          hasMore: false,
        },
        summary: {},
      });
    }

    // ==========================================
    // 2. GET CHILD IDs AND THERAPIST IDs
    // ==========================================

    const childIds = new Set();
    const therapistIds = new Set();

    schedules.forEach((schedule) => {
      if (schedule.therapistId) {
        therapistIds.add(String(schedule.therapistId));
      }

      (schedule.appointments || []).forEach((appointment) => {
        if (appointmentDateKey(appointment.date) !== selectedDate) {
          return;
        }

        (appointment.children || []).forEach((entry) => {
          const id = entry.childId?._id || entry.childId;

          if (id) childIds.add(String(id));
        });
      });
    });

    // ==========================================
    // 3. FETCH USERS
    // ==========================================

    const [children, therapists] = await Promise.all([
      User.find({
        _id: { $in: [...childIds] },
        isActive: true,
      })
        .select("_id fullName name profileImage fatherName parentName")
        .lean(),

      User.find({
        _id: { $in: [...therapistIds] },
      })
        .select("_id fullName name profileImage")
        .lean(),
    ]);

    const childMap = new Map(
      children.map((child) => [String(child._id), child])
    );

    const therapistMap = new Map(
      therapists.map((therapist) => [
        String(therapist._id),
        therapist,
      ])
    );

    // ==========================================
    // 4. BUILD ATTENDANCE RECORDS
    // ==========================================

    const data = [];

    for (const schedule of schedules) {
      const therapist = therapistMap.get(
        String(schedule.therapistId)
      );

      for (const appointment of schedule.appointments || []) {
        const appointmentDate = appointmentDateKey(
          appointment.date
        );

        if (appointmentDate !== selectedDate) continue;

        const validChildren = [];

        for (const childEntry of appointment.children || []) {
          const childId = String(
            childEntry.childId?._id ||
            childEntry.childId ||
            ""
          );

          const child = childMap.get(childId);

          if (!child) continue;

          validChildren.push({ childEntry, child });
        }

        if (!validChildren.length) continue;

        // ======================================
        // THERAPIST ATTENDANCE
        // ======================================

        if (selectedType === "therapist") {
          const status = String(
            appointment.therapist_attendance || "pending"
          ).toLowerCase();

          data.push({
            attendanceId: String(schedule._id),
            appointmentId: String(appointment._id),

            therapistId: String(schedule.therapistId),

            therapistName:
              therapist?.fullName ||
              therapist?.name ||
              "Unknown Therapist",

            profileImage: therapist?.profileImage || "",

            childName: validChildren
              .map(({ child }) => child.fullName || child.name)
              .join(", "),

            date: appointmentDate,
            startTime: appointment.startTime || "",
            endTime: appointment.endTime || "",
            sessionType: appointment.sessionType || "regular",
            therapistAttendance:
              appointment.sessionType === "cancel"
                ? "cancel"
                : appointment.sessionType === "postponed"
                ? "postponed"
                : status,

            therapistAttendanceMarkedAt:
              appointment.therapist_attendance_marked_at || null,
          });

          continue;
        }

        // ======================================
        // CHILD ATTENDANCE
        // ======================================

        for (const { childEntry, child } of validChildren) {
          data.push({
            attendanceId: String(schedule._id),
            appointmentId: String(appointment._id),

            childAttendanceId: childEntry._id
              ? String(childEntry._id)
              : null,

            childId: String(child._id),

            childName:
              child.fullName ||
              child.name ||
              "Unknown Child",

            profileImage: child.profileImage || "",

            therapistId: String(schedule.therapistId),

            therapistName:
              therapist?.fullName ||
              therapist?.name ||
              "Unknown Therapist",

            date: appointmentDate,
            startTime: appointment.startTime || "",
            endTime: appointment.endTime || "",

            sessionType: appointment.sessionType || "regular",
            attendanceStatus:
              appointment.sessionType === "cancel"
                ? "cancel"
                : appointment.sessionType === "postponed"
                ? "postponed"
                : normalizeStatus(childEntry.attendance_status),
          });
        }
      }
    }

    // ==========================================
    // 5. SORT RECORDS
    // ==========================================

    data.sort((a, b) => {
      const timeCompare = String(a.startTime).localeCompare(
        String(b.startTime)
      );

      if (timeCompare !== 0) return timeCompare;

      return String(a.childName || a.therapistName).localeCompare(
        String(b.childName || b.therapistName)
      );
    });

    // ==========================================
    // 6. SUMMARY
    // ==========================================

    const summary = selectedType === "therapist"
      ? {
          total: data.length,
          present: data.filter(
            (item) => item.therapistAttendance === "present"
          ).length,
          absent: data.filter(
            (item) => item.therapistAttendance === "absent"
          ).length,
          pending: data.filter(
            (item) => item.therapistAttendance === "pending"
          ).length,
          cancelled: data.filter(
            (item) => item.therapistAttendance === "cancel"
          ).length,
          postponed: data.filter(
            (item) => item.therapistAttendance === "postpond" || item.therapistAttendance === "postponed"
          ).length,
        }
      : {
          total: data.length,
          present: data.filter(
            (item) => item.attendanceStatus === "Present"
          ).length,
          absent: data.filter(
            (item) => item.attendanceStatus === "Absent"
          ).length,
          pending: data.filter(
            (item) => item.attendanceStatus === "Pending"
          ).length,
          cancelled: data.filter((item) => item.attendanceStatus === "cancel").length,
        };

    // ==========================================
    // 7. PAGINATION
    // ==========================================

    const total = data.length;
    const totalPages = Math.ceil(total / pageLimit);
    const startIndex = (currentPage - 1) * pageLimit;

    const paginatedData = data.slice(
      startIndex,
      startIndex + pageLimit
    );

    return res.status(200).json({
      success: true,
      message: "Admin attendance fetched successfully.",
      attendanceType: selectedType,
      selectedDate,
      data: paginatedData,
      count: paginatedData.length,
      summary,
      pagination: {
        page: currentPage,
        limit: pageLimit,
        total,
        totalPages,
        hasMore: currentPage < totalPages,
      },
    });

  } catch (error) {
    console.error("getAdminAttendance error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch admin attendance.",
      error: error.message,
    });
  }
};

const CHILD_DB_STATUS = {
  present: "Complete",   
  absent: "Absent",
  pending: "Pending",
};

exports.updateAdminAttendance = async (req, res) => {
  try {
    const role = String(req.user?.role || "").toLowerCase();
    if (!["admin", "superadmin"].includes(role)) {
      return res.status(403).json({ success: false, message: "Admin access required." });
    }

    const { attendanceType, scheduleId, appointmentId, childId, status } = req.body;
    const type = String(attendanceType || "").toLowerCase();
    const newStatus = String(status || "").toLowerCase();

    if (!["child", "therapist"].includes(type)) {
      return res.status(400).json({ success: false, message: "Invalid attendance type." });
    }
    if (!["present", "absent", "pending"].includes(newStatus)) {
      return res.status(400).json({ success: false, message: "Invalid status." });
    }
    if (
      !mongoose.isValidObjectId(scheduleId) ||
      !mongoose.isValidObjectId(appointmentId) ||
      (type === "child" && !mongoose.isValidObjectId(childId))
    ) {
      return res.status(400).json({ success: false, message: "Invalid ids." });
    }

    const doc = await Scheduling.findById(scheduleId).select("appointments").lean();
    const ap = doc?.appointments?.find((a) => String(a._id) === String(appointmentId));
    if (!ap) {
      return res.status(404).json({ success: false, message: "Appointment not found." });
    }

    if (ap.sessionType === "cancel" || ap.sessionType === "postponed") {
      return res.status(400).json({
        success: false,
        message: "Cancelled or postponed sessions cannot be marked.",
      });
    }

    if (appointmentDateKey(ap.date) > formatAppDate(new Date())) {
      return res.status(400).json({
        success: false,
        message: "You cannot mark attendance for a future appointment.",
      });
    }

    let result;

    if (type === "child") {
      const inside = (ap.children || []).some((c) => String(c.childId) === String(childId));
      if (!inside) {
        return res.status(404).json({ success: false, message: "Child not found in this appointment." });
      }

      result = await Scheduling.updateOne(
        { _id: scheduleId },
        { $set: { "appointments.$[a].children.$[c].attendance_status": CHILD_DB_STATUS[newStatus] } },
        {
          arrayFilters: [
            { "a._id": new mongoose.Types.ObjectId(appointmentId) },
            { "c.childId": new mongoose.Types.ObjectId(childId) },
          ],
        },
      );
    } else {
      result = await Scheduling.updateOne(
        { _id: scheduleId },
        {
          $set: {
            "appointments.$[a].therapist_attendance": newStatus,
            "appointments.$[a].therapist_attendance_marked_at": new Date(),
          },
        },
        { arrayFilters: [{ "a._id": new mongoose.Types.ObjectId(appointmentId) }] },
      );
    }

    if (!result.matchedCount) {
      return res.status(404).json({ success: false, message: "Attendance record not found." });
    }

    return res.json({ success: true, message: "Attendance updated.", data: { status: newStatus } });
  } catch (error) {
    console.error("updateAdminAttendance:", error);
    return res.status(500).json({ success: false, message: "Failed to update attendance." });
  }
};
