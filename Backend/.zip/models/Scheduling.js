const mongoose = require("mongoose");

const TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)$/;

const toMin = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

const appointmentChildSchema = new mongoose.Schema(
  {
    childId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    attendance_status: {
      type: String,
      enum: ["Complete", "Absent", "Pending"],
      default: "Pending",
    },
  },
  { _id: true },
);

const appointmentSchema = new mongoose.Schema(
  {
    date: {
      type: Date,
      required: true,
    },

    startTime: {
      type: String,
      required: true,
      match: [TIME_REGEX, "startTime must be HH:mm."],
    },

    endTime: {
      type: String,
      required: true,
      match: [TIME_REGEX, "endTime must be HH:mm."],
    },

    type: {
      type: String,
      enum: ["batch", "custom"],
      required: true,
    },

    batchAssignmentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "BatchAssignment",
      default: null,
    },

    batchId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Batch",
      default: null,
    },

    sessionType: {
      type: String,
      enum: ["regular", "postponed", "additional", "alternate", "cancel"],
      default: "regular",
    },

    originalAppointmentId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
    },
    session_status: {
      type: String,
      enum: [
        "Upcoming",
        "InProgress",
        "Completed",
        "Missed",
      ],
      default: "Upcoming",
    },
    therapist_attendance: {
      type: String,
      enum: [
        "pending",
        "present",
        "absent",
        "cancel",
        "postpond"
      ],
      default: "pending"
    },
    children: {
      type: [appointmentChildSchema],
      default: [],
    },
    reminderSentAt: {
      type: Date,
      default: null,
    },
    therapist_attendance: {
      type: String,
      enum: [
        "pending",
        "present",
        "absent",
        "cancel",
        "postpond",
      ],
      default: "pending",
    },

    therapist_attendance_marked_at: {
      type: Date,
      default: null,
    },
  },
  { _id: true },
);

const schedulingSchema = new mongoose.Schema(
  {
    therapistId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    year: {
      type: Number,
      required: true,
    },

    month: {
      type: Number,
      required: true,
      min: 1,
      max: 12,
    },

    appointments: {
      type: [appointmentSchema],
      default: [],
    },
  },
  {
    timestamps: true,
  },
);

schedulingSchema.index(
  {
    therapistId: 1,
    year: 1,
    month: 1,
  },
  {
    unique: true,
  },
);

schedulingSchema.pre("validate", function () {
  const byDate = {};

  for (const ap of this.appointments) {
    const dateObj = new Date(ap.date);
    const key = dateObj.toISOString().slice(0, 10);

    const formattedDate = [
      String(dateObj.getUTCDate()).padStart(2, "0"),
      String(dateObj.getUTCMonth() + 1).padStart(2, "0"),
      dateObj.getUTCFullYear(),
    ].join("-");

    const start = toMin(ap.startTime);
    const end = toMin(ap.endTime);

    if (["cancel", "postponed"].includes(ap.sessionType)) continue;

    if (end <= start) {
      this.invalidate(
        "appointments",
        `End time must be after start time. Date: ${formattedDate}, Start Time: ${ap.startTime}, End Time: ${ap.endTime}.`
      );
      return;
    }

    const list = (byDate[key] = byDate[key] || []);

    if (list.some((x) => start < x.end && x.start < end)) {
      this.invalidate(
        "appointments",
        `Appointment conflict on ${formattedDate}. Start Time: ${ap.startTime}, End Time: ${ap.endTime}.`
      );
      return;
    }

    list.push({ start, end });
  }
});
schedulingSchema.index({ "appointments.batchId": 1 });
schedulingSchema.index({ "appointments.batchAssignmentId": 1 });
schedulingSchema.index({ "appointments.children.childId": 1 });
schedulingSchema.index({ "appointments._id": 1 });

module.exports = mongoose.model("Scheduling", schedulingSchema);
