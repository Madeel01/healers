const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const authRoutes = require("./routes/authRoutes");
const adminRoutes = require("./routes/adminRoutes");
const therapistRoutes = require("./routes/therapistRoutes");
const schedulingRoutes = require("./routes/schedulingRoutes");
const childRoutes = require("./routes/childRoutes");
const chatRoutes = require("./routes/chatRoutes");
const invoiceRoutes = require("./routes/invoiceRoute");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});
const MONGO_URI = process.env.MONGO_URI;
console.log(MONGO_URI,"uriiii");
mongoose
  .connect("mongodb://thehealerskpk_db_user:LtNEh6OflcIdLthE@ac-9jthydw-shard-00-00.h6wruvp.mongodb.net:27017,ac-9jthydw-shard-00-01.h6wruvp.mongodb.net:27017,ac-9jthydw-shard-00-02.h6wruvp.mongodb.net:27017/HEALERS?ssl=true&replicaSet=atlas-qvc2hf-shard-0&authSource=admin&appName=Healers")
  .then(() => {
    console.log("MongoDB Connected Successfully");
    // require("./jobs/cleanupPendingUploads")();
    try {
      require("./jobs/appointmentReminderJob").start();
      require("./jobs/scheduledBroadcasts").start();
    } catch (err) {
      console.error("Scheduled broadcast startup error:", err);
    }
  })
  .catch((err) => {
    console.error("MongoDB Connection Error:", err.message);
    process.exit(1);
  });
app.get("/", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Healers Institution API is running smoothly",
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/therapist", therapistRoutes);
app.use("/api/scheduling", schedulingRoutes);
app.use("/assets/broadcasts", express.static(path.join(__dirname, "assets", "broadcasts")));
app.use("/api/child", childRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/admin_invoice", invoiceRoutes);

app.use((req, res, next) => {
  res.status(404).json({ message: `Cannot find ${req.originalUrl} on this server` });
});

app.use((err, req, res, next) => {
  console.error("Unhandled Error:", err.stack);
  res.status(err.status || 500).json({
    message: err.message || "Internal Server Error",
  });
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server listening on port ${PORT}`);
});
