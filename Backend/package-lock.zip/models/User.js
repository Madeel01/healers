const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      unique: true,
      sparse: true,
      lowercase: true,
      trim: true,
    },
    phone: {
      type: String,
      // unique: true,
      // sparse: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: ["Admin", "Therapist", "Parent", "Child"],
      default: "Child",
    },
    permissions: [{
      type: String,
    }],

    biometricKey: {
      type: String,
      default: null,
    },
    agreeTerms: {
      type: Boolean,
      required: true,
    },
    isLogin: {
      type: Boolean,
      default: false,
    },
    fatherName: {
      type: String,
      default: "",
      trim: true,
    },
    fatherCnic: { type: String, trim: true, default: "" },
    age: {
      type: Number,
      default: null,
      min: 0,
    },
    profileImage: {
      type: String,
      default: "",
      trim: true,
    },
    isOnline: {
      type: Boolean,
      default: false,
    },
    lastActive: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("User", userSchema);
